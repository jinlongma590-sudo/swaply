// lib/services/notification_service.dart
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/foundation.dart';
import 'package:postgrest/postgrest.dart'; // 必须：提供 eq / in_ 等扩展
/// 通知类型枚举
enum NotificationType {
  offer('offer'),
  wishlist('wishlist'),
  system('system'),
  message('message'),
  purchase('purchase'),
  priceDrop('price_drop');

  const NotificationType(this.value);
  final String value;
}

/// 通知服务类
class NotificationService {
  static final SupabaseClient _client = Supabase.instance.client;
  static const String _tableName = 'notifications';

  /// 获取当前用户ID
  static String? get _currentUserId => _client.auth.currentUser?.id;

  /// 调试打印
  static void _debugPrint(String message) {
    if (kDebugMode) {
      // ignore: avoid_print
      print('[NotificationService] $message');
    }
  }

  /// 创建新通知
  static Future<Map<String, dynamic>?> createNotification({
    required String recipientId,
    String? senderId,
    required NotificationType type,
    required String title,
    required String message,
    String? listingId,
    String? offerId,
    Map<String, dynamic>? metadata,
  }) async {
    try {
      _debugPrint('Creating notification: $title for user $recipientId');

      final data = {
        'recipient_id': recipientId,
        'sender_id': senderId ?? _currentUserId,
        'type': type.value,
        'title': title,
        'message': message,
        'listing_id': listingId,
        'offer_id': offerId,
        'metadata': metadata ?? <String, dynamic>{},
        'created_at': DateTime.now().toIso8601String(),
      };

      final result = await _client.from(_tableName).insert(data).select().single();

      _debugPrint('Notification created successfully: ${result['id']}');
      return Map<String, dynamic>.from(result);
    } catch (e) {
      _debugPrint('Error creating notification: $e');
      return null;
    }
  }

  /// 创建报价通知
  static Future<bool> createOfferNotification({
    required String sellerId,
    required String buyerId,
    required String listingId,
    required double offerAmount,
    required String listingTitle,
    String? buyerName,
    String? buyerPhone,
    String? message,
  }) async {
    try {
      final displayName = buyerName ?? 'Someone';
      final notification = await createNotification(
        recipientId: sellerId,
        senderId: buyerId,
        type: NotificationType.offer,
        title: 'New Offer Received',
        message: '$displayName made an offer of \$$offerAmount for your $listingTitle',
        listingId: listingId,
        metadata: {
          'offer_amount': offerAmount,
          'buyer_name': displayName,
          'buyer_phone': buyerPhone,
          'buyer_message': message,
          'listing_title': listingTitle,
        },
      );

      return notification != null;
    } catch (e) {
      _debugPrint('Error creating offer notification: $e');
      return false;
    }
  }

  /// 创建收藏通知
  static Future<bool> createWishlistNotification({
    required String sellerId,
    required String likerId,
    required String listingId,
    required String listingTitle,
    String? likerName,
  }) async {
    try {
      // 不给自己发通知
      if (sellerId == likerId) return true;

      final displayName = likerName ?? 'Someone';
      final notification = await createNotification(
        recipientId: sellerId,
        senderId: likerId,
        type: NotificationType.wishlist,
        title: 'Item Added to Wishlist',
        message: '$displayName added your $listingTitle to their wishlist',
        listingId: listingId,
        metadata: {'liker_name': displayName, 'listing_title': listingTitle},
      );

      return notification != null;
    } catch (e) {
      _debugPrint('Error creating wishlist notification: $e');
      return false;
    }
  }

  /// 创建系统通知
  static Future<bool> createSystemNotification({
    required String recipientId,
    required String title,
    required String message,
    Map<String, dynamic>? metadata,
  }) async {
    try {
      final notification = await createNotification(
        recipientId: recipientId,
        type: NotificationType.system,
        title: title,
        message: message,
        metadata: metadata,
      );
      return notification != null;
    } catch (e) {
      _debugPrint('Error creating system notification: $e');
      return false;
    }
  }

  /// 获取用户的通知列表（避免把 select() 结果存变量后再追加条件）
  static Future<List<Map<String, dynamic>>> getUserNotifications({
    String? userId,
    int limit = 50,
    int offset = 0,
    bool includeRead = true,
  }) async {
    try {
      final targetUserId = userId ?? _currentUserId;
      if (targetUserId == null) {
        _debugPrint('No user ID provided and no current user');
        return [];
      }

      _debugPrint('Fetching notifications for user: $targetUserId');

      final List<dynamic> data = includeRead
          ? await _client
          .from(_tableName)
          .select('*')
          .eq('recipient_id', targetUserId)
          .eq('is_deleted', false)
          .order('created_at', ascending: false)
          .range(offset, offset + limit - 1)
          : await _client
          .from(_tableName)
          .select('*')
          .eq('recipient_id', targetUserId)
          .eq('is_deleted', false)
          .eq('is_read', false)
          .order('created_at', ascending: false)
          .range(offset, offset + limit - 1);

      return data.map<Map<String, dynamic>>((e) => Map<String, dynamic>.from(e)).toList();
    } catch (e) {
      _debugPrint('Error fetching notifications: $e');
      return [];
    }
  }

  /// 获取未读通知数量
  static Future<int> getUnreadNotificationsCount({String? userId}) async {
    try {
      final targetUserId = userId ?? _currentUserId;
      if (targetUserId == null) return 0;

      final List<dynamic> data = await _client
          .from(_tableName)
          .select('id')
          .eq('recipient_id', targetUserId)
          .eq('is_read', false)
          .eq('is_deleted', false);

      return data.length;
    } catch (e) {
      _debugPrint('Error getting unread count: $e');
      return 0;
    }
  }

  /// 标记通知为已读
  static Future<bool> markNotificationAsRead(String notificationId) async {
    try {
      if (_currentUserId == null) return false;

      _debugPrint('Marking notification as read: $notificationId');

      await _client
          .from(_tableName)
          .update({
        'is_read': true,
        'read_at': DateTime.now().toIso8601String(),
      })
          .eq('id', notificationId)
          .eq('recipient_id', _currentUserId!);

      return true;
    } catch (e) {
      _debugPrint('Error marking notification as read: $e');
      return false;
    }
  }

  /// 标记所有通知为已读
  static Future<bool> markAllNotificationsAsRead({String? userId}) async {
    try {
      final targetUserId = userId ?? _currentUserId;
      if (targetUserId == null) return false;

      _debugPrint('Marking all notifications as read for user: $targetUserId');

      await _client
          .from(_tableName)
          .update({
        'is_read': true,
        'read_at': DateTime.now().toIso8601String(),
      })
          .eq('recipient_id', targetUserId)
          .eq('is_read', false);

      return true;
    } catch (e) {
      _debugPrint('Error marking all notifications as read: $e');
      return false;
    }
  }

  /// 删除通知（软删除）
  static Future<bool> deleteNotification(String notificationId) async {
    try {
      if (_currentUserId == null) return false;

      _debugPrint('Deleting notification: $notificationId');

      await _client
          .from(_tableName)
          .update({'is_deleted': true})
          .eq('id', notificationId)
          .eq('recipient_id', _currentUserId!);

      return true;
    } catch (e) {
      _debugPrint('Error deleting notification: $e');
      return false;
    }
  }

  /// 清除用户所有通知（软删除）
  static Future<bool> clearAllNotifications({String? userId}) async {
    try {
      final targetUserId = userId ?? _currentUserId;
      if (targetUserId == null) return false;

      _debugPrint('Clearing all notifications for user: $targetUserId');

      await _client.from(_tableName).update({'is_deleted': true}).eq('recipient_id', targetUserId);

      return true;
    } catch (e) {
      _debugPrint('Error clearing all notifications: $e');
      return false;
    }
  }

  /// 获取通知的显示图标
  static String getNotificationIcon(String type) {
    switch (type) {
      case 'offer':
        return '🟟';
      case 'wishlist':
        return '❤️';
      case 'purchase':
        return '🟟';
      case 'message':
        return '🟟';
      case 'price_drop':
        return '🟟';
      case 'system':
      default:
        return '🟟';
    }
  }

  /// 获取通知的颜色
  static int getNotificationColor(String type) {
    switch (type) {
      case 'offer':
        return 0xFF4CAF50; // Green
      case 'wishlist':
        return 0xFFE91E63; // Pink
      case 'purchase':
        return 0xFF2196F3; // Blue
      case 'message':
        return 0xFFFF9800; // Orange
      case 'price_drop':
        return 0xFF9C27B0; // Purple
      case 'system':
      default:
        return 0xFF607D8B; // Blue Grey
    }
  }

  /// 时间格式
  static String formatNotificationTime(String createdAt) {
    try {
      final date = DateTime.parse(createdAt);
      final now = DateTime.now();
      final difference = now.difference(date);

      if (difference.inMinutes < 1) return 'Just now';
      if (difference.inMinutes < 60) return '${difference.inMinutes}m ago';
      if (difference.inHours < 24) return '${difference.inHours}h ago';
      if (difference.inDays < 7) return '${difference.inDays}d ago';
      return '${date.day}/${date.month}/${date.year}';
    } catch (_) {
      return 'Unknown';
    }
  }

  /// 订阅实时通知
  static RealtimeChannel subscribeToNotifications({
    required String userId,
    required Function(Map<String, dynamic>) onNotificationReceived,
  }) {
    _debugPrint('Subscribing to real-time notifications for user: $userId');

    final channel = _client
        .channel('notifications:$userId')
        .onPostgresChanges(
      event: PostgresChangeEvent.insert,
      schema: 'public',
      table: _tableName,
      filter: PostgresChangeFilter(
        type: PostgresChangeFilterType.eq,
        column: 'recipient_id',
        value: userId,
      ),
      callback: (payload) {
        _debugPrint('New notification received: ${payload.newRecord}');
        final record = payload.newRecord;
        if (record != null) {
          onNotificationReceived(Map<String, dynamic>.from(record));
        }
      },
    )
        .subscribe();

    return channel;
  }

  /// 取消订阅
  static void unsubscribeFromNotifications(RealtimeChannel channel) {
    _debugPrint('Unsubscribing from notifications');
    _client.removeChannel(channel);
  }

  /// 发送欢迎通知
  static Future<bool> sendWelcomeNotification(String userId) async {
    return createSystemNotification(
      recipientId: userId,
      title: 'Welcome to Swaply! 🟟',
      message:
      'Thank you for joining our marketplace. Start exploring amazing deals and sell your items!',
      metadata: {'welcome_notification': true, 'version': '1.0.0'},
    );
  }

  /// 健康检查
  static Future<bool> testConnection() async {
    try {
      _debugPrint('Testing notification service connection...');
      final userId = _currentUserId;
      if (userId == null) return false;
      await getUnreadNotificationsCount(userId: userId);
      return true;
    } catch (e) {
      _debugPrint('Notification service connection test failed: $e');
      return false;
    }
  }
}