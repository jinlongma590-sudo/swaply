// lib/services/offer_service.dart - 完全兼容版本
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/foundation.dart';
import 'package:swaply/models/offer.dart';

/// 报价服务类
class OfferService {
  static final SupabaseClient _client = Supabase.instance.client;
  static const String _tableName = 'offers';

  /// 获取当前用户ID
  static String? get _currentUserId => _client.auth.currentUser?.id;

  /// 调试打印
  static void _debugPrint(String message) {
    if (kDebugMode) {
      print('[OfferService] $message');
    }
  }

  /// 创建新报价
  static Future<Map<String, dynamic>?> createOffer({
    required String listingId,
    required String sellerId,
    required double offerAmount,
    double? originalPrice,
    String? message,
    String? buyerPhone,
    String? buyerName,
    int expiryDays = 7,
  }) async {
    try {
      final buyerId = _currentUserId;
      if (buyerId == null) {
        _debugPrint('No authenticated user found');
        return null;
      }

      // 检查是否已有未处理的报价
      final existingOffer = await _client
          .from(_tableName)
          .select('id')
          .eq('listing_id', listingId)
          .eq('buyer_id', buyerId)
          .eq('status', OfferStatus.pending.value)
          .maybeSingle();

      if (existingOffer != null) {
        _debugPrint('User already has a pending offer for this listing');
        throw Exception('You already have a pending offer for this item');
      }

      _debugPrint('Creating offer: \$$offerAmount for listing $listingId');

      final data = {
        'listing_id': listingId,
        'buyer_id': buyerId,
        'seller_id': sellerId,
        'offer_amount': offerAmount,
        'original_price': originalPrice,
        'message': message,
        'buyer_phone': buyerPhone,
        'buyer_name': buyerName ?? 'Anonymous',
        'status': OfferStatus.pending.value,
        'created_at': DateTime.now().toIso8601String(),
        'expires_at': DateTime.now().add(Duration(days: expiryDays)).toIso8601String(),
      };

      final result = await _client.from(_tableName).insert(data).select().single();

      _debugPrint('Offer created successfully: ${result['id']}');
      return result;
    } catch (e) {
      _debugPrint('Error creating offer: $e');
      rethrow;
    }
  }

  /// 更新报价状态
  static Future<bool> updateOfferStatus({
    required String offerId,
    required OfferStatus status,
    String? responseMessage,
  }) async {
    try {
      final userId = _currentUserId;
      if (userId == null) {
        _debugPrint('No authenticated user found');
        return false;
      }

      _debugPrint('Updating offer $offerId status to ${status.value}');

      final updateData = <String, dynamic>{
        'status': status.value,
        'updated_at': DateTime.now().toIso8601String(),
      };

      if (responseMessage != null && responseMessage.isNotEmpty) {
        updateData['response_message'] = responseMessage;
      }

      if (status == OfferStatus.accepted || status == OfferStatus.declined) {
        updateData['responded_at'] = DateTime.now().toIso8601String();
      }

      await _client
          .from(_tableName)
          .update(updateData)
          .eq('id', offerId)
          .eq('seller_id', userId); // 只有卖家可以更新状态

      _debugPrint('Offer status updated successfully');
      return true;
    } catch (e) {
      _debugPrint('Error updating offer status: $e');
      return false;
    }
  }

  /// 接受报价
  static Future<bool> acceptOffer(String offerId, {String? message}) async {
    try {
      final success = await updateOfferStatus(
        offerId: offerId,
        status: OfferStatus.accepted,
        responseMessage: message,
      );

      if (success) {
        // 自动拒绝同一商品的其他待处理报价
        await _rejectOtherOffers(offerId);
      }

      return success;
    } catch (e) {
      _debugPrint('Error accepting offer: $e');
      return false;
    }
  }

  /// 拒绝报价 (兼容旧方法名)
  static Future<bool> declineOffer(String offerId, {String? message}) async {
    return rejectOffer(offerId, reason: message);
  }

  /// 拒绝报价
  static Future<bool> rejectOffer(String offerId, {String? reason}) async {
    return updateOfferStatus(
      offerId: offerId,
      status: OfferStatus.declined,
      responseMessage: reason,
    );
  }

  /// 撤回报价（买家操作）
  static Future<bool> withdrawOffer(String offerId, {String? reason}) async {
    try {
      final userId = _currentUserId;
      if (userId == null) {
        _debugPrint('No authenticated user found');
        return false;
      }

      _debugPrint('Withdrawing offer: $offerId');

      final updateData = <String, dynamic>{
        'status': OfferStatus.withdrawn.value,
        'updated_at': DateTime.now().toIso8601String(),
      };

      if (reason != null && reason.isNotEmpty) {
        updateData['response_message'] = reason;
      }

      await _client
          .from(_tableName)
          .update(updateData)
          .eq('id', offerId)
          .eq('buyer_id', userId); // 只有买家可以撤回自己的报价

      _debugPrint('Offer withdrawn successfully');
      return true;
    } catch (e) {
      _debugPrint('Error withdrawing offer: $e');
      return false;
    }
  }

  /// 自动拒绝同一商品的其他待处理报价
  static Future<void> _rejectOtherOffers(String acceptedOfferId) async {
    try {
      // 获取被接受报价的商品ID
      final acceptedOffer = await _client
          .from(_tableName)
          .select('listing_id')
          .eq('id', acceptedOfferId)
          .single();

      final listingId = acceptedOffer['listing_id'];

      // 拒绝同一商品的其他待处理报价
      await _client
          .from(_tableName)
          .update({
        'status': OfferStatus.declined.value,
        'updated_at': DateTime.now().toIso8601String(),
        'response_message': 'This item has been sold to another buyer.',
      })
          .eq('listing_id', listingId)
          .eq('status', OfferStatus.pending.value)
          .neq('id', acceptedOfferId);

      _debugPrint('Rejected other pending offers for listing: $listingId');
    } catch (e) {
      _debugPrint('Error rejecting other offers: $e');
    }
  }

  /// 获取商品的所有报价（卖家视图）
  static Future<List<Map<String, dynamic>>> getListingOffers({
    required String listingId,
    List<OfferStatus>? statusFilter,
    int limit = 50,
    int offset = 0,
  }) async {
    try {
      final userId = _currentUserId;
      if (userId == null) {
        _debugPrint('No authenticated user found');
        return [];
      }

      _debugPrint('Fetching offers for listing: $listingId');

      var query = _client
          .from(_tableName)
          .select('''
            *,
            listings!inner(id, title, price, images, city),
            buyer_profiles:buyer_id(full_name, avatar_url, phone)
          ''')
          .eq('listing_id', listingId);

      // 如果有状态筛选，添加状态过滤
      if (statusFilter != null && statusFilter.isNotEmpty) {
        final statusValues = statusFilter.map((s) => s.value).toList();
        query = query.filter('status', 'in', '(${statusValues.join(',')})');
      }

      final List<dynamic> data = await query
          .order('created_at', ascending: false)
          .range(offset, offset + limit - 1);

      return data.map<Map<String, dynamic>>((e) => Map.from(e)).toList();
    } catch (e) {
      _debugPrint('Error fetching listing offers: $e');
      return [];
    }
  }

  /// 获取用户发出的报价（买家视图）
  static Future<List<Map<String, dynamic>>> getUserOffers({
    String? userId,
    List<OfferStatus>? statusFilter,
    int limit = 50,
    int offset = 0,
  }) async {
    try {
      final targetUserId = userId ?? _currentUserId;
      if (targetUserId == null) {
        _debugPrint('No user ID provided');
        return [];
      }

      _debugPrint('Fetching offers for user: $targetUserId');

      var query = _client
          .from(_tableName)
          .select('''
            *,
            listings!inner(id, title, price, images, city),
            seller_profiles:seller_id(full_name, avatar_url, phone)
          ''')
          .eq('buyer_id', targetUserId);

      // 如果有状态筛选，添加状态过滤
      if (statusFilter != null && statusFilter.isNotEmpty) {
        final statusValues = statusFilter.map((s) => s.value).toList();
        query = query.filter('status', 'in', '(${statusValues.join(',')})');
      }

      final List<dynamic> data = await query
          .order('created_at', ascending: false)
          .range(offset, offset + limit - 1);

      return data.map<Map<String, dynamic>>((e) => Map.from(e)).toList();
    } catch (e) {
      _debugPrint('Error fetching user offers: $e');
      return [];
    }
  }

  /// 获取收到的报价（卖家视图）
  static Future<List<Map<String, dynamic>>> getReceivedOffers({
    String? userId,
    List<OfferStatus>? statusFilter,
    int limit = 50,
    int offset = 0,
  }) async {
    try {
      final targetUserId = userId ?? _currentUserId;
      if (targetUserId == null) {
        _debugPrint('No user ID provided');
        return [];
      }

      _debugPrint('Fetching received offers for user: $targetUserId');

      var query = _client
          .from(_tableName)
          .select('''
            *,
            listings!inner(id, title, price, images, city),
            buyer_profiles:buyer_id(full_name, avatar_url, phone)
          ''')
          .eq('seller_id', targetUserId);

      // 如果有状态筛选，添加状态过滤
      if (statusFilter != null && statusFilter.isNotEmpty) {
        final statusValues = statusFilter.map((s) => s.value).toList();
        query = query.filter('status', 'in', '(${statusValues.join(',')})');
      }

      final List<dynamic> data = await query
          .order('created_at', ascending: false)
          .range(offset, offset + limit - 1);

      return data.map<Map<String, dynamic>>((e) => Map.from(e)).toList();
    } catch (e) {
      _debugPrint('Error fetching received offers: $e');
      return [];
    }
  }

  /// 获取单个报价详情
  static Future<Map<String, dynamic>?> getOfferDetails(String offerId) async {
    try {
      _debugPrint('Fetching offer details: $offerId');

      final data = await _client
          .from(_tableName)
          .select('''
            *,
            listings!inner(id, title, price, images, city, description),
            buyer_profiles:buyer_id(full_name, avatar_url, phone),
            seller_profiles:seller_id(full_name, avatar_url, phone)
          ''')
          .eq('id', offerId)
          .single();

      _debugPrint('Fetched offer details successfully');
      return Map<String, dynamic>.from(data);
    } catch (e) {
      _debugPrint('Error fetching offer details: $e');
      return null;
    }
  }

  /// 检查用户是否对某商品有未处理的报价
  static Future<Map<String, dynamic>?> getUserPendingOffer({
    required String listingId,
    String? userId,
  }) async {
    try {
      final targetUserId = userId ?? _currentUserId;
      if (targetUserId == null) return null;

      _debugPrint('Checking pending offer for listing: $listingId');

      final data = await _client
          .from(_tableName)
          .select('*')
          .eq('listing_id', listingId)
          .eq('buyer_id', targetUserId)
          .eq('status', OfferStatus.pending.value)
          .maybeSingle();

      if (data != null) {
        _debugPrint('Found pending offer: ${data['id']}');
        return Map<String, dynamic>.from(data);
      }

      return null;
    } catch (e) {
      _debugPrint('Error checking pending offer: $e');
      return null;
    }
  }

  /// 获取报价统计信息
  static Future<Map<String, int>> getOfferStats({String? userId}) async {
    try {
      final targetUserId = userId ?? _currentUserId;
      if (targetUserId == null) {
        return {
          'sent_offers': 0,
          'received_offers': 0,
          'pending_sent': 0,
          'pending_received': 0,
          'accepted': 0,
          'declined': 0,
          'expired': 0,
          'withdrawn': 0,
        };
      }

      _debugPrint('Fetching offer stats for user: $targetUserId');

      final sentOffers = await _client
          .from(_tableName)
          .select('status')
          .eq('buyer_id', targetUserId);

      final receivedOffers = await _client
          .from(_tableName)
          .select('status')
          .eq('seller_id', targetUserId);

      final stats = {
        'sent_offers': sentOffers.length,
        'received_offers': receivedOffers.length,
        'pending_sent': sentOffers.where((o) => o['status'] == 'pending').length,
        'pending_received': receivedOffers.where((o) => o['status'] == 'pending').length,
        'accepted': sentOffers.where((o) => o['status'] == 'accepted').length,
        'declined': sentOffers.where((o) => o['status'] == 'declined').length +
            receivedOffers.where((o) => o['status'] == 'declined').length,
        'expired': sentOffers.where((o) => o['status'] == 'expired').length +
            receivedOffers.where((o) => o['status'] == 'expired').length,
        'withdrawn': sentOffers.where((o) => o['status'] == 'withdrawn').length,
      };

      _debugPrint('Offer stats: $stats');
      return stats;
    } catch (e) {
      _debugPrint('Error fetching offer stats: $e');
      return {};
    }
  }

  /// 标记过期报价
  static Future<int> markExpiredOffers() async {
    try {
      _debugPrint('Marking expired offers...');

      final result = await _client
          .from(_tableName)
          .update({
        'status': OfferStatus.expired.value,
        'updated_at': DateTime.now().toIso8601String(),
      })
          .eq('status', OfferStatus.pending.value)
          .lt('expires_at', DateTime.now().toIso8601String())
          .select('id');

      final expiredCount = (result as List).length;
      _debugPrint('Marked $expiredCount offers as expired');
      return expiredCount;
    } catch (e) {
      _debugPrint('Error marking expired offers: $e');
      return 0;
    }
  }

  /// 删除报价记录（仅买家可删自己的）
  static Future<bool> deleteOffer(String offerId) async {
    try {
      final userId = _currentUserId;
      if (userId == null) return false;

      _debugPrint('Deleting offer: $offerId');

      await _client
          .from(_tableName)
          .delete()
          .eq('id', offerId)
          .eq('buyer_id', userId);

      _debugPrint('Offer deleted successfully');
      return true;
    } catch (e) {
      _debugPrint('Error deleting offer: $e');
      return false;
    }
  }

  // 兼容性方法 - 保持与现有代码的兼容性

  /// 获取状态显示文本（兼容性方法）
  static String getStatusDisplayText(String status) {
    return OfferStatus.fromString(status).displayText;
  }

  /// 获取状态颜色（兼容性方法）
  static int getStatusColor(String status) {
    return OfferStatus.fromString(status).color;
  }

  /// 格式化报价时间（兼容性方法）
  static String formatOfferTime(String createdAt) {
    try {
      final date = DateTime.parse(createdAt);
      final now = DateTime.now();
      final difference = now.difference(date);

      if (difference.inMinutes < 1) {
        return 'Just now';
      } else if (difference.inMinutes < 60) {
        return '${difference.inMinutes}m ago';
      } else if (difference.inHours < 24) {
        return '${difference.inHours}h ago';
      } else if (difference.inDays < 7) {
        return '${difference.inDays}d ago';
      } else {
        return '${date.day}/${date.month}/${date.year}';
      }
    } catch (_) {
      return 'Unknown';
    }
  }

  /// 计算报价百分比
  static double calculateOfferPercentage(double offerAmount, double originalPrice) {
    if (originalPrice <= 0) return 0;
    return (offerAmount / originalPrice) * 100;
  }

  /// 格式化报价金额
  static String formatOfferAmount(double amount) {
    if (amount >= 1000000) {
      return '\$${(amount / 1000000).toStringAsFixed(1)}M';
    } else if (amount >= 1000) {
      return '\$${(amount / 1000).toStringAsFixed(1)}K';
    } else {
      return '\$${amount.toStringAsFixed(0)}';
    }
  }

  /// 测试连接
  static Future<bool> testConnection() async {
    try {
      _debugPrint('Testing offer service connection...');
      final userId = _currentUserId;
      if (userId == null) {
        _debugPrint('No current user for connection test');
        return false;
      }
      await getOfferStats(userId: userId);
      _debugPrint('Offer service connection test successful');
      return true;
    } catch (e) {
      _debugPrint('Offer service connection test failed: $e');
      return false;
    }
  }
}
