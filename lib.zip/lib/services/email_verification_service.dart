// lib/services/email_verification_service.dart
import 'package:supabase_flutter/supabase_flutter.dart';

/// 负责和后端 Edge Functions 打交道：
/// - send-verification-email 负责生成验证码并发邮件、写库
/// - verify-email-code 负责校验验证码（通过后服务端或我们在前端把 profiles 标记为已验证）
class EmailVerificationService {
  EmailVerificationService._();
  static final EmailVerificationService _singleton = EmailVerificationService._();
  factory EmailVerificationService() => _singleton;

  SupabaseClient get _sb => Supabase.instance.client;

  /// 发送验证码（仅调用 Edge Function，不直接改表）
  Future<bool> sendVerificationCode(String email) async {
    try {
      final res = await _sb.functions.invoke(
        'send-verification-email',
        body: {'email': email},
      );

      // 200/201 都算成功
      if (res.status == 200 || res.status == 201) {
        return true;
      }

      // 如果不是 200/201，尝试读错误体（服务端有 error 字段的话）
      final data = res.data;
      final msg = (data is Map && data['error'] != null)
          ? data['error'].toString()
          : 'status ${res.status}';
      throw Exception(msg);
    } catch (e) {
      // 往外抛，由页面统一处理并提示
      throw Exception('Failed to send verification code: $e');
    }
  }

  /// 校验验证码（仅调用 Edge Function）
  Future<bool> verifyCode(String email, String code) async {
    try {
      final res = await _sb.functions.invoke(
        'verify-email-code',
        body: {'email': email, 'code': code},
      );

      // 函数约定返回 { ok: true } 表示成功
      final ok = (res.data is Map) && (res.data['ok'] == true);
      if (!ok) {
        final reason =
        (res.data is Map && res.data['reason'] != null) ? res.data['reason'] : 'verify failed';
        throw Exception(reason.toString());
      }

      // 双保险：函数成功后，这里把 profiles.is_email_verified 也置为 true（若你已经在函数里更新，这里不会有副作用）
      final uid = _sb.auth.currentUser?.id;
      if (uid != null) {
        await _sb
            .from('profiles')
            .update({'is_email_verified': true, 'updated_at': DateTime.now().toIso8601String()})
            .eq('id', uid);
      }

      return true;
    } catch (e) {
      throw Exception('Verification failed: $e');
    }
  }
}