// lib/services/profile_service.dart
// 只以 profiles 表为准，不再把 Supabase Auth 的 emailConfirmedAt 合并到资料里
import 'dart:io';
import 'package:supabase_flutter/supabase_flutter.dart';

class ProfileService {
  // ---- 单例：兼容 ProfileService.instance / ProfileService.i / ProfileService() ----
  ProfileService._();
  static final ProfileService instance = ProfileService._();
  static final ProfileService i = instance;
  factory ProfileService() => instance;

  SupabaseClient get _sb => Supabase.instance.client;
  String? get uid => _sb.auth.currentUser?.id;

  // ========== Profiles ==========

  /// 读取当前用户资料（兼容老接口名）
  Future<Map<String, dynamic>?> getUserProfile() => getMyProfile();

  /// 读取当前用户资料（仅返回 profiles 表数据，不合并 auth 状态）
  Future<Map<String, dynamic>?> getMyProfile() async {
    final id = uid;
    if (id == null) return null;

    try {
      final data =
      await _sb.from('profiles').select().eq('id', id).maybeSingle();
      return data == null ? null : Map<String, dynamic>.from(data);
    } catch (e) {
      print('Error in getMyProfile: $e');
      return null;
    }
  }

  /// 更新用户资料（兼容老接口名）
  Future<void> updateUserProfile({
    String? fullName,
    String? phone,
    String? avatarUrl,
  }) async {
    try {
      final current = await getMyProfile();
      final currentData = current ?? <String, dynamic>{};

      await upsertProfile(
        fullName: fullName ?? (currentData['full_name']?.toString() ?? 'User'),
        phone: phone ?? currentData['phone']?.toString(),
        avatarUrl: avatarUrl ?? currentData['avatar_url']?.toString(),
      );
    } catch (e) {
      throw Exception('Failed to update user profile: $e');
    }
  }

  /// upsert 到 profiles（新接口）
  Future<void> upsertProfile({
    required String fullName,
    String? phone,
    String? avatarUrl,
    bool? isOfficial,
    String? verificationStatus,
  }) async {
    final id = uid;
    if (id == null) throw Exception('Not logged in');

    try {
      final updateData = <String, dynamic>{
        'id': id,
        'full_name': fullName,
        'updated_at': DateTime.now().toIso8601String(),
      };

      if (phone != null) updateData['phone'] = phone;
      if (avatarUrl != null) updateData['avatar_url'] = avatarUrl;
      if (isOfficial != null) updateData['is_official'] = isOfficial;
      if (verificationStatus != null) {
        updateData['verification_status'] = verificationStatus;
      }

      await _sb.from('profiles').upsert(updateData);
    } catch (e) {
      throw Exception('Failed to upsert profile: $e');
    }
  }

  /// 上传头像
  Future<String> uploadAvatar(File file) async {
    final id = uid;
    if (id == null) throw Exception('Not logged in');

    try {
      final ext = _fileExt(file.path);
      final storagePath = '$id/avatar$ext';

      await _sb.storage
          .from('avatars')
          .upload(storagePath, file, fileOptions: const FileOptions(upsert: true));

      return _sb.storage.from('avatars').getPublicUrl(storagePath);
    } catch (e) {
      throw Exception('Failed to upload avatar: $e');
    }
  }

  // ========== 验证相关功能（以 profiles 为准） ==========

  /// 是否邮箱已验证 —— 只查 profiles.is_email_verified
  Future<bool> isEmailVerified() async {
    final id = uid;
    if (id == null) return false;
    try {
      final row = await _sb
          .from('profiles')
          .select('is_email_verified')
          .eq('id', id)
          .maybeSingle();
      return row?['is_email_verified'] == true;
    } catch (_) {
      return false;
    }
  }

  /// （保留）发送邮件验证：如需用 Supabase Auth 的邮件验证流程可继续使用；
  /// 但“已认证徽章”不再依据 auth 状态，只依据 profiles.is_email_verified。
  Future<void> sendEmailVerification({String? email}) async {
    final user = _sb.auth.currentUser;
    if (user == null) throw Exception('User not logged in');

    try {
      if (email != null && email != user.email) {
        await _sb.auth.updateUser(UserAttributes(email: email));
      } else if (user.email != null) {
        await _sb.auth.resend(type: OtpType.signup, email: user.email!);
      }
    } catch (e) {
      throw Exception('Failed to send email verification: $e');
    }
  }

  /// 刷新用户会话（可选）
  Future<void> refreshUserSession() async {
    try {
      await _sb.auth.refreshSession();
    } catch (e) {
      throw Exception('Failed to refresh session: $e');
    }
  }

  /// 设置官方账号状态
  Future<void> setOfficialStatus({
    required String userId,
    required bool isOfficial,
  }) async {
    final currentUser = _sb.auth.currentUser;
    if (currentUser == null) throw Exception('Not authenticated');

    try {
      await _sb
          .from('profiles')
          .update({
        'is_official': isOfficial,
        'updated_at': DateTime.now().toIso8601String(),
      })
          .eq('id', userId);
    } catch (e) {
      throw Exception('Failed to set official status: $e');
    }
  }

  /// 获取用户验证类型：只看 profiles 字段
  Future<String> getUserVerificationType([String? userId]) async {
    final targetId = userId ?? uid;
    if (targetId == null) return 'none';

    try {
      final profile = await _sb
          .from('profiles')
          .select('is_official, is_email_verified')
          .eq('id', targetId)
          .maybeSingle();

      if (profile == null) return 'none';
      if (profile['is_official'] == true) return 'official';
      if (profile['is_email_verified'] == true) return 'verified';
      return 'none';
    } catch (_) {
      return 'none';
    }
  }

  /// 批量获取验证状态
  Future<Map<String, String>> getBatchUserVerificationTypes(
      List<String> userIds) async {
    final result = <String, String>{};
    for (final userId in userIds) {
      try {
        result[userId] = await getUserVerificationType(userId);
      } catch (_) {
        result[userId] = 'none';
      }
    }
    return result;
  }

  /// 获取带验证信息的用户资料：结果里附带 `verification_type`
  Future<Map<String, dynamic>?> getUserProfileWithVerification(
      [String? userId]) async {
    final targetId = userId ?? uid;
    if (targetId == null) return null;

    try {
      final profile =
      await _sb.from('profiles').select().eq('id', targetId).maybeSingle();
      if (profile == null) return null;

      final data = Map<String, dynamic>.from(profile);
      data['verification_type'] = await getUserVerificationType(targetId);
      return data;
    } catch (_) {
      return null;
    }
  }

  // ========== Favorites ==========

  Future<List<Map<String, dynamic>>> getUserFavorites() async {
    final id = uid;
    if (id == null) return [];
    try {
      final rows = await _sb
          .from('favorites')
          .select()
          .eq('user_id', id)
          .order('created_at', ascending: false);
      return rows
          .map<Map<String, dynamic>>((e) => Map<String, dynamic>.from(e))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<bool> toggleFavorite({required String listingId}) async {
    final id = uid;
    if (id == null) throw Exception('Not logged in');

    try {
      final exist = await _sb
          .from('favorites')
          .select()
          .eq('user_id', id)
          .eq('listing_id', listingId)
          .maybeSingle();

      if (exist != null) {
        await _sb
            .from('favorites')
            .delete()
            .eq('user_id', id)
            .eq('listing_id', listingId);
        return false;
      } else {
        await _sb.from('favorites').insert({
          'user_id': id,
          'listing_id': listingId,
          'created_at': DateTime.now().toIso8601String(),
        });
        return true;
      }
    } catch (e) {
      throw Exception('Failed to toggle favorite: $e');
    }
  }

  // ========== Helpers ==========

  String _fileExt(String path) {
    final dot = path.lastIndexOf('.');
    if (dot == -1 || dot == path.length - 1) return '.jpg';
    final ext = path.substring(dot);
    if (ext.length > 5) return '.jpg';
    return ext;
  }
}