// lib/services/wishlist_service.dart
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/foundation.dart';

class WishlistService {
  static final SupabaseClient _client = Supabase.instance.client;
  static const String _tableName = 'wishlists';

  static void _debugPrint(String message) {
    if (kDebugMode) {
      print(message);
    }
  }

  /// 添加商品到wishlist
  static Future<bool> addToWishlist({
    required String userId,
    required String listingId,
  }) async {
    try {
      _debugPrint('Adding to wishlist: userId=$userId, listingId=$listingId');

      // 检查是否已经在wishlist中
      final existing = await _client
          .from(_tableName)
          .select('id')
          .eq('user_id', userId)
          .eq('listing_id', listingId)
          .maybeSingle();

      if (existing != null) {
        _debugPrint('Item already in wishlist');
        return false;
      }

      // 添加到wishlist
      final result = await _client.from(_tableName).insert({
        'user_id': userId,
        'listing_id': listingId,
        'created_at': DateTime.now().toIso8601String(),
      }).select();

      _debugPrint('Insert result: $result');
      return result.isNotEmpty;
    } catch (e) {
      _debugPrint('Error adding to wishlist: $e');
      return false;
    }
  }

  /// 从wishlist中移除商品
  static Future<bool> removeFromWishlist({
    required String userId,
    required String listingId,
  }) async {
    try {
      _debugPrint('Removing from wishlist: userId=$userId, listingId=$listingId');

      await _client
          .from(_tableName)
          .delete()
          .eq('user_id', userId)
          .eq('listing_id', listingId);

      _debugPrint('Successfully removed from wishlist');
      return true;
    } catch (e) {
      _debugPrint('Error removing from wishlist: $e');
      return false;
    }
  }

  /// 检查商品是否在wishlist中
  static Future<bool> isInWishlist({
    required String userId,
    required String listingId,
  }) async {
    try {
      _debugPrint('Checking wishlist status: userId=$userId, listingId=$listingId');

      final result = await _client
          .from(_tableName)
          .select('id')
          .eq('user_id', userId)
          .eq('listing_id', listingId)
          .maybeSingle();

      final isInWishlist = result != null;
      _debugPrint('Is in wishlist: $isInWishlist');
      return isInWishlist;
    } catch (e) {
      _debugPrint('Error checking wishlist: $e');
      return false;
    }
  }

  /// 获取用户的wishlist数量
  static Future<int> getWishlistCount({required String userId}) async {
    try {
      _debugPrint('Getting wishlist count for user: $userId');

      final data = await _client
          .from(_tableName)
          .select('id')
          .eq('user_id', userId);

      final count = (data as List).length;
      _debugPrint('Wishlist count: $count');
      return count;
    } catch (e) {
      _debugPrint('Error getting wishlist count: $e');
      return 0;
    }
  }

  /// 获取用户的wishlist商品列表（简化版本）
  static Future<List<Map<String, dynamic>>> getUserWishlist({
    required String userId,
    int limit = 50,
    int offset = 0,
  }) async {
    try {
      _debugPrint('Getting user wishlist: userId=$userId, limit=$limit, offset=$offset');

      // 先获取wishlist记录
      final wishlistData = await _client
          .from(_tableName)
          .select('*')
          .eq('user_id', userId)
          .order('created_at', ascending: false)
          .range(offset, offset + limit - 1);

      _debugPrint('Wishlist raw data: $wishlistData');

      if (wishlistData.isEmpty) {
        _debugPrint('No wishlist items found');
        return [];
      }

      // 为每个wishlist项目单独获取商品信息
      final result = <Map<String, dynamic>>[];
      for (final wishlistItem in wishlistData) {
        final listingId = wishlistItem['listing_id'];
        if (listingId != null) {
          try {
            final listing = await _client
                .from('listings')
                .select('id, title, price, city, images, image_urls, status, is_active, seller_name, category, description')
                .eq('id', listingId)
                .eq('is_active', true)
                .maybeSingle();

            if (listing != null) {
              result.add({
                'id': wishlistItem['id'],
                'created_at': wishlistItem['created_at'],
                'listing_id': listingId,
                'listings': listing,
              });
              _debugPrint('Successfully loaded listing data for item $listingId');
            }
          } catch (e) {
            _debugPrint('Error fetching listing $listingId: $e');
          }
        }
      }

      _debugPrint('Final result: ${result.length} items');
      return result;
    } catch (e) {
      _debugPrint('Error getting user wishlist: $e');
      return [];
    }
  }

  /// 获取用户的wishlist商品列表（简单版本，不关联查询）
  static Future<List<Map<String, dynamic>>> getUserWishlistSimple({
    required String userId,
    int limit = 50,
    int offset = 0,
  }) async {
    try {
      _debugPrint('Getting user wishlist simple: userId=$userId, limit=$limit, offset=$offset');

      final data = await _client
          .from(_tableName)
          .select('*')
          .eq('user_id', userId)
          .order('created_at', ascending: false)
          .range(offset, offset + limit - 1);

      final result = List<Map<String, dynamic>>.from(data);
      _debugPrint('Got ${result.length} wishlist items');
      return result;
    } catch (e) {
      _debugPrint('Error getting user wishlist simple: $e');
      return [];
    }
  }

  /// 切换wishlist状态（添加或移除）
  static Future<bool> toggleWishlist({
    required String userId,
    required String listingId,
  }) async {
    try {
      _debugPrint('Toggling wishlist: userId=$userId, listingId=$listingId');

      // 先检查当前状态
      final isCurrentlyInWishlist = await isInWishlist(
        userId: userId,
        listingId: listingId,
      );

      _debugPrint('Currently in wishlist: $isCurrentlyInWishlist');

      bool success;
      if (isCurrentlyInWishlist) {
        // 如果已在wishlist中，则移除
        success = await removeFromWishlist(
          userId: userId,
          listingId: listingId,
        );
        _debugPrint('Remove operation success: $success');
        return success ? false : isCurrentlyInWishlist; // 成功移除返回false
      } else {
        // 如果不在wishlist中，则添加
        success = await addToWishlist(
          userId: userId,
          listingId: listingId,
        );
        _debugPrint('Add operation success: $success');
        return success ? true : isCurrentlyInWishlist; // 成功添加返回true
      }
    } catch (e) {
      _debugPrint('Error toggling wishlist: $e');
      // 如果出错，返回当前状态不变
      return await isInWishlist(userId: userId, listingId: listingId);
    }
  }

  /// 获取用户wishlist数量的便捷方法
  static Future<int> getUserWishlistCount(String userId) async {
    return await getWishlistCount(userId: userId);
  }

  /// 批量删除用户的wishlist项（可选功能）
  static Future<bool> clearUserWishlist({required String userId}) async {
    try {
      _debugPrint('Clearing wishlist for user: $userId');

      await _client
          .from(_tableName)
          .delete()
          .eq('user_id', userId);

      _debugPrint('Successfully cleared wishlist');
      return true;
    } catch (e) {
      _debugPrint('Error clearing wishlist: $e');
      return false;
    }
  }

  /// 测试数据库连接和权限
  static Future<bool> testConnection({required String userId}) async {
    try {
      _debugPrint('Testing wishlist database connection...');

      // 尝试读取用户的wishlist
      final data = await _client
          .from(_tableName)
          .select('id')
          .eq('user_id', userId)
          .limit(1);

      _debugPrint('Connection test successful');
      return true;
    } catch (e) {
      _debugPrint('Connection test failed: $e');
      return false;
    }
  }
}