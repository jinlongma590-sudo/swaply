// lib/services/coupon_service.dart - UUID版本（修复FetchOptions问题）
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/foundation.dart';
import 'package:swaply/models/coupon.dart';
import 'dart:math';

/// 优惠券服务类 - UUID版本
class CouponService {
  static final SupabaseClient _client = Supabase.instance.client;
  static const String _tableName = 'coupons';
  static const String _pinnedAdsTableName = 'pinned_ads';

  /// 获取当前用户ID
  static String? get _currentUserId => _client.auth.currentUser?.id;

  /// 调试打印
  static void _debugPrint(String message) {
    if (kDebugMode) {
      print('[CouponService] $message');
    }
  }

  /// 生成优惠券代码
  static String _generateCouponCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    final random = Random();
    return List.generate(8, (index) => chars[random.nextInt(chars.length)]).join();
  }

  /// 创建优惠券（管理员功能）
  static Future<CouponModel?> createCoupon({
    required String userId,
    required CouponType type,
    required String title,
    required String description,
    required int durationDays,
    int maxUses = 1,
    Map<String, dynamic>? metadata,
  }) async {
    try {
      _debugPrint('Creating coupon for user: $userId, type: ${type.value}');

      final code = _generateCouponCode();
      final now = DateTime.now();
      final expiresAt = now.add(Duration(days: durationDays));

      final data = {
        'code': code,
        'user_id': userId,
        'type': type.value,
        'status': CouponStatus.active.value,
        'title': title,
        'description': description,
        'duration_days': durationDays,
        'max_uses': maxUses,
        'used_count': 0,
        'created_at': now.toIso8601String(),
        'expires_at': expiresAt.toIso8601String(),
        'metadata': metadata,
      };

      final result = await _client.from(_tableName).insert(data).select().single();

      _debugPrint('Coupon created successfully: ${result['id']}');
      return CouponModel.fromMap(result);
    } catch (e) {
      _debugPrint('Error creating coupon: $e');
      return null;
    }
  }

  /// 批量创建置顶体验卡
  static Future<List<CouponModel>> createPinnedCoupons({
    required List<String> userIds,
    int durationDays = 7,
    String title = 'Pinned Ad Experience Card',
    String description = 'Pin your ad to the top of category listings for better visibility',
  }) async {
    try {
      _debugPrint('Creating pinned coupons for ${userIds.length} users');

      final List<CouponModel> createdCoupons = [];

      for (final userId in userIds) {
        final coupon = await createCoupon(
          userId: userId,
          type: CouponType.pinned,
          title: title,
          description: description,
          durationDays: durationDays,
          maxUses: 1,
        );

        if (coupon != null) {
          createdCoupons.add(coupon);
        }
      }

      _debugPrint('Created ${createdCoupons.length} pinned coupons');
      return createdCoupons;
    } catch (e) {
      _debugPrint('Error creating pinned coupons: $e');
      return [];
    }
  }

  /// 获取用户的优惠券
  static Future<List<CouponModel>> getUserCoupons({
    String? userId,
    CouponType? type,
    CouponStatus? status,
    bool onlyUsable = false,
  }) async {
    try {
      final targetUserId = userId ?? _currentUserId;
      if (targetUserId == null) return [];

      _debugPrint('Fetching coupons for user: $targetUserId');

      var query = _client
          .from(_tableName)
          .select('*')
          .eq('user_id', targetUserId);

      if (type != null) {
        query = query.eq('type', type.value);
      }

      if (status != null) {
        query = query.eq('status', status.value);
      }

      if (onlyUsable) {
        query = query
            .eq('status', CouponStatus.active.value)
            .gte('expires_at', DateTime.now().toIso8601String());
      }

      final List<dynamic> data = await query.order('created_at', ascending: false);

      final coupons = data.map<CouponModel>((e) => CouponModel.fromMap(Map.from(e))).toList();

      // 过滤掉已用完的优惠券（如果onlyUsable为true）
      if (onlyUsable) {
        return coupons.where((coupon) => coupon.isUsable).toList();
      }

      return coupons;
    } catch (e) {
      _debugPrint('Error fetching user coupons: $e');
      return [];
    }
  }

  /// 使用优惠券将listing置顶
  static Future<bool> useCouponForPinning({
    required String couponId,
    required String listingId, // 修复：改为 String 类型（UUID）
  }) async {
    try {
      final userId = _currentUserId;
      if (userId == null) {
        _debugPrint('No authenticated user found');
        return false;
      }

      _debugPrint('Using coupon $couponId for listing $listingId');

      // 获取优惠券信息
      final couponData = await _client
          .from(_tableName)
          .select('*')
          .eq('id', couponId)
          .eq('user_id', userId)
          .single();

      final coupon = CouponModel.fromMap(couponData);

      // 验证优惠券是否可用
      if (!coupon.isUsable) {
        _debugPrint('Coupon is not usable: ${coupon.statusDescription}');
        return false;
      }

      if (coupon.type != CouponType.pinned) {
        _debugPrint('Coupon is not a pinned type');
        return false;
      }

      // 获取listing信息
      final listingData = await _client
          .from('listings')
          .select('id, title, category, city, user_id')
          .eq('id', listingId)
          .eq('user_id', userId)
          .single();

      final category = listingData['category'];
      final city = listingData['city'];

      // 检查该分类是否已有太多置顶广告
      final existingPinnedCount = await _countPinnedAdsInCategory(category, city);
      const maxPinnedPerCategory = 5; // 可配置

      if (existingPinnedCount >= maxPinnedPerCategory) {
        _debugPrint('Category $category already has maximum pinned ads');
        // 移除最旧的置顶广告
        await _removeOldestPinnedAd(category, city);
      }

      // 开始事务：更新优惠券状态并创建置顶记录
      final now = DateTime.now();
      final pinnedUntil = now.add(Duration(days: coupon.durationDays));

      // 更新优惠券状态
      await _client
          .from(_tableName)
          .update({
        'status': CouponStatus.used.value,
        'used_count': coupon.usedCount + 1,
        'used_at': now.toIso8601String(),
        'listing_id': listingId,
      })
          .eq('id', couponId);

      // 创建置顶广告记录
      await _client.from(_pinnedAdsTableName).insert({
        'listing_id': listingId,
        'user_id': userId,
        'category': category,
        'city': city,
        'pinned_at': now.toIso8601String(),
        'pinned_until': pinnedUntil.toIso8601String(),
        'coupon_id': couponId,
        'status': 'active',
      });

      _debugPrint('Successfully pinned listing $listingId until ${pinnedUntil.toIso8601String()}');
      return true;
    } catch (e) {
      _debugPrint('Error using coupon for pinning: $e');
      return false;
    }
  }

  /// 计算分类中的置顶广告数量 - 修复版本
  static Future<int> _countPinnedAdsInCategory(String category, String? city) async {
    try {
      var query = _client
          .from(_pinnedAdsTableName)
          .select('id') // 只选择id字段
          .eq('category', category)
          .eq('status', 'active')
          .gte('pinned_until', DateTime.now().toIso8601String());

      if (city != null) {
        query = query.eq('city', city);
      }

      final response = await query;
      return (response as List).length; // 修复：直接使用 List 长度
    } catch (e) {
      _debugPrint('Error counting pinned ads: $e');
      return 0;
    }
  }

  /// 移除最旧的置顶广告
  static Future<void> _removeOldestPinnedAd(String category, String? city) async {
    try {
      var query = _client
          .from(_pinnedAdsTableName)
          .select('id')
          .eq('category', category)
          .eq('status', 'active');

      if (city != null) {
        query = query.eq('city', city);
      }

      final oldestPinned = await query
          .order('pinned_at', ascending: true)
          .limit(1)
          .maybeSingle();

      if (oldestPinned != null) {
        await _client
            .from(_pinnedAdsTableName)
            .update({'status': 'expired'})
            .eq('id', oldestPinned['id']);

        _debugPrint('Removed oldest pinned ad: ${oldestPinned['id']}');
      }
    } catch (e) {
      _debugPrint('Error removing oldest pinned ad: $e');
    }
  }

  /// 获取置顶广告列表（用于显示）
  static Future<List<Map<String, dynamic>>> getPinnedAds({
    String? category,
    String? city,
    int limit = 10,
  }) async {
    try {
      _debugPrint('Fetching pinned ads for category: $category, city: $city');

      var query = _client
          .from(_pinnedAdsTableName)
          .select('''
            *,
            listings!inner(id, title, price, images, description, user_id, city, category)
          ''')
          .eq('status', 'active')
          .gte('pinned_until', DateTime.now().toIso8601String());

      if (category != null) {
        query = query.eq('category', category);
      }

      if (city != null) {
        query = query.eq('city', city);
      }

      final List<dynamic> data = await query
          .order('pinned_at', ascending: false)
          .limit(limit);

      _debugPrint('Found ${data.length} pinned ads');
      return data.map<Map<String, dynamic>>((e) => Map.from(e)).toList();
    } catch (e) {
      _debugPrint('Error fetching pinned ads: $e');
      return [];
    }
  }

  /// 获取用户的置顶广告
  static Future<List<Map<String, dynamic>>> getUserPinnedAds({String? userId}) async {
    try {
      final targetUserId = userId ?? _currentUserId;
      if (targetUserId == null) return [];

      _debugPrint('Fetching pinned ads for user: $targetUserId');

      final List<dynamic> data = await _client
          .from(_pinnedAdsTableName)
          .select('''
            *,
            listings!inner(id, title, price, images, description, city, category)
          ''')
          .eq('user_id', targetUserId)
          .order('pinned_at', ascending: false);

      return data.map<Map<String, dynamic>>((e) => Map.from(e)).toList();
    } catch (e) {
      _debugPrint('Error fetching user pinned ads: $e');
      return [];
    }
  }

  /// 检查listing是否被置顶
  static Future<Map<String, dynamic>?> getListingPinnedStatus(String listingId) async {
    try {
      final data = await _client
          .from(_pinnedAdsTableName)
          .select('*')
          .eq('listing_id', listingId)
          .eq('status', 'active')
          .gte('pinned_until', DateTime.now().toIso8601String())
          .maybeSingle();

      return data != null ? Map<String, dynamic>.from(data) : null;
    } catch (e) {
      _debugPrint('Error checking listing pinned status: $e');
      return null;
    }
  }

  /// 取消置顶
  static Future<bool> unpinListing(String listingId) async {
    try {
      final userId = _currentUserId;
      if (userId == null) return false;

      _debugPrint('Unpinning listing: $listingId');

      await _client
          .from(_pinnedAdsTableName)
          .update({'status': 'cancelled'})
          .eq('listing_id', listingId)
          .eq('user_id', userId);

      return true;
    } catch (e) {
      _debugPrint('Error unpinning listing: $e');
      return false;
    }
  }

  /// 清理过期的置顶广告
  static Future<int> cleanupExpiredPinnedAds() async {
    try {
      _debugPrint('Cleaning up expired pinned ads...');

      final result = await _client
          .from(_pinnedAdsTableName)
          .update({'status': 'expired'})
          .eq('status', 'active')
          .lt('pinned_until', DateTime.now().toIso8601String())
          .select('id');

      final expiredCount = (result as List).length;
      _debugPrint('Cleaned up $expiredCount expired pinned ads');
      return expiredCount;
    } catch (e) {
      _debugPrint('Error cleaning up expired pinned ads: $e');
      return 0;
    }
  }

  /// 撤销优惠券（管理员功能）
  static Future<bool> revokeCoupon(String couponId) async {
    try {
      _debugPrint('Revoking coupon: $couponId');

      await _client
          .from(_tableName)
          .update({
        'status': CouponStatus.revoked.value,
        'updated_at': DateTime.now().toIso8601String(),
      })
          .eq('id', couponId);

      return true;
    } catch (e) {
      _debugPrint('Error revoking coupon: $e');
      return false;
    }
  }

  /// 获取优惠券统计
  static Future<Map<String, int>> getCouponStats({String? userId}) async {
    try {
      final targetUserId = userId ?? _currentUserId;
      if (targetUserId == null) return {};

      _debugPrint('Fetching coupon stats for user: $targetUserId');

      final coupons = await getUserCoupons(userId: targetUserId);

      final stats = {
        'total_coupons': coupons.length,
        'active_coupons': coupons.where((c) => c.status == CouponStatus.active).length,
        'used_coupons': coupons.where((c) => c.status == CouponStatus.used).length,
        'expired_coupons': coupons.where((c) => c.isExpired).length,
        'pinned_coupons': coupons.where((c) => c.type == CouponType.pinned).length,
        'usable_coupons': coupons.where((c) => c.isUsable).length,
      };

      _debugPrint('Coupon stats: $stats');
      return stats;
    } catch (e) {
      _debugPrint('Error fetching coupon stats: $e');
      return {};
    }
  }

  /// 测试连接
  static Future<bool> testConnection() async {
    try {
      _debugPrint('Testing coupon service connection...');
      await getCouponStats();
      _debugPrint('Coupon service connection test successful');
      return true;
    } catch (e) {
      _debugPrint('Coupon service connection test failed: $e');
      return false;
    }
  }
}