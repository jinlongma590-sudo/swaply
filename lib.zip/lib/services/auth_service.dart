// lib/services/auth_service.dart
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthService {
  final _sb = Supabase.instance.client;

  User? get currentUser => _sb.auth.currentUser;
  bool get isLoggedIn => currentUser != null;

  Future<AuthResponse> signUpWithEmailPassword({
    required String email,
    required String password,
    String? fullName,
    String? phone,
  }) async {
    final res = await _sb.auth.signUp(
      email: email,
      password: password,
      data: {
        if (fullName != null) 'name': fullName,
        if (fullName != null) 'full_name': fullName,
        if (phone != null) 'phone': phone,
      },
    );

    // 创建资料
    if (res.user != null) {
      await _createUserProfile(
        userId: res.user!.id,
        displayName: fullName,
        phone: phone,
      );
    }
    return res;
  }

  Future<AuthResponse> signInWithEmailPassword({
    required String email,
    required String password,
  }) {
    return _sb.auth.signInWithPassword(email: email, password: password);
  }

  /// 使用 OAuth 登录（用 OAuthProvider，避免 “Undefined name 'Provider'”）
  Future<void> signInWithGoogle() async {
    await _sb.auth.signInWithOAuth(
      OAuthProvider.google,
      redirectTo: 'io.supabase.swaply://login-callback/',
    );
  }

  Future<void> signInWithFacebook() async {
    await _sb.auth.signInWithOAuth(
      OAuthProvider.facebook,
      redirectTo: 'io.supabase.swaply://login-callback/',
    );
  }

  Future<AuthResponse> signInAnonymously() {
    return _sb.auth.signInAnonymously();
  }

  Future<void> resetPassword(String email) async {
    await _sb.auth.resetPasswordForEmail(
      email,
      redirectTo: 'io.supabase.swaply://reset-password/',
    );
  }

  Future<UserResponse> updatePassword(String newPassword) {
    return _sb.auth.updateUser(UserAttributes(password: newPassword));
  }

  Future<void> signOut() async {
    await _sb.auth.signOut();
  }

  /// 注册成功后补一条 user_profiles
  Future<void> _createUserProfile({
    required String userId,
    String? displayName,
    String? phone,
  }) async {
    try {
      await _sb.from('user_profiles').insert({
        'user_id': userId,
        if (displayName != null) 'display_name': displayName,
        if (phone != null) 'phone': phone,
        'created_at': DateTime.now().toIso8601String(),
      });
    } catch (_) {}
  }

  String _handleAuthError(Object e) => e.toString();
}
