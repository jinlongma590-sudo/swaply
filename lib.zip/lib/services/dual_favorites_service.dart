// lib/services/dual_favorites_service.dart
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/foundation.dart';

/// 双重收藏服务 - 同时管理 favorites 和 wishlists 表
/// 确保两个表的数据保持同步
class DualFavoritesService {
  static final SupabaseClient _client = Supabase.instance.client;
  static const String _favoritesTable = 'favorites';
  static const String _wishlistsTable = 'wishlists';

  static void _debugPrint(String message) {
    if (kDebugMode) {
      print('[DualFavoritesService] $message');
    }
  }

  /// 同时添加到收藏和心愿单
  static Future<bool> addToFavorites({
    required String userId,
    required String listingId,
  }) async {
    try {
      _debugPrint('Adding to both favorites and wishlists: userId=$userId, listingId=$listingId');

      // 使用事务确保两个操作都成功
      final now = DateTime.now().toIso8601String();

      // 先检查是否已经存在
      final existingFavorite = await _client
          .from(_favoritesTable)
          .select('id')
          .eq('user_id', userId)
          .eq('listing_id', listingId)
          .maybeSingle();

      if (existingFavorite != null) {
        _debugPrint('Item already in favorites');
        return false; // 已经存在，不需要重复添加
      }

      // 同时插入到两个表
      final favoriteData = {
        'user_id': userId,
        'listing_id': listingId,
        'created_at': now,
      };

      final wishlistData = {
        'user_id': userId,
        'listing_id': listingId,
        'created_at': now,
      };

      // 插入到 favorites 表
      await _client.from(_favoritesTable).insert(favoriteData);

      // 插入到 wishlists 表
      await _client.from(_wishlistsTable).insert(wishlistData);

      _debugPrint('Successfully added to both favorites and wishlists');
      return true;

    } catch (e) {
      _debugPrint('Error adding to favorites: $e');

      // 如果出错，尝试清理可能插入成功的数据
      try {
        await removeFromFavorites(userId: userId, listingId: listingId);
      } catch (cleanupError) {
        _debugPrint('Error during cleanup: $cleanupError');
      }

      return false;
    }
  }

  /// 同时从收藏和心愿单中移除
  static Future<bool> removeFromFavorites({
    required String userId,
    required String listingId,
  }) async {
    try {
      _debugPrint('Removing from both favorites and wishlists: userId=$userId, listingId=$listingId');

      // 从 favorites 表删除
      await _client
          .from(_favoritesTable)
          .delete()
          .eq('user_id', userId)
          .eq('listing_id', listingId);

      // 从 wishlists 表删除
      await _client
          .from(_wishlistsTable)
          .delete()
          .eq('user_id', userId)
          .eq('listing_id', listingId);

      _debugPrint('Successfully removed from both favorites and wishlists');
      return true;

    } catch (e) {
      _debugPrint('Error removing from favorites: $e');
      return false;
    }
  }

  /// 检查是否在收藏中（检查 favorites 表）
  static Future<bool> isInFavorites({
    required String userId,
    required String listingId,
  }) async {
    try {
      _debugPrint('Checking favorites status: userId=$userId, listingId=$listingId');

      final result = await _client
          .from(_favoritesTable)
          .select('id')
          .eq('user_id', userId)
          .eq('listing_id', listingId)
          .maybeSingle();

      final isInFavorites = result != null;
      _debugPrint('Is in favorites: $isInFavorites');
      return isInFavorites;

    } catch (e) {
      _debugPrint('Error checking favorites: $e');
      return false;
    }
  }

  /// 切换收藏状态（同时操作两个表）
  static Future<bool> toggleFavorite({
    required String userId,
    required String listingId,
  }) async {
    try {
      _debugPrint('Toggling favorite: userId=$userId, listingId=$listingId');

      // 先检查当前状态
      final isCurrentlyInFavorites = await isInFavorites(
        userId: userId,
        listingId: listingId,
      );

      _debugPrint('Currently in favorites: $isCurrentlyInFavorites');

      bool success;
      if (isCurrentlyInFavorites) {
        // 如果已在收藏中，则移除
        success = await removeFromFavorites(
          userId: userId,
          listingId: listingId,
        );
        _debugPrint('Remove operation success: $success');
        return success ? false : isCurrentlyInFavorites; // 成功移除返回false
      } else {
        // 如果不在收藏中，则添加
        success = await addToFavorites(
          userId: userId,
          listingId: listingId,
        );
        _debugPrint('Add operation success: $success');
        return success ? true : isCurrentlyInFavorites; // 成功添加返回true
      }

    } catch (e) {
      _debugPrint('Error toggling favorite: $e');
      // 如果出错，返回当前状态不变
      return await isInFavorites(userId: userId, listingId: listingId);
    }
  }

  /// 获取用户的收藏列表（从 favorites 表，带商品详情）
  static Future<List<Map<String, dynamic>>> getUserFavorites({
    required String userId,
    int limit = 50,
    int offset = 0,
  }) async {
    try {
      _debugPrint('Getting user favorites: userId=$userId, limit=$limit, offset=$offset');

      // 先获取收藏记录
      final favoritesData = await _client
          .from(_favoritesTable)
          .select('*')
          .eq('user_id', userId)
          .order('created_at', ascending: false)
          .range(offset, offset + limit - 1);

      _debugPrint('Favorites raw data: $favoritesData');

      if (favoritesData.isEmpty) {
        _debugPrint('No favorites found');
        return [];
      }

      // 为每个收藏项目单独获取商品信息
      final result = <Map<String, dynamic>>[];
      for (final favoriteItem in favoritesData) {
        final listingId = favoriteItem['listing_id'];
        if (listingId != null) {
          try {
            final listing = await _client
                .from('listings')
                .select('id, title, price, city, images, image_urls, status, is_active, seller_name, category, description, created_at')
                .eq('id', listingId)
                .eq('is_active', true)
                .maybeSingle();

            if (listing != null) {
              result.add({
                'id': favoriteItem['id'],
                'created_at': favoriteItem['created_at'],
                'listing_id': listingId,
                'listing': listing,
              });
              _debugPrint('Successfully loaded listing data for item $listingId');
            }
          } catch (e) {
            _debugPrint('Error fetching listing $listingId: $e');
          }
        }
      }

      _debugPrint('Final favorites result: ${result.length} items');
      return result;

    } catch (e) {
      _debugPrint('Error getting user favorites: $e');
      return [];
    }
  }

  /// 获取用户的心愿单列表（从 wishlists 表，带商品详情）
  static Future<List<Map<String, dynamic>>> getUserWishlist({
    required String userId,
    int limit = 50,
    int offset = 0,
  }) async {
    try {
      _debugPrint('Getting user wishlist: userId=$userId, limit=$limit, offset=$offset');

      // 先获取心愿单记录
      final wishlistData = await _client
          .from(_wishlistsTable)
          .select('*')
          .eq('user_id', userId)
          .order('created_at', ascending: false)
          .range(offset, offset + limit - 1);

      _debugPrint('Wishlist raw data: $wishlistData');

      if (wishlistData.isEmpty) {
        _debugPrint('No wishlist items found');
        return [];
      }

      // 为每个心愿单项目单独获取商品信息
      final result = <Map<String, dynamic>>[];
      for (final wishlistItem in wishlistData) {
        final listingId = wishlistItem['listing_id'];
        if (listingId != null) {
          try {
            final listing = await _client
                .from('listings')
                .select('id, title, price, city, images, image_urls, status, is_active, seller_name, category, description, created_at')
                .eq('id', listingId)
                .eq('is_active', true)
                .maybeSingle();

            if (listing != null) {
              result.add({
                'id': wishlistItem['id'],
                'created_at': wishlistItem['created_at'],
                'listing_id': listingId,
                'listings': listing, // 注意这里用的是 listings 不是 listing，保持与其他地方一致
              });
              _debugPrint('Successfully loaded listing data for wishlist item $listingId');
            }
          } catch (e) {
            _debugPrint('Error fetching listing for wishlist $listingId: $e');
          }
        }
      }

      _debugPrint('Final wishlist result: ${result.length} items');
      return result;

    } catch (e) {
      _debugPrint('Error getting user wishlist: $e');
      return [];
    }
  }

  /// 获取收藏数量
  static Future<int> getFavoritesCount({required String userId}) async {
    try {
      _debugPrint('Getting favorites count for user: $userId');

      final data = await _client
          .from(_favoritesTable)
          .select('id')
          .eq('user_id', userId);

      final count = (data as List).length;
      _debugPrint('Favorites count: $count');
      return count;

    } catch (e) {
      _debugPrint('Error getting favorites count: $e');
      return 0;
    }
  }

  /// 获取心愿单数量
  static Future<int> getWishlistCount({required String userId}) async {
    try {
      _debugPrint('Getting wishlist count for user: $userId');

      final data = await _client
          .from(_wishlistsTable)
          .select('id')
          .eq('user_id', userId);

      final count = (data as List).length;
      _debugPrint('Wishlist count: $count');
      return count;

    } catch (e) {
      _debugPrint('Error getting wishlist count: $e');
      return 0;
    }
  }

  /// 清空用户的收藏和心愿单
  static Future<bool> clearUserFavorites({required String userId}) async {
    try {
      _debugPrint('Clearing all favorites and wishlists for user: $userId');

      // 清空 favorites 表
      await _client
          .from(_favoritesTable)
          .delete()
          .eq('user_id', userId);

      // 清空 wishlists 表
      await _client
          .from(_wishlistsTable)
          .delete()
          .eq('user_id', userId);

      _debugPrint('Successfully cleared all favorites and wishlists');
      return true;

    } catch (e) {
      _debugPrint('Error clearing favorites: $e');
      return false;
    }
  }

  /// 获取用户收藏的商品ID集合（用于快速检查）
  static Future<Set<String>> getUserFavoriteListingIds({
    required String userId,
  }) async {
    try {
      _debugPrint('Getting user favorite listing IDs for user: $userId');

      final data = await _client
          .from(_favoritesTable)
          .select('listing_id')
          .eq('user_id', userId);

      final listingIds = <String>{};
      for (final item in data) {
        final listingId = item['listing_id']?.toString();
        if (listingId != null) {
          listingIds.add(listingId);
        }
      }

      _debugPrint('Found ${listingIds.length} favorite listing IDs');
      return listingIds;

    } catch (e) {
      _debugPrint('Error getting favorite listing IDs: $e');
      return <String>{};
    }
  }

  /// 数据同步 - 确保 favorites 和 wishlists 表数据一致
  static Future<bool> syncFavoritesAndWishlists({required String userId}) async {
    try {
      _debugPrint('Syncing favorites and wishlists for user: $userId');

      // 获取 favorites 表中的数据
      final favorites = await _client
          .from(_favoritesTable)
          .select('listing_id, created_at')
          .eq('user_id', userId);

      // 获取 wishlists 表中的数据
      final wishlists = await _client
          .from(_wishlistsTable)
          .select('listing_id, created_at')
          .eq('user_id', userId);

      final favoriteIds = favorites.map((f) => f['listing_id']?.toString()).where((id) => id != null).toSet();
      final wishlistIds = wishlists.map((w) => w['listing_id']?.toString()).where((id) => id != null).toSet();

      _debugPrint('Favorites IDs: $favoriteIds');
      _debugPrint('Wishlist IDs: $wishlistIds');

      // 找出差异
      final missingInWishlists = favoriteIds.difference(wishlistIds);
      final missingInFavorites = wishlistIds.difference(favoriteIds);

      // 添加到 wishlists 表中缺失的项目
      for (final listingId in missingInWishlists) {
        try {
          await _client.from(_wishlistsTable).insert({
            'user_id': userId,
            'listing_id': listingId,
            'created_at': DateTime.now().toIso8601String(),
          });
          _debugPrint('Added $listingId to wishlists');
        } catch (e) {
          _debugPrint('Error adding $listingId to wishlists: $e');
        }
      }

      // 添加到 favorites 表中缺失的项目
      for (final listingId in missingInFavorites) {
        try {
          await _client.from(_favoritesTable).insert({
            'user_id': userId,
            'listing_id': listingId,
            'created_at': DateTime.now().toIso8601String(),
          });
          _debugPrint('Added $listingId to favorites');
        } catch (e) {
          _debugPrint('Error adding $listingId to favorites: $e');
        }
      }

      _debugPrint('Sync completed. Added ${missingInWishlists.length} to wishlists, ${missingInFavorites.length} to favorites');
      return true;

    } catch (e) {
      _debugPrint('Error syncing favorites and wishlists: $e');
      return false;
    }
  }

  /// 格式化保存时间
  static String formatSavedTime(String? createdAt) {
    if (createdAt == null || createdAt.isEmpty) return 'Recently';

    try {
      final date = DateTime.parse(createdAt);
      final now = DateTime.now();
      final difference = now.difference(date);

      if (difference.inMinutes < 60) {
        return '${difference.inMinutes}m ago';
      } else if (difference.inHours < 24) {
        return '${difference.inHours}h ago';
      } else if (difference.inDays < 7) {
        return '${difference.inDays}d ago';
      } else if (difference.inDays < 30) {
        final weeks = (difference.inDays / 7).floor();
        return '${weeks}w ago';
      } else {
        return '${date.day}/${date.month}/${date.year}';
      }
    } catch (e) {
      _debugPrint('Error formatting time: $e');
      return 'Recently';
    }
  }

  /// 测试数据库连接
  static Future<bool> testConnection({required String userId}) async {
    try {
      _debugPrint('Testing dual favorites database connection...');

      // 测试 favorites 表
      await _client
          .from(_favoritesTable)
          .select('id')
          .eq('user_id', userId)
          .limit(1);

      // 测试 wishlists 表
      await _client
          .from(_wishlistsTable)
          .select('id')
          .eq('user_id', userId)
          .limit(1);

      _debugPrint('Dual favorites connection test successful');
      return true;

    } catch (e) {
      _debugPrint('Dual favorites connection test failed: $e');
      return false;
    }
  }

  /// 批量操作 - 添加多个商品到收藏
  static Future<List<String>> batchAddToFavorites({
    required String userId,
    required List<String> listingIds,
  }) async {
    final successfulIds = <String>[];

    for (final listingId in listingIds) {
      try {
        final success = await addToFavorites(
          userId: userId,
          listingId: listingId,
        );
        if (success) {
          successfulIds.add(listingId);
        }
      } catch (e) {
        _debugPrint('Error adding $listingId in batch operation: $e');
      }
    }

    _debugPrint('Batch add completed. Successful: ${successfulIds.length}/${listingIds.length}');
    return successfulIds;
  }

  /// 批量操作 - 从收藏中移除多个商品
  static Future<List<String>> batchRemoveFromFavorites({
    required String userId,
    required List<String> listingIds,
  }) async {
    final successfulIds = <String>[];

    for (final listingId in listingIds) {
      try {
        final success = await removeFromFavorites(
          userId: userId,
          listingId: listingId,
        );
        if (success) {
          successfulIds.add(listingId);
        }
      } catch (e) {
        _debugPrint('Error removing $listingId in batch operation: $e');
      }
    }

    _debugPrint('Batch remove completed. Successful: ${successfulIds.length}/${listingIds.length}');
    return successfulIds;
  }
}