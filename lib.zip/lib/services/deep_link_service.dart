﻿// lib/services/deep_link_service.dart
import 'dart:async';
import 'package:app_links/app_links.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:swaply/router/root_nav.dart';

class DeepLinkService {
  DeepLinkService._();
  static final DeepLinkService I = DeepLinkService._();

  AppLinks? _links;
  StreamSubscription<Uri>? _sub;
  bool _started = false;

  /// 兼容旧代码：如果外部还在调用 init，就在这里确保 _links 被创建。
  void init(GlobalKey<NavigatorState> key) {
    // 用全局 rootNavKey，不再单独存 key；这里只负责初始化 _links
    _links ??= AppLinks();
  }

  Future<void> start() async {
    if (_started) return;
    _started = true;

    // ✅ 确保无论是否调用过 init，这里一定能拿到 AppLinks 实例
    _links ??= AppLinks();

    // 兼容不同版本：尝试 getInitialAppLink → getLatestAppLink（dynamic 调用，防编译期报错）
    try {
      final l = _links;
      if (l != null) {
        Uri? initial;
        try {
          initial = await (l as dynamic).getInitialAppLink();
        } catch (_) {
          try {
            initial = await (l as dynamic).getLatestAppLink();
          } catch (_) {}
        }
        if (initial != null) {
          _dispatch(initial);
        }
      }
    } catch (e, st) {
      if (kDebugMode) {
        debugPrint('[DeepLink] initial error: $e\n$st');
      }
    }

    _sub = _links?.uriLinkStream.listen(
      _dispatch,
      onError: (e) {
        debugPrint('[DeepLink] stream error: $e');
      },
    );
  }

  void _dispatch(Uri uri) {
    debugPrint('[DeepLink] on: $uri');

    final nav = rootNavKey.currentState;
    if (nav == null) {
      debugPrint('[DeepLink] rootNavKey has no state, skip');
      return;
    }

    switch (uri.path) {
      case '/login-callback':
      // Supabase 内部处理，不在这里额外导航
        return;
      case '/reset-password':
        nav.pushNamed(
          '/reset-password',
          arguments: uri.queryParameters,
        );
        return;
      case '/listing':
        final id = uri.queryParameters['id'];
        if (id != null && id.isNotEmpty) {
          nav.pushNamed(
            '/listing',
            arguments: id,
          );
        }
        return;
      default:
        return;
    }
  }

  void dispose() {
    _sub?.cancel();
    _sub = null;
    _links = null;
    _started = false;
  }
}
