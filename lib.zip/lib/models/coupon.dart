// lib/models/coupon.dart - UUID版本
import 'package:flutter/foundation.dart';

/// 优惠券类型枚举
enum CouponType {
  pinned('pinned', 'Pinned Ad', '置顶广告'),
  featured('featured', 'Featured Ad', '精选广告'),
  boost('boost', 'Boost Ad', '推广广告'),
  premium('premium', 'Premium Listing', '高级列表');

  const CouponType(this.value, this.displayNameEn, this.displayNameZh);

  final String value;
  final String displayNameEn;
  final String displayNameZh;

  static CouponType fromString(String value) {
    return CouponType.values.firstWhere(
          (type) => type.value == value,
      orElse: () => CouponType.pinned,
    );
  }
}

/// 优惠券状态枚举
enum CouponStatus {
  active('active', 'Active', '有效'),
  used('used', 'Used', '已使用'),
  expired('expired', 'Expired', '已过期'),
  revoked('revoked', 'Revoked', '已撤销');

  const CouponStatus(this.value, this.displayNameEn, this.displayNameZh);

  final String value;
  final String displayNameEn;
  final String displayNameZh;

  static CouponStatus fromString(String value) {
    return CouponStatus.values.firstWhere(
          (status) => status.value == value,
      orElse: () => CouponStatus.active,
    );
  }
}

/// 优惠券模型 - UUID版本
class CouponModel {
  final String id;
  final String code;
  final String userId;
  final CouponType type;
  final CouponStatus status;
  final String title;
  final String description;
  final int durationDays;
  final int maxUses;
  final int usedCount;
  final DateTime createdAt;
  final DateTime expiresAt;
  final DateTime? usedAt;
  final String? listingId; // 修复：改为 String? 类型（UUID）
  final Map<String, dynamic>? metadata;

  CouponModel({
    required this.id,
    required this.code,
    required this.userId,
    required this.type,
    required this.status,
    required this.title,
    required this.description,
    required this.durationDays,
    this.maxUses = 1,
    this.usedCount = 0,
    required this.createdAt,
    required this.expiresAt,
    this.usedAt,
    this.listingId, // String? 类型
    this.metadata,
  });

  /// 从 Map 创建 CouponModel
  factory CouponModel.fromMap(Map<String, dynamic> map) {
    try {
      return CouponModel(
        id: map['id']?.toString() ?? '',
        code: map['code']?.toString() ?? '',
        userId: map['user_id']?.toString() ?? '',
        type: CouponType.fromString(map['type']?.toString() ?? 'pinned'),
        status: CouponStatus.fromString(map['status']?.toString() ?? 'active'),
        title: map['title']?.toString() ?? '',
        description: map['description']?.toString() ?? '',
        durationDays: (map['duration_days'] as num?)?.toInt() ?? 7,
        maxUses: (map['max_uses'] as num?)?.toInt() ?? 1,
        usedCount: (map['used_count'] as num?)?.toInt() ?? 0,
        createdAt: DateTime.tryParse(map['created_at']?.toString() ?? '') ?? DateTime.now(),
        expiresAt: DateTime.tryParse(map['expires_at']?.toString() ?? '') ?? DateTime.now(),
        usedAt: map['used_at'] != null ? DateTime.tryParse(map['used_at'].toString()) : null,
        listingId: map['listing_id']?.toString(), // 修复：保持为 String（UUID）
        metadata: map['metadata'] as Map<String, dynamic>?,
      );
    } catch (e) {
      if (kDebugMode) {
        print('Error parsing CouponModel: $e');
        print('Map data: $map');
      }
      rethrow;
    }
  }

  /// 转换为 Map
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'code': code,
      'user_id': userId,
      'type': type.value,
      'status': status.value,
      'title': title,
      'description': description,
      'duration_days': durationDays,
      'max_uses': maxUses,
      'used_count': usedCount,
      'created_at': createdAt.toIso8601String(),
      'expires_at': expiresAt.toIso8601String(),
      'used_at': usedAt?.toIso8601String(),
      'listing_id': listingId,
      'metadata': metadata,
    };
  }

  /// 创建副本
  CouponModel copyWith({
    String? id,
    String? code,
    String? userId,
    CouponType? type,
    CouponStatus? status,
    String? title,
    String? description,
    int? durationDays,
    int? maxUses,
    int? usedCount,
    DateTime? createdAt,
    DateTime? expiresAt,
    DateTime? usedAt,
    String? listingId,
    Map<String, dynamic>? metadata,
  }) {
    return CouponModel(
      id: id ?? this.id,
      code: code ?? this.code,
      userId: userId ?? this.userId,
      type: type ?? this.type,
      status: status ?? this.status,
      title: title ?? this.title,
      description: description ?? this.description,
      durationDays: durationDays ?? this.durationDays,
      maxUses: maxUses ?? this.maxUses,
      usedCount: usedCount ?? this.usedCount,
      createdAt: createdAt ?? this.createdAt,
      expiresAt: expiresAt ?? this.expiresAt,
      usedAt: usedAt ?? this.usedAt,
      listingId: listingId ?? this.listingId,
      metadata: metadata ?? this.metadata,
    );
  }

  // 便捷的getter方法

  /// 是否可用
  bool get isUsable {
    return status == CouponStatus.active &&
        !isExpired &&
        usedCount < maxUses;
  }

  /// 是否过期
  bool get isExpired {
    return DateTime.now().isAfter(expiresAt);
  }

  /// 是否已使用完
  bool get isUsedUp {
    return usedCount >= maxUses;
  }

  /// 剩余使用次数
  int get remainingUses {
    return (maxUses - usedCount).clamp(0, maxUses);
  }

  /// 格式化的过期时间
  String get formattedExpiryDate {
    return '${expiresAt.day}/${expiresAt.month}/${expiresAt.year}';
  }

  /// 距离过期的天数
  int get daysUntilExpiry {
    if (isExpired) return 0;
    return expiresAt.difference(DateTime.now()).inDays;
  }

  /// 状态描述
  String get statusDescription {
    if (isExpired) return 'Expired';
    if (isUsedUp) return 'Used up';
    if (status == CouponStatus.used) return 'Used';
    if (status == CouponStatus.revoked) return 'Revoked';
    return 'Active';
  }

  /// 创建时间格式化
  String get timeAgo {
    final now = DateTime.now();
    final difference = now.difference(createdAt);

    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else if (difference.inDays < 7) {
      return '${difference.inDays}d ago';
    } else {
      return '${createdAt.day}/${createdAt.month}/${createdAt.year}';
    }
  }

  @override
  String toString() {
    return 'CouponModel(id: $id, code: $code, type: ${type.value}, status: ${status.value}, title: $title)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is CouponModel &&
        other.id == id &&
        other.code == code &&
        other.userId == userId &&
        other.type == type &&
        other.status == status;
  }

  @override
  int get hashCode {
    return id.hashCode ^
    code.hashCode ^
    userId.hashCode ^
    type.hashCode ^
    status.hashCode;
  }
}

/// 置顶广告配置类
class PinnedAdConfig {
  final int maxPinnedPerCategory;
  final int defaultDurationDays;
  final Map<String, int> categoryLimits;

  const PinnedAdConfig({
    this.maxPinnedPerCategory = 3,
    this.defaultDurationDays = 7,
    this.categoryLimits = const {},
  });

  int getLimitForCategory(String category) {
    return categoryLimits[category] ?? maxPinnedPerCategory;
  }
}