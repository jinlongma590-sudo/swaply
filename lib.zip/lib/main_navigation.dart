import 'package:flutter/material.dart';
import 'package:swaply/pages/home_page.dart';
import 'package:flutter/material.dart';
import 'package:swaply/pages/home_page.dart';
import 'package:swaply/pages/sell_form_page.dart';
import 'package:swaply/pages/product_detail_page.dart';
import 'package:swaply/models/listing_store.dart';
import 'package:swaply/auth/login_screen.dart';
import 'package:swaply/auth/welcome_screen.dart';


class MainNavigation extends StatelessWidget {
  const MainNavigation({super.key});

  @override
  Widget build(BuildContext context) {
    return  MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}