// lib/widgets/verification_badge.dart
import 'package:flutter/material.dart';

enum VerificationBadgeType {
  none,
  verified,    // 普通已验证用户（profiles.is_email_verified = true）
  official,    // 官方账号（profiles.is_official = true）
}

class VerificationBadge extends StatelessWidget {
  final VerificationBadgeType type;
  final double size;
  final bool showBorder;

  const VerificationBadge({
    Key? key,
    required this.type,
    this.size = 20,
    this.showBorder = true,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (type == VerificationBadgeType.none) {
      return const SizedBox.shrink();
    }

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: _getBackgroundColor(),
        shape: BoxShape.circle,
        border: showBorder
            ? Border.all(color: Colors.white, width: 2)
            : null,
        boxShadow: showBorder
            ? [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ]
            : null,
      ),
      child: Icon(
        _getIcon(),
        color: Colors.white,
        size: size * 0.6,
      ),
    );
  }

  Color _getBackgroundColor() {
    switch (type) {
      case VerificationBadgeType.verified:
        return const Color(0xFF4CAF50); // 绿色 - 已验证
      case VerificationBadgeType.official:
        return const Color(0xFF2196F3); // 蓝色 - 官方账号
      case VerificationBadgeType.none:
        return Colors.transparent;
    }
  }

  IconData _getIcon() {
    switch (type) {
      case VerificationBadgeType.verified:
        return Icons.check;
      case VerificationBadgeType.official:
        return Icons.star;
      case VerificationBadgeType.none:
        return Icons.clear;
    }
  }

  /// 获取验证状态说明文字
  static String getVerificationText(VerificationBadgeType type) {
    switch (type) {
      case VerificationBadgeType.verified:
        return 'Verified Account';
      case VerificationBadgeType.official:
        return 'Official Account';
      case VerificationBadgeType.none:
        return 'Not Verified';
    }
  }

  /// 根据用户数据判断验证类型（只看 profiles 表字段）
  static VerificationBadgeType getVerificationTypeFromUser(
      Map<String, dynamic>? userData) {
    if (userData == null) return VerificationBadgeType.none;

    // 官方账号优先
    final isOfficial =
        userData['is_official'] == true ||
            userData['account_type'] == 'official';
    if (isOfficial) {
      return VerificationBadgeType.official;
    }

    // 邮箱验证
    final isEmailVerified = userData['is_email_verified'] == true;
    if (isEmailVerified) {
      return VerificationBadgeType.verified;
    }

    return VerificationBadgeType.none;
  }
}

/// 带验证徽章的头像组件
class VerifiedAvatar extends StatelessWidget {
  final String? avatarUrl;
  final double radius;
  final VerificationBadgeType verificationType;
  final VoidCallback? onTap;
  final IconData defaultIcon;

  const VerifiedAvatar({
    Key? key,
    this.avatarUrl,
    this.radius = 40,
    this.verificationType = VerificationBadgeType.none,
    this.onTap,
    this.defaultIcon = Icons.person,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          CircleAvatar(
            radius: radius,
            backgroundColor: Colors.grey[200],
            backgroundImage: avatarUrl != null && avatarUrl!.isNotEmpty
                ? NetworkImage(avatarUrl!)
                : null,
            child: avatarUrl == null || avatarUrl!.isEmpty
                ? Icon(
              defaultIcon,
              size: radius * 0.8,
              color: Colors.grey[600],
            )
                : null,
          ),

          // 验证徽章
          if (verificationType != VerificationBadgeType.none)
            Positioned(
              bottom: -2,
              right: -2,
              child: VerificationBadge(
                type: verificationType,
                size: radius * 0.5,
                showBorder: true,
              ),
            ),
        ],
      ),
    );
  }
}

/// 用户信息行（带验证状态）
class VerifiedUserRow extends StatelessWidget {
  final String name;
  final String? subtitle;
  final String? avatarUrl;
  final VerificationBadgeType verificationType;
  final VoidCallback? onTap;
  final Widget? trailing;

  const VerifiedUserRow({
    Key? key,
    required this.name,
    this.subtitle,
    this.avatarUrl,
    this.verificationType = VerificationBadgeType.none,
    this.onTap,
    this.trailing,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            // 头像
            VerifiedAvatar(
              avatarUrl: avatarUrl,
              radius: 20,
              verificationType: verificationType,
            ),
            const SizedBox(width: 12),

            // 用户信息
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        name,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),

                      // 内联徽章
                      if (verificationType != VerificationBadgeType.none) ...[
                        const SizedBox(width: 6),
                        VerificationBadge(
                          type: verificationType,
                          size: 16,
                          showBorder: false,
                        ),
                      ],
                    ],
                  ),

                  if (subtitle != null) ...[
                    const SizedBox(height: 2),
                    Text(
                      subtitle!,
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ],
              ),
            ),

            if (trailing != null) trailing!,
          ],
        ),
      ),
    );
  }
}

/// 验证状态标签
class VerificationStatusChip extends StatelessWidget {
  final VerificationBadgeType type;
  final bool showIcon;
  final EdgeInsets? padding;

  const VerificationStatusChip({
    Key? key,
    required this.type,
    this.showIcon = true,
    this.padding,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (type == VerificationBadgeType.none) {
      return Container(
        padding:
        padding ?? const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: Colors.grey.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.grey.withOpacity(0.3)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (showIcon) ...[
              Icon(Icons.error_outline, size: 14, color: Colors.grey[600]),
              const SizedBox(width: 4),
            ],
            Text(
              'Not Verified',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: Colors.grey[700],
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      padding:
      padding ?? const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: _getChipColor().withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _getChipColor().withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (showIcon) ...[
            VerificationBadge(
              type: type,
              size: 14,
              showBorder: false,
            ),
            const SizedBox(width: 4),
          ],
          Text(
            VerificationBadge.getVerificationText(type),
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: _getChipColor(),
            ),
          ),
        ],
      ),
    );
  }

  Color _getChipColor() {
    switch (type) {
      case VerificationBadgeType.verified:
        return const Color(0xFF4CAF50);
      case VerificationBadgeType.official:
        return const Color(0xFF2196F3);
      case VerificationBadgeType.none:
        return Colors.grey;
    }
  }
}