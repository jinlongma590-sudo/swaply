import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

// 移除 flutter_localizations 与自定义本地化
// import 'package:flutter_localizations/flutter_localizations.dart';
// import 'package:swaply/l10n/app_localizations.dart';

// 移除 Provider 与 LanguageProvider
// import 'package:provider/provider.dart';
// import 'package:swaply/providers/language_provider.dart';

import 'package:swaply/pages/home_page.dart' as swaply;
import 'package:swaply/pages/sell_form_page.dart';
import 'package:swaply/pages/product_detail_page.dart';
import 'package:swaply/models/listing_store.dart';
import 'package:swaply/auth/welcome_screen.dart';
import 'package:swaply/auth/login_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'https://rhckybselarzglkmlyqs.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJoY2t5YnNlbGFyemdsa21seXFzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTUwMTM0NTgsImV4cCI6MjA3MDU4OTQ1OH0.3I0T2DidiF-q9l2tWeHOjB31QogXHDqRtEjDn0RfVbU',
  );

  // 直接启动 App（不再使用 ChangeNotifierProvider）
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Swaply',
      debugShowCheckedModeBanner: false,
      // 纯英文，不配置任何本地化 delegate
      theme: ThemeData(
        primarySwatch: Colors.blue,
        primaryColor: const Color(0xFF2196F3),
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF2196F3),
          primary: const Color(0xFF2196F3),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF2196F3),
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF2196F3),
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        ),
      ),
      // 如果你的项目里有 WelcomeScreen，就保持欢迎页；没有就改成 MainNavigationPage()
      home: const WelcomeScreen(),
      routes: {
        '/home': (context) => const MainNavigationPage(),
        '/welcome': (context) => const WelcomeScreen(),
        '/login': (context) => const LoginScreen(),
      },
    );
  }
}

/// ========== 主导航（去本地化/去语言切换版） ==========
class MainNavigationPage extends StatefulWidget {
  final bool isGuest;

  const MainNavigationPage({Key? key, this.isGuest = false}) : super(key: key);

  @override
  _MainNavigationPageState createState() => _MainNavigationPageState();
}

class _MainNavigationPageState extends State<MainNavigationPage> {
  int _selectedIndex = 0;
  int _notificationCount = 5;

  final _homeKey = GlobalKey<NavigatorState>();
  final _savedKey = GlobalKey<NavigatorState>();
  final _sellKey = GlobalKey<NavigatorState>();
  final _notifKey = GlobalKey<NavigatorState>();
  final _profileKey = GlobalKey<NavigatorState>();

  late final List<GlobalKey<NavigatorState>> _navigatorKeys = [
    _homeKey,
    _savedKey,
    _sellKey,
    _notifKey,
    _profileKey,
  ];

  Future<bool> _onWillPop() async {
    final current = _navigatorKeys[_selectedIndex].currentState!;
    if (current.canPop()) {
      current.pop();
      return false;
    }
    return true;
  }

  void _clearNotifications() {
    setState(() => _notificationCount = 0);
  }

  void _showLoginRequired(String feature, BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Login required'),
        content: Text('Please login to use $feature.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (_) => const LoginScreen()),
              );
            },
            child: const Text('Login'),
          ),
        ],
      ),
    );
  }

  Widget _buildTabNavigator(GlobalKey<NavigatorState> key, Widget root) {
    return Navigator(
      key: key,
      onGenerateRoute: (_) => MaterialPageRoute(builder: (_) => root),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        body: IndexedStack(
          index: _selectedIndex,
          children: [
            _buildTabNavigator(_homeKey, const _HomeRoot()),
            _buildTabNavigator(_savedKey, _SavedRoot(isGuest: widget.isGuest)),
            _buildTabNavigator(_sellKey, _SellRoot(isGuest: widget.isGuest)),
            _buildTabNavigator(_notifKey, _NotificationsRoot(onClear: _clearNotifications, isGuest: widget.isGuest)),
            _buildTabNavigator(_profileKey, const _ProfileRoot()),
          ],
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _selectedIndex,
          onDestinationSelected: (i) => setState(() => _selectedIndex = i),
          labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
          destinations: [
            const NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
            const NavigationDestination(icon: Icon(Icons.bookmark_border), selectedIcon: Icon(Icons.bookmark), label: 'Saved'),
            const NavigationDestination(icon: Icon(Icons.add_box_outlined), selectedIcon: Icon(Icons.add_box), label: 'Sell'),
            NavigationDestination(
              icon: Stack(children: [
                const Icon(Icons.notifications_outlined),
                if (_notificationCount > 0 && !widget.isGuest)
                  Positioned(right: 0, top: 0, child: _Badge(count: _notificationCount)),
              ]),
              selectedIcon: const Icon(Icons.notifications),
              label: 'Notifications',
            ),
            const NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
          ],
        ),
      ),
    );
  }
}

// ====== 各 Tab 根页 ======

class _HomeRoot extends StatelessWidget {
  const _HomeRoot();

  @override
  Widget build(BuildContext context) => const swaply.HomePage();
}

class _SavedRoot extends StatelessWidget {
  final bool isGuest;
  const _SavedRoot({required this.isGuest});

  @override
  Widget build(BuildContext context) {
    if (isGuest) {
      return Scaffold(
        backgroundColor: const Color(0xFFF5F5F5),
        appBar: AppBar(title: const Text('Saved')),
        body: const Center(child: Text('Login to save your favorite items and searches.')),
      );
    }
    return Scaffold(
      appBar: AppBar(title: const Text('My Favorites')),
      body: const Center(child: Text('Favorites list will be here')),
    );
  }
}

class _SellRoot extends StatelessWidget {
  final bool isGuest;
  const _SellRoot({required this.isGuest});

  @override
  Widget build(BuildContext context) {
    if (isGuest) {
      return Scaffold(
        appBar: AppBar(title: const Text('Sell Item')),
        body: const Center(child: Text('Login to post your listings.')),
      );
    }
    return const SellFormPage();
  }
}

class _NotificationsRoot extends StatefulWidget {
  final VoidCallback onClear;
  final bool isGuest;
  const _NotificationsRoot({required this.onClear, required this.isGuest});

  @override
  State<_NotificationsRoot> createState() => _NotificationsRootState();
}

class _NotificationsRootState extends State<_NotificationsRoot> {
  final List<String> _notifications = List.generate(8, (i) => 'Notification #${i + 1}');

  void _delete(int index) => setState(() => _notifications.removeAt(index));

  @override
  void initState() {
    super.initState();
    widget.onClear(); // 进入通知页清零角标
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: [
          TextButton(
            onPressed: () => setState(() => _notifications.clear()),
            child: const Text('Clear all', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
      body: widget.isGuest
          ? const Center(child: Text('Login to receive notifications.'))
          : (_notifications.isEmpty
          ? const Center(child: Text('No notifications'))
          : ListView.separated(
        itemCount: _notifications.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (_, i) => ListTile(
          title: Text(_notifications[i]),
          trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => _delete(i)),
        ),
      )),
    );
  }
}

class _ProfileRoot extends StatelessWidget {
  const _ProfileRoot();

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text('Profile')), body: const Center(child: Text('Guest user')));
  }
}

class _Badge extends StatelessWidget {
  final int count;
  const _Badge({required this.count});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
      decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(10)),
      child: Text('$count', style: const TextStyle(color: Colors.white, fontSize: 10)),
    );
  }
}
