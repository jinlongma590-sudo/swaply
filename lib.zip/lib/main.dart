// lib/main.dart - 完整版本带邮箱验证功能（2900+行完整保留）
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:swaply/services/profile_service.dart';
import 'package:swaply/services/notification_service.dart';
import 'package:swaply/services/dual_favorites_service.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:swaply/pages/my_listings_page.dart';
import 'package:provider/provider.dart';
import 'package:swaply/pages/home_page.dart' as swaply;
import 'package:swaply/pages/sell_form_page.dart';
import 'package:swaply/pages/product_detail_page.dart';
import 'package:swaply/models/listing_store.dart';
import 'package:swaply/auth/welcome_screen.dart';
import 'package:swaply/auth/login_screen.dart';
import 'package:swaply/services/listing_service.dart';
import 'package:swaply/pages/coupon_management_page.dart';

// 新增导入验证相关组件
import 'package:swaply/widgets/verification_badge.dart';
import 'package:swaply/pages/verification_page.dart';

// ======= Embedded stubs to keep app English-only without external l10n/provider files =======
import 'package:flutter/foundation.dart' show SynchronousFuture;
import 'package:flutter/widgets.dart';

class AppLocalizations {
  final Locale locale;
  AppLocalizations(this.locale);

  static AppLocalizations? of(BuildContext context) {
    return AppLocalizations(const Locale('en'));
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
  _AppLocalizationsDelegate();

  // ---------- Generic / Auth ----------
  String get appTitle => 'Swaply';
  String get loginRequired => 'Login required';
  String loginRequiredMessage(String feature) => 'Please login to use $feature.';
  String get cancel => 'Cancel';
  String get login => 'Login';
  String get logout => 'Logout';
  String get logoutConfirmation => 'Are you sure you want to logout?';
  String get createAccount => 'Create account';
  String get alreadyHaveAccount => 'Already have an account?';
  String get signUpNow => 'Sign up now';
  String get signUpToUnlock => 'Sign up to unlock the features below';
  String get verification => 'Verification';
  String get accountVerification => 'Account verification';
  String get notVerified => 'Not verified';
  String get about => 'About';
  String get settings => 'Settings';
  String get helpSupport => 'Help & Support';

  // ---------- Tabs / Common ----------
  String get home => 'Home';
  String get saved => 'Saved';
  String get sell => 'Sell';
  String get notifications => 'Notifications';
  String get profile => 'Profile';
  String get favorites => 'Favorites';
  String get rating => 'Rating';

  // ---------- Home ----------
  String get whatLookingFor => 'What are you looking for?';
  String get allZimbabwe => 'All Zimbabwe';
  String get searchPlaceholder => 'Search...';

  // Categories
  String get trending => 'Trending';
  String get vehicles => 'Vehicles';
  String get property => 'Property';
  String get beauty => 'Beauty & Personal Care';
  String get jobs => 'Jobs';
  String get babiesKids => 'Babies & Kids';
  String get services => 'Services';
  String get leisure => 'Leisure Activities';
  String get repairConst => 'Repair & Construction';
  String get furniture => 'Home, Furniture & Appliances';
  String get pets => 'Pets';
  String get electronics => 'Electronics';
  String get phones => 'Phones & Tablets';
  String get seekingWork => 'Seeking Work & CVs';
  String get fashion => 'Fashion';
  String get foodDrinks => 'Food, Agriculture & Drinks';

  // ---------- Saved ----------
  String get myFavorites => 'My Favorites';
  String get loginToSaveFavorites => 'Login to save your favorite items and searches.';
  String get loginNow => 'Login now';
  String get ads => 'Ads';
  String get searches => 'Searches';
  String get noFavoriteAdsYet => 'No favorite ads yet';
  String get favoritesHelp => 'Tap the bookmark icon on a listing to add it to Favorites.';
  String get browseItems => 'Browse items';
  String get removedFromFavorites => 'Removed from favorites';
  String get alertsEnabled => 'Alerts enabled';
  String get searchingFor => 'Searching for';
  String get savedOn => 'saved on';
  String get wishlist => 'Wishlist';
  String get noSavedSearches => 'No saved searches';

  // ---------- Sell ----------
  String get sellItem => 'Sell Item';
  String get loginToPost => 'Login to post your listings.';
  String get sellYourItems => 'Sell your items';
  String get takePhotoAndSell => 'Take a photo and sell in minutes.';
  String get postNewAd => 'Post new ad';
  String get myListings => 'My Listings';
  String get newAd => 'New Ad';
  String get noTitle => 'No title';
  String get noPrice => 'No price';
  String get views => 'views';
  String get totalViews => 'Total views';
  String get likes => 'likes';
  String get edit => 'Edit';
  String get promote => 'Promote';
  String get delete => 'Delete';
  String get editModeComingSoon => 'Edit mode is coming soon';
  String get editFeatureComingSoon => 'Edit feature is coming soon';
  String get listingDeleted => 'Listing deleted';
  String get promoteFeatureComingSoon => 'Promote feature is coming soon';
  String get activeAds => 'Active ads';
  String get navigateToSellTab => 'Navigate to Sell tab';
  String get navigateToSavedTab => 'Navigate to Saved tab';
  String get myPurchases => 'My Purchases';
  String get postListings => 'post listings';

  // ---------- Notifications ----------
  String get notificationDeleted => 'Notification deleted';
  String get loginToReceiveNotifications => 'Login to receive notifications.';
  String get markAllAsRead => 'Mark all as read';
  String get clearAll => 'Clear all';
  String get noNotifications => 'No notifications';
  String get notificationsWillAppearHere => 'Your notifications will appear here.';
  String get receiveNotifications => 'Login to receive notifications.';

  // ---------- Profile ----------
  String get guestUser => 'Guest user';
  String get browseWithoutAccount => 'Browsing without an account';
  String memberSince(String m) => 'Member since $m';
  String get editProfile => 'Edit Profile';

  // ---------- Cities ----------
  String get harare => 'Harare';
  String get bulawayo => 'Bulawayo';
  String get chitungwiza => 'Chitungwiza';
  String get mutare => 'Mutare';
  String get gweru => 'Gweru';
  String get kwekwe => 'Kwekwe';
  String get kadoma => 'Kadoma';
  String get masvingo => 'Masvingo';
  String get chinhoyi => 'Chinhoyi';
  String get chegutu => 'Chegutu';
  String get bindura => 'Bindura';
  String get marondera => 'Marondera';
  String get redcliff => 'Redcliff';

  // ---------- Variants / Typos you might have ----------
  String get saveItems => 'Save items';
  String get saveltems => 'Save items'; // l/I 拼写错误

  @override
  dynamic noSuchMethod(Invocation invocation) => '';
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => true;

  @override
  Future<AppLocalizations> load(Locale locale) =>
      SynchronousFuture<AppLocalizations>(AppLocalizations(const Locale('en')));

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

class LanguageProvider extends ChangeNotifier {
  Locale _current = const Locale('en');
  Locale get currentLocale => _current;
  bool get isEnglish => true;
  void changeLanguage([Locale? locale]) {
    _current = const Locale('en');
    notifyListeners();
  }
  void toggleLanguage() {
    _current = const Locale('en');
    notifyListeners();
  }
}
// ======= End embedded stubs =======

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // ========= 全局错误兜底 =========
  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.presentError(details);
  };
  ErrorWidget.builder = (FlutterErrorDetails details) {
    return Material(
      color: const Color(0xFFF5F5F5),
      child: Center(
        child: Container(
          margin: const EdgeInsets.all(24),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 12)],
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error_outline, color: Colors.red, size: 36),
                const SizedBox(height: 8),
                const Text('Something went wrong', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Text(
                  details.exceptionAsString(),
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.black54),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  };

  await Supabase.initialize(
    url: 'https://rhckybselarzglkmlyqs.supabase.co',
    anonKey:
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJoY2t5YnNlbGFyemdsa21seXFzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTUwMTM0NTgsImV4cCI6MjA3MDU4OTQ1OH0.3I0T2DidiF-q9l2tWeHOjB31QogXHDqRtEjDn0RfVbU',
  );

  runApp(
    ChangeNotifierProvider(
      create: (_) => LanguageProvider(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<LanguageProvider>(
      builder: (context, languageProvider, child) {
        return MaterialApp(
          title: 'Swaply',
          debugShowCheckedModeBanner: false,
          locale: languageProvider.currentLocale,
          localizationsDelegates: const [
            AppLocalizations.delegate,
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          supportedLocales: const [Locale('en')],
          builder: (context, child) {
            return MediaQuery(
              data: MediaQuery.of(context).copyWith(
                textScaleFactor: 1.0, // 固定字体缩放比例
              ),
              child: child!,
            );
          },
          theme: ThemeData(
            primarySwatch: Colors.blue,
            primaryColor: const Color(0xFF2196F3),
            useMaterial3: true,
            colorScheme: ColorScheme.fromSeed(
              seedColor: const Color(0xFF2196F3),
              primary: const Color(0xFF2196F3),
            ),
            appBarTheme: const AppBarTheme(
              backgroundColor: Color(0xFF2196F3),
              foregroundColor: Colors.white,
              elevation: 0,
            ),
            elevatedButtonTheme: ElevatedButtonThemeData(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2196F3),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ),
          home: const WelcomeScreen(),
          routes: {
            '/home': (context) => const MainNavigationPage(),
            '/welcome': (context) => const WelcomeScreen(),
          },
        );
      },
    );
  }
}

class MainNavigationPage extends StatefulWidget {
  final bool isGuest;
  const MainNavigationPage({Key? key, this.isGuest = false}) : super(key: key);
  @override
  State<MainNavigationPage> createState() => _MainNavigationPageState();
}

class _MainNavigationPageState extends State<MainNavigationPage> {
  int _selectedIndex = 0;
  int _notificationCount = 0;

  final _homeKey = GlobalKey<NavigatorState>();
  final _savedKey = GlobalKey<NavigatorState>();
  final _sellKey = GlobalKey<NavigatorState>();
  final _notifKey = GlobalKey<NavigatorState>();
  final _profileKey = GlobalKey<NavigatorState>();

  late final List<GlobalKey<NavigatorState>> _navigatorKeys = [
    _homeKey, _savedKey, _sellKey, _notifKey, _profileKey,
  ];

  @override
  void initState() {
    super.initState();
    _loadNotificationCount();
  }

  Future<void> _loadNotificationCount() async {
    if (!widget.isGuest) {
      try {
        final count = await NotificationService.getUnreadNotificationsCount();
        if (mounted) {
          setState(() => _notificationCount = count);
        }
      } catch (e) {
        if (kDebugMode) {
          print('Error loading notification count: $e');
        }
      }
    }
  }

  void _onPopInvokedWithResult(bool didPop, Object? result) {
    if (didPop) return;
    final current = _navigatorKeys[_selectedIndex].currentState!;
    if (current.canPop()) current.pop();
  }

  void _clearNotifications() {
    setState(() => _notificationCount = 0);
  }

  void _showLoginRequired(String feature, BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(l10n.loginRequired),
          content: Text(l10n.loginRequiredMessage(feature)),
          actions: [
            TextButton(onPressed: () => Navigator.of(context).pop(), child: Text(l10n.cancel)),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const LoginScreen()));
              },
              child: Text(l10n.login),
            ),
          ],
        );
      },
    );
  }

  Widget _buildTabNavigator(GlobalKey<NavigatorState> key, Widget root, LanguageProvider languageProvider) {
    return Navigator(
      key: key,
      onGenerateRoute: (_) => MaterialPageRoute(
        builder: (_) => ChangeNotifierProvider<LanguageProvider>.value(
          value: languageProvider,
          child: root,
        ),
      ),
    );
  }

  // 新增：切换到首页的方法
  void _navigateToHome() {
    setState(() => _selectedIndex = 0);
  }

  @override
  Widget build(BuildContext context) {
    final languageProvider = Provider.of<LanguageProvider>(context, listen: false);

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: _onPopInvokedWithResult,
      child: Scaffold(
        body: IndexedStack(
          index: _selectedIndex,
          children: [
            _buildTabNavigator(_homeKey, const _HomeRoot(), languageProvider),
            _buildTabNavigator(_savedKey, _SavedRoot(
              isGuest: widget.isGuest,
              onNavigateToHome: _navigateToHome, // 传递导航回调
            ), languageProvider),
            _buildTabNavigator(_sellKey, _SellRoot(isGuest: widget.isGuest), languageProvider),
            _buildTabNavigator(_notifKey, _NotifRoot(
              onClearBadge: _clearNotifications,
              isGuest: widget.isGuest,
              onNotificationCountChanged: (count) => setState(() => _notificationCount = count),
            ), languageProvider),
            _buildTabNavigator(_profileKey, _ProfileRoot(isGuest: widget.isGuest), languageProvider),
          ],
        ),
        bottomNavigationBar: _buildBottomBar(context),
      ),
    );
  }

  Widget _buildBottomBar(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final width = MediaQuery.of(context).size.width;
    final itemWidth = width / 5;

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [BoxShadow(color: Colors.grey.withOpacity(0.2), spreadRadius: 1, blurRadius: 10, offset: const Offset(0, -3))],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.only(top: 6, bottom: 6),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildNavItem(Icons.home_outlined, Icons.home, l10n.home, 0, itemWidth, context),
              _buildNavItem(Icons.bookmark_outline, Icons.bookmark, l10n.saved, 1, itemWidth, context),
              _buildAddButton(itemWidth, context),
              _buildNavItemWithBadge(Icons.notifications_outlined, Icons.notifications, l10n.notifications, 3, _notificationCount, itemWidth, context),
              _buildNavItem(Icons.person_outline, Icons.person, l10n.profile, 4, itemWidth, context),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(
      IconData icon,
      IconData activeIcon,
      String label,
      int index,
      double itemWidth,
      BuildContext context,
      ) {
    final l10n = AppLocalizations.of(context)!;
    final bool isSelected = _selectedIndex == index;

    return GestureDetector(
      onTap: () {
        if (widget.isGuest && (index == 1 || index == 3)) {
          _showLoginRequired(index == 1 ? l10n.saveItems : l10n.receiveNotifications, context);
          return; // 保留tab
        }
        setState(() => _selectedIndex = index);
      },
      child: SizedBox(
        width: itemWidth,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(isSelected ? activeIcon : icon, color: isSelected ? const Color(0xFF2196F3) : Colors.grey[600], size: 24),
            const SizedBox(height: 2),
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                label,
                softWrap: false,
                maxLines: 1,
                style: TextStyle(
                  color: isSelected ? const Color(0xFF2196F3) : Colors.grey[600],
                  fontSize: 11,
                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItemWithBadge(
      IconData icon,
      IconData activeIcon,
      String label,
      int index,
      int badgeCount,
      double itemWidth,
      BuildContext context,
      ) {
    final l10n = AppLocalizations.of(context)!;
    final bool isSelected = _selectedIndex == index;

    return GestureDetector(
      onTap: () {
        if (widget.isGuest) {
          _showLoginRequired(l10n.receiveNotifications, context);
          return;
        }
        setState(() {
          _selectedIndex = index;
          if (index == 3) _loadNotificationCount();
        });
      },
      child: SizedBox(
        width: itemWidth,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Icon(isSelected ? activeIcon : icon, color: isSelected ? const Color(0xFF2196F3) : Colors.grey[600], size: 24),
                if (badgeCount > 0 && !widget.isGuest)
                  Positioned(
                    right: -8,
                    top: -6,
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: badgeCount > 9 ? 4 : 6, vertical: 2),
                      decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(10)),
                      child: Text(badgeCount > 99 ? '99+' : '$badgeCount',
                          style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 2),
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                label,
                softWrap: false,
                maxLines: 1,
                style: TextStyle(
                  color: isSelected ? const Color(0xFF2196F3) : Colors.grey[600],
                  fontSize: 11,
                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAddButton(double itemWidth, BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final bool isSelected = _selectedIndex == 2;

    return GestureDetector(
      onTap: () {
        if (widget.isGuest) {
          _showLoginRequired(l10n.postListings, context);
        } else {
          setState(() => _selectedIndex = 2);
        }
      },
      child: SizedBox(
        width: itemWidth,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: const Color(0xFF2196F3),
                borderRadius: BorderRadius.circular(8),
                boxShadow: isSelected
                    ? [BoxShadow(color: const Color(0xFF2196F3).withOpacity(0.25), blurRadius: 10, offset: const Offset(0, 4))]
                    : [],
              ),
              child: const Icon(Icons.add, color: Colors.white, size: 22),
            ),
            const SizedBox(height: 2),
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                l10n.sell,
                softWrap: false,
                maxLines: 1,
                style: const TextStyle(color: Color(0xFF2196F3), fontSize: 11, fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/* ---------------- Tab 根页 ---------------- */

class _HomeRoot extends StatelessWidget {
  const _HomeRoot();
  @override
  Widget build(BuildContext context) => const swaply.HomePage();
}

// 修改：添加导航回调参数
class _SavedRoot extends StatelessWidget {
  final bool isGuest;
  final VoidCallback? onNavigateToHome;
  const _SavedRoot({this.isGuest = false, this.onNavigateToHome});
  @override
  Widget build(BuildContext context) => SavedPage(
    isGuest: isGuest,
    onNavigateToHome: onNavigateToHome,
  );
}

class _SellRoot extends StatelessWidget {
  final bool isGuest;
  const _SellRoot({this.isGuest = false});
  @override
  Widget build(BuildContext context) => SellPage(isGuest: isGuest);
}

class _NotifRoot extends StatelessWidget {
  final VoidCallback onClearBadge;
  final bool isGuest;
  final Function(int)? onNotificationCountChanged;

  const _NotifRoot({
    required this.onClearBadge,
    this.isGuest = false,
    this.onNotificationCountChanged,
  });

  @override
  Widget build(BuildContext context) => NotificationPage(
    onClearBadge: onClearBadge,
    isGuest: isGuest,
    onNotificationCountChanged: onNotificationCountChanged,
  );
}

class _ProfileRoot extends StatelessWidget {
  final bool isGuest;
  const _ProfileRoot({this.isGuest = false});
  @override
  Widget build(BuildContext context) => ProfilePage(isGuest: isGuest);
}

/* ---------------- Saved Page 收藏页 (接入后端版本) - 修复版 ---------------- */

class SavedPage extends StatefulWidget {
  final bool isGuest;
  final VoidCallback? onNavigateToHome; // 新增：导航回调
  const SavedPage({Key? key, this.isGuest = false, this.onNavigateToHome}) : super(key: key);
  @override
  State<SavedPage> createState() => _SavedPageState();
}

class _SavedPageState extends State<SavedPage> {
  List<Map<String, dynamic>> _favoriteItems = [];
  bool _isLoading = true;
  bool _isRefreshing = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    if (!widget.isGuest) {
      _loadFavorites();
    } else {
      setState(() => _isLoading = false);
    }
  }

  /// 加载收藏列表 - 修复：使用 DualFavoritesService
  Future<void> _loadFavorites() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'Please login to view your favorites';
      });
      return;
    }

    try {
      setState(() {
        _isLoading = true;
        _errorMessage = null;
      });

      if (kDebugMode) {
        print('Loading favorites for user: ${user.id}');
      }

      // 修复：使用 DualFavoritesService 获取收藏列表（从 favorites 表）
      final items = await DualFavoritesService.getUserFavorites(
        userId: user.id,
        limit: 100,
      );

      if (mounted) {
        setState(() {
          _favoriteItems = items;
          _isLoading = false;
        });

        if (kDebugMode) {
          print('Loaded ${items.length} favorite items');
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error loading favorites: $e');
      }

      if (mounted) {
        setState(() {
          _isLoading = false;
          _errorMessage = 'Failed to load favorites. Please try again.';
        });
      }
    }
  }

  /// 刷新收藏列表
  Future<void> _refreshFavorites() async {
    setState(() => _isRefreshing = true);
    await _loadFavorites();
    setState(() => _isRefreshing = false);
  }

  /// 从收藏夹移除商品 - 修复：使用 DualFavoritesService
  Future<void> _removeFromFavorites(String listingId, int index) async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;

    try {
      // 修复：使用 DualFavoritesService 同步移除
      final success = await DualFavoritesService.removeFromFavorites(
        userId: user.id,
        listingId: listingId,
      );

      if (success && mounted) {
        setState(() {
          _favoriteItems.removeAt(index);
        });

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Removed from favorites and wishlist'),
            backgroundColor: Colors.green,
          ),
        );
      } else {
        throw Exception('Failed to remove from favorites');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error removing from favorites: $e');
      }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Failed to remove item. Please try again.'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  /// 获取商品图片
  String _getListingImage(Map<String, dynamic> listing) {
    final images = listing['images'] ?? listing['image_urls'];
    if (images is List && images.isNotEmpty) {
      return images.first.toString();
    }
    return 'assets/images/placeholder.jpg';
  }

  /// 格式化价格
  String _formatPrice(dynamic price) {
    if (price == null) return 'Price not available';

    final priceStr = price.toString();
    if (priceStr.startsWith('\$')) return priceStr;

    final numPrice = double.tryParse(priceStr);
    if (numPrice != null) {
      return '\$${numPrice.toStringAsFixed(0)}';
    }

    return priceStr;
  }

  /// 构建商品卡片
  Widget _buildFavoriteCard(Map<String, dynamic> item, int index) {
    final listing = item['listing'] ?? {};
    final listingId = item['listing_id']?.toString() ?? listing['id']?.toString() ?? '';
    final title = listing['title']?.toString() ?? 'Unknown Item';
    final price = _formatPrice(listing['price']);
    final city = listing['city']?.toString() ?? '';
    final imageUrl = _getListingImage(listing);
    final createdAt = item['created_at']?.toString() ?? '';

    // 格式化收藏时间
    final timeAdded = DualFavoritesService.formatSavedTime(createdAt);

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: () {
          if (listingId.isNotEmpty) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ProductDetailPage(
                  productId: listingId,
                  productData: listing,
                ),
              ),
            ).then((_) {
              // 从商品详情页返回后刷新列表
              _loadFavorites();
            });
          }
        },
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 商品图片
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Container(
                  width: 80,
                  height: 80,
                  color: Colors.grey[200],
                  child: imageUrl.startsWith('http')
                      ? Image.network(
                    imageUrl,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return const Icon(
                        Icons.image_not_supported,
                        color: Colors.grey,
                        size: 40,
                      );
                    },
                  )
                      : Image.asset(
                    imageUrl,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return const Icon(
                        Icons.image_not_supported,
                        color: Colors.grey,
                        size: 40,
                      );
                    },
                  ),
                ),
              ),
              const SizedBox(width: 12),

              // 商品信息
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      price,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF2196F3),
                      ),
                    ),
                    const SizedBox(height: 4),
                    if (city.isNotEmpty)
                      Row(
                        children: [
                          Icon(
                            Icons.location_on,
                            size: 14,
                            color: Colors.grey[600],
                          ),
                          const SizedBox(width: 4),
                          Text(
                            city,
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                    const SizedBox(height: 4),
                    Text(
                      'Saved $timeAdded',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[500],
                      ),
                    ),
                  ],
                ),
              ),

              // 移除按钮
              IconButton(
                icon: const Icon(
                  Icons.bookmark,
                  color: Color(0xFF2196F3),
                ),
                onPressed: () => _showRemoveDialog(listingId, title, index),
                tooltip: 'Remove from favorites',
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// 显示移除确认对话框
  void _showRemoveDialog(String listingId, String title, int index) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Remove from Favorites'),
          content: Text('Are you sure you want to remove "$title" from your favorites and wishlist?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _removeFromFavorites(listingId, index);
              },
              child: const Text(
                'Remove',
                style: TextStyle(color: Colors.red),
              ),
            ),
          ],
        );
      },
    );
  }

  /// 构建空状态 - 修复版
  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.bookmark_border,
              size: 80,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            const Text(
              'No Favorites Yet',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Start adding items you like to your favorites by tapping the bookmark icon on any listing.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () {
                // 修复：使用回调函数导航到首页
                if (widget.onNavigateToHome != null) {
                  widget.onNavigateToHome!();
                } else {
                  // 备用方案：弹出到顶层
                  Navigator.of(context).popUntil((route) => route.isFirst);
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2196F3),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: const Text('Browse Items'),
            ),
          ],
        ),
      ),
    );
  }

  /// 构建错误状态
  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline,
              size: 80,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            const Text(
              'Something went wrong',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _errorMessage ?? 'Failed to load your favorites.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _loadFavorites,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2196F3),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: const Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    if (widget.isGuest) {
      return Scaffold(
        backgroundColor: const Color(0xFFF5F5F5),
        appBar: AppBar(
          backgroundColor: const Color(0xFF2196F3),
          title: Text(l10n.myFavorites, style: const TextStyle(color: Colors.white)),
          elevation: 0,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.lock_outline, size: 80, color: Colors.grey[400]),
              const SizedBox(height: 16),
              Text(l10n.loginRequired, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40),
                child: Text(l10n.loginToSaveFavorites, textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[600], fontSize: 14)),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const LoginScreen()));
                },
                child: Text(l10n.loginNow),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        backgroundColor: const Color(0xFF2196F3),
        title: Text(
          'My Favorites (${_favoriteItems.length})',
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
        elevation: 0,
        actions: [
          if (_favoriteItems.isNotEmpty && !_isLoading)
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert, color: Colors.white),
              onSelected: (value) {
                if (value == 'clear_all') {
                  _showClearAllDialog();
                }
              },
              itemBuilder: (BuildContext context) => [
                const PopupMenuItem(
                  value: 'clear_all',
                  child: Row(
                    children: [
                      Icon(Icons.clear_all, color: Colors.red),
                      SizedBox(width: 8),
                      Text('Clear All'),
                    ],
                  ),
                ),
              ],
            ),
        ],
      ),
      body: _isLoading
          ? const Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF2196F3)),
        ),
      )
          : _errorMessage != null
          ? _buildErrorState()
          : _favoriteItems.isEmpty
          ? _buildEmptyState()
          : RefreshIndicator(
        onRefresh: _refreshFavorites,
        color: const Color(0xFF2196F3),
        child: ListView.builder(
          padding: const EdgeInsets.symmetric(vertical: 8),
          itemCount: _favoriteItems.length,
          itemBuilder: (context, index) {
            return _buildFavoriteCard(_favoriteItems[index], index);
          },
        ),
      ),
    );
  }

  /// 显示清空所有确认对话框
  void _showClearAllDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Clear All Favorites'),
          content: const Text('Are you sure you want to remove all items from your favorites and wishlist? This action cannot be undone.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _clearAllFavorites();
              },
              child: const Text(
                'Clear All',
                style: TextStyle(color: Colors.red),
              ),
            ),
          ],
        );
      },
    );
  }

  /// 清空所有收藏 - 修复：使用 DualFavoritesService 同步清空
  Future<void> _clearAllFavorites() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;

    try {
      // 修复：使用 DualFavoritesService 同步清空
      final success = await DualFavoritesService.clearUserFavorites(userId: user.id);

      if (success && mounted) {
        setState(() {
          _favoriteItems.clear();
        });

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('All favorites and wishlist cleared successfully'),
            backgroundColor: Colors.green,
          ),
        );
      } else {
        throw Exception('Failed to clear favorites');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error clearing favorites: $e');
      }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Failed to clear favorites. Please try again.'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
}

/* ---------------- Wishlist Page 心愿单页面 - 新增 ---------------- */

class WishlistPage extends StatefulWidget {
  const WishlistPage({Key? key}) : super(key: key);

  @override
  State<WishlistPage> createState() => _WishlistPageState();
}

class _WishlistPageState extends State<WishlistPage> {
  List<Map<String, dynamic>> _wishlistItems = [];
  bool _isLoading = true;
  bool _isRefreshing = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _loadWishlist();
  }

  /// 加载心愿单列表
  Future<void> _loadWishlist() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'Please login to view your wishlist';
      });
      return;
    }

    try {
      setState(() {
        _isLoading = true;
        _errorMessage = null;
      });

      if (kDebugMode) {
        print('Loading wishlist for user: ${user.id}');
      }

      // 使用 DualFavoritesService 获取心愿单列表（从 wishlists 表）
      final items = await DualFavoritesService.getUserWishlist(
        userId: user.id,
        limit: 100,
      );

      if (mounted) {
        setState(() {
          _wishlistItems = items;
          _isLoading = false;
        });

        if (kDebugMode) {
          print('Loaded ${items.length} wishlist items');
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error loading wishlist: $e');
      }

      if (mounted) {
        setState(() {
          _isLoading = false;
          _errorMessage = 'Failed to load wishlist. Please try again.';
        });
      }
    }
  }

  /// 刷新心愿单列表
  Future<void> _refreshWishlist() async {
    setState(() => _isRefreshing = true);
    await _loadWishlist();
    setState(() => _isRefreshing = false);
  }

  /// 从心愿单移除商品
  Future<void> _removeFromWishlist(String listingId, int index) async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;

    try {
      // 使用 DualFavoritesService 同步移除
      final success = await DualFavoritesService.removeFromFavorites(
        userId: user.id,
        listingId: listingId,
      );

      if (success && mounted) {
        setState(() {
          _wishlistItems.removeAt(index);
        });

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Removed from wishlist and favorites'),
            backgroundColor: Colors.green,
          ),
        );
      } else {
        throw Exception('Failed to remove from wishlist');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error removing from wishlist: $e');
      }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Failed to remove item. Please try again.'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  /// 获取商品图片
  String _getListingImage(Map<String, dynamic> listing) {
    final images = listing['images'] ?? listing['image_urls'];
    if (images is List && images.isNotEmpty) {
      return images.first.toString();
    }
    return 'assets/images/placeholder.jpg';
  }

  /// 格式化价格
  String _formatPrice(dynamic price) {
    if (price == null) return 'Price not available';

    final priceStr = price.toString();
    if (priceStr.startsWith('\$')) return priceStr;

    final numPrice = double.tryParse(priceStr);
    if (numPrice != null) {
      return '\$${numPrice.toStringAsFixed(0)}';
    }

    return priceStr;
  }

  /// 构建心愿单卡片
  Widget _buildWishlistCard(Map<String, dynamic> item, int index) {
    final listing = item['listing'] ?? {};
    final listingId = item['listing_id']?.toString() ?? listing['id']?.toString() ?? '';
    final title = listing['title']?.toString() ?? 'Unknown Item';
    final price = _formatPrice(listing['price']);
    final city = listing['city']?.toString() ?? '';
    final imageUrl = _getListingImage(listing);
    final createdAt = item['created_at']?.toString() ?? '';

    // 格式化添加时间
    final timeAdded = DualFavoritesService.formatSavedTime(createdAt);

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: () {
          if (listingId.isNotEmpty) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ProductDetailPage(
                  productId: listingId,
                  productData: listing,
                ),
              ),
            ).then((_) {
              // 从商品详情页返回后刷新列表
              _loadWishlist();
            });
          }
        },
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 商品图片
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Container(
                  width: 80,
                  height: 80,
                  color: Colors.grey[200],
                  child: imageUrl.startsWith('http')
                      ? Image.network(
                    imageUrl,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return const Icon(
                        Icons.image_not_supported,
                        color: Colors.grey,
                        size: 40,
                      );
                    },
                  )
                      : Image.asset(
                    imageUrl,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return const Icon(
                        Icons.image_not_supported,
                        color: Colors.grey,
                        size: 40,
                      );
                    },
                  ),
                ),
              ),
              const SizedBox(width: 12),

              // 商品信息
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      price,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF2196F3),
                      ),
                    ),
                    const SizedBox(height: 4),
                    if (city.isNotEmpty)
                      Row(
                        children: [
                          Icon(
                            Icons.location_on,
                            size: 14,
                            color: Colors.grey[600],
                          ),
                          const SizedBox(width: 4),
                          Text(
                            city,
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                    const SizedBox(height: 4),
                    Text(
                      'Added $timeAdded',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[500],
                      ),
                    ),
                  ],
                ),
              ),

              // 移除按钮
              IconButton(
                icon: const Icon(
                  Icons.favorite,
                  color: Color(0xFF2196F3),
                ),
                onPressed: () => _showRemoveDialog(listingId, title, index),
                tooltip: 'Remove from wishlist',
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// 显示移除确认对话框
  void _showRemoveDialog(String listingId, String title, int index) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Remove from Wishlist'),
          content: Text('Are you sure you want to remove "$title" from your wishlist and favorites?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _removeFromWishlist(listingId, index);
              },
              child: const Text(
                'Remove',
                style: TextStyle(color: Colors.red),
              ),
            ),
          ],
        );
      },
    );
  }

  /// 构建空状态
  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.favorite_border,
              size: 80,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            const Text(
              'No Wishlist Items Yet',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Start adding items you like to your wishlist by tapping the bookmark icon on any listing.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => Navigator.of(context).pop(),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2196F3),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: const Text('Browse Items'),
            ),
          ],
        ),
      ),
    );
  }

  /// 构建错误状态
  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline,
              size: 80,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            const Text(
              'Something went wrong',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _errorMessage ?? 'Failed to load your wishlist.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _loadWishlist,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2196F3),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: const Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        backgroundColor: const Color(0xFF2196F3),
        title: Text(
          'My Wishlist (${_wishlistItems.length})',
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
        elevation: 0,
        actions: [
          if (_wishlistItems.isNotEmpty && !_isLoading)
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert, color: Colors.white),
              onSelected: (value) {
                if (value == 'clear_all') {
                  _showClearAllDialog();
                }
              },
              itemBuilder: (BuildContext context) => [
                const PopupMenuItem(
                  value: 'clear_all',
                  child: Row(
                    children: [
                      Icon(Icons.clear_all, color: Colors.red),
                      SizedBox(width: 8),
                      Text('Clear All'),
                    ],
                  ),
                ),
              ],
            ),
        ],
      ),
      body: _isLoading
          ? const Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF2196F3)),
        ),
      )
          : _errorMessage != null
          ? _buildErrorState()
          : _wishlistItems.isEmpty
          ? _buildEmptyState()
          : RefreshIndicator(
        onRefresh: _refreshWishlist,
        color: const Color(0xFF2196F3),
        child: ListView.builder(
          padding: const EdgeInsets.symmetric(vertical: 8),
          itemCount: _wishlistItems.length,
          itemBuilder: (context, index) {
            return _buildWishlistCard(_wishlistItems[index], index);
          },
        ),
      ),
    );
  }

  /// 显示清空所有确认对话框
  void _showClearAllDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Clear All Wishlist'),
          content: const Text('Are you sure you want to remove all items from your wishlist and favorites? This action cannot be undone.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _clearAllWishlist();
              },
              child: const Text(
                'Clear All',
                style: TextStyle(color: Colors.red),
              ),
            ),
          ],
        );
      },
    );
  }

  /// 清空所有心愿单
  Future<void> _clearAllWishlist() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;

    try {
      // 使用 DualFavoritesService 同步清空
      final success = await DualFavoritesService.clearUserFavorites(userId: user.id);

      if (success && mounted) {
        setState(() {
          _wishlistItems.clear();
        });

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('All wishlist and favorites cleared successfully'),
            backgroundColor: Colors.green,
          ),
        );
      } else {
        throw Exception('Failed to clear wishlist');
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error clearing wishlist: $e');
      }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Failed to clear wishlist. Please try again.'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
}

/* ---------------- Sell Page 出售页 (恢复完整功能) ---------------- */

class SellPage extends StatelessWidget {
  final bool isGuest;
  const SellPage({Key? key, this.isGuest = false}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    if (isGuest) {
      return Scaffold(
        backgroundColor: const Color(0xFFF5F5F5),
        appBar: AppBar(backgroundColor: const Color(0xFF2196F3), title: Text(l10n.sellItem, style: const TextStyle(color: Colors.white)), elevation: 0),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.lock_outline, size: 80, color: Colors.grey[400]),
              const SizedBox(height: 16),
              Text(l10n.loginRequired, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40),
                child: Text(l10n.loginToPost, textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[600], fontSize: 14)),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const LoginScreen()));
                },
                child: Text(l10n.loginNow),
              ),
            ],
          ),
        ),
      );
    }

    final raw = ListingStore.i.getAll();
    final List<Map<String, dynamic>> myListings =
    (raw is List) ? List<Map<String, dynamic>>.from(raw) : const <Map<String, dynamic>>[];

    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(backgroundColor: const Color(0xFF2196F3), title: Text(l10n.sellItem, style: const TextStyle(color: Colors.white)), elevation: 0),
      body: myListings.isEmpty
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.add_a_photo, size: 80, color: Color(0xFF2196F3)),
            const SizedBox(height: 16),
            Text(l10n.sellYourItems, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(l10n.takePhotoAndSell, style: TextStyle(color: Colors.grey[600])),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF2196F3), padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12)),
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SellFormPage())),
              icon: const Icon(Icons.add, color: Colors.white),
              label: Text(l10n.postNewAd, style: const TextStyle(color: Colors.white)),
            ),
          ],
        ),
      )
          : Column(
        children: [
          Container(
            color: Colors.white,
            padding: const EdgeInsets.all(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('${l10n.myListings} (${myListings.length})', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ElevatedButton.icon(
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SellFormPage())),
                  icon: const Icon(Icons.add, size: 16),
                  label: Text(l10n.newAd),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(8),
              itemCount: myListings.length,
              itemBuilder: (context, index) {
                final item = myListings[index];
                return Card(
                  margin: const EdgeInsets.symmetric(vertical: 4),
                  child: ListTile(
                    leading: Container(
                      width: 60, height: 60,
                      decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(8)),
                      child: item['images'] != null && item['images'].isNotEmpty
                          ? ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.asset(
                          item['images'][0],
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) => const Icon(Icons.image, color: Colors.grey),
                        ),
                      )
                          : const Icon(Icons.image, color: Colors.grey),
                    ),
                    title: Text(item['title'] ?? l10n.noTitle),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(item['price'] ?? l10n.noPrice, style: const TextStyle(color: Color(0xFF2196F3), fontWeight: FontWeight.bold)),
                        Row(
                          children: [
                            Icon(Icons.visibility, size: 14, color: Colors.grey[600]),
                            const SizedBox(width: 4),
                            Text('234 ${l10n.views}', style: TextStyle(color: Colors.grey[600])),
                            const SizedBox(width: 12),
                            Icon(Icons.favorite, size: 14, color: Colors.grey[600]),
                            const SizedBox(width: 4),
                            Text('12 ${l10n.likes}', style: TextStyle(color: Colors.grey[600])),
                          ],
                        ),
                      ],
                    ),
                    trailing: PopupMenuButton<String>(
                      onSelected: (value) async {
                        switch (value) {
                          case 'view':
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ProductDetailPage(
                                  productId: item['id'].toString(),
                                  productData: item,
                                ),
                              ),
                            );
                            break;
                          case 'edit':
                            await Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => const SellFormPage(),
                              ),
                            );
                            break;
                          case 'delete':
                            final ok = await showDialog<bool>(
                              context: context,
                              builder: (_) => AlertDialog(
                                title: Text(l10n.delete),
                                content: const Text('Are you sure you want to delete this listing? This cannot be undone.'),
                                actions: [
                                  TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                                  TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete', style: TextStyle(color: Colors.red))),
                                ],
                              ),
                            );
                            if (ok == true) {
                              try {
                                final urls = (item['images'] as List?)?.cast<String>() ?? const <String>[];
                                final paths = urls.map(ListingService.publicUrlToObjectPath).whereType<String>().toList();
                                await ListingService.deleteListingAndStorage(
                                  id: (item['id'] as num).toInt(),
                                  imageObjectPaths: paths,
                                );
                                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(l10n.listingDeleted)));
                              } catch (e) {
                                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Delete failed: $e')));
                              }
                            }
                            break;
                        }
                      },
                      itemBuilder: (BuildContext context) => const [
                        PopupMenuItem(value: 'view', child: Text('View')),
                        PopupMenuItem(value: 'edit', child: Text('Edit')),
                        PopupMenuItem(value: 'delete', child: Text('Delete')),
                      ],
                    ),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => ProductDetailPage(productId: item['id'], productData: item))),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

/* ---------------- Notification Page 通知页 (使用第二个版本的Service集成) ---------------- */

class NotificationPage extends StatefulWidget {
  final VoidCallback? onClearBadge;
  final bool isGuest;
  final Function(int)? onNotificationCountChanged;

  const NotificationPage({
    Key? key,
    this.onClearBadge,
    this.isGuest = false,
    this.onNotificationCountChanged,
  }) : super(key: key);

  @override
  State<NotificationPage> createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  List<Map<String, dynamic>> _notifications = [];
  bool _isLoading = true;
  RealtimeChannel? _notificationChannel;

  @override
  void initState() {
    super.initState();
    if (!widget.isGuest) {
      _loadNotifications();
      _subscribeToNotifications();
    } else {
      setState(() => _isLoading = false);
    }

    if (widget.onClearBadge != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) => widget.onClearBadge!());
    }
  }

  @override
  void dispose() {
    _unsubscribeFromNotifications();
    super.dispose();
  }

  Future<void> _loadNotifications() async {
    try {
      setState(() => _isLoading = true);

      final notifications = await NotificationService.getUserNotifications(
        limit: 100,
        includeRead: true,
      );

      if (mounted) {
        setState(() {
          _notifications = notifications;
          _isLoading = false;
        });
        _updateUnreadCount();
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error loading notifications: $e');
      }
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _subscribeToNotifications() {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;

    _notificationChannel = NotificationService.subscribeToNotifications(
      userId: user.id,
      onNotificationReceived: (notification) {
        if (mounted) {
          setState(() {
            _notifications.insert(0, notification);
          });
          _updateUnreadCount();
        }
      },
    );
  }

  void _unsubscribeFromNotifications() {
    if (_notificationChannel != null) {
      NotificationService.unsubscribeFromNotifications(_notificationChannel!);
      _notificationChannel = null;
    }
  }

  void _updateUnreadCount() {
    final unreadCount = _notifications.where((n) => n['is_read'] != true).length;
    if (widget.onNotificationCountChanged != null) {
      widget.onNotificationCountChanged!(unreadCount);
    }
  }

  Future<void> _markAsRead(int index) async {
    final notification = _notifications[index];
    if (notification['is_read'] == true) return;

    try {
      final success = await NotificationService.markNotificationAsRead(
        notification['id'].toString(),
      );

      if (success && mounted) {
        setState(() {
          _notifications[index]['is_read'] = true;
          _notifications[index]['read_at'] = DateTime.now().toIso8601String();
        });
        _updateUnreadCount();
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error marking notification as read: $e');
      }
    }
  }

  Future<void> _deleteNotification(int index) async {
    final l10n = AppLocalizations.of(context)!;
    final notification = _notifications[index];

    try {
      final success = await NotificationService.deleteNotification(
        notification['id'].toString(),
      );

      if (success && mounted) {
        setState(() => _notifications.removeAt(index));
        _updateUnreadCount();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(l10n.notificationDeleted)),
        );
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error deleting notification: $e');
      }
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to delete notification')),
      );
    }
  }

  Future<void> _markAllAsRead() async {
    try {
      final success = await NotificationService.markAllNotificationsAsRead();

      if (success && mounted) {
        setState(() {
          for (var notification in _notifications) {
            notification['is_read'] = true;
            notification['read_at'] = DateTime.now().toIso8601String();
          }
        });
        _updateUnreadCount();
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error marking all as read: $e');
      }
    }
  }

  Future<void> _clearAll() async {
    try {
      final success = await NotificationService.clearAllNotifications();

      if (success && mounted) {
        setState(() => _notifications.clear());
        _updateUnreadCount();
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error clearing all notifications: $e');
      }
    }
  }

  Widget _getNotificationIcon(String type) {
    final color = Color(NotificationService.getNotificationColor(type));

    switch (type) {
      case 'offer':
        return CircleAvatar(
          backgroundColor: color,
          child: const Icon(Icons.local_offer, color: Colors.white, size: 20),
        );
      case 'wishlist':
        return CircleAvatar(
          backgroundColor: color,
          child: const Icon(Icons.bookmark, color: Colors.white, size: 20),
        );
      case 'purchase':
        return CircleAvatar(
          backgroundColor: color,
          child: const Icon(Icons.shopping_cart, color: Colors.white, size: 20),
        );
      case 'message':
        return CircleAvatar(
          backgroundColor: color,
          child: const Icon(Icons.message, color: Colors.white, size: 20),
        );
      case 'price_drop':
        return CircleAvatar(
          backgroundColor: color,
          child: const Icon(Icons.trending_down, color: Colors.white, size: 20),
        );
      case 'system':
      default:
        return CircleAvatar(
          backgroundColor: color,
          child: const Icon(Icons.notifications, color: Colors.white, size: 20),
        );
    }
  }

  void _handleNotificationTap(Map<String, dynamic> notification) {
    final index = _notifications.indexOf(notification);
    if (index >= 0) {
      _markAsRead(index);
    }

    final type = notification['type']?.toString() ?? '';
    final listingId = notification['listing_id']?.toString();

    if (listingId != null && (type == 'offer' || type == 'wishlist')) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ProductDetailPage(productId: listingId),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    if (widget.isGuest) {
      return Scaffold(
        backgroundColor: const Color(0xFFF5F5F5),
        appBar: AppBar(
            backgroundColor: const Color(0xFF2196F3),
            title: Text(l10n.notifications, style: const TextStyle(color: Colors.white)),
            elevation: 0
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.lock_outline, size: 80, color: Colors.grey[400]),
              const SizedBox(height: 16),
              Text(l10n.loginRequired, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40),
                child: Text(
                    l10n.loginToReceiveNotifications,
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.grey[600], fontSize: 14)
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () => Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => const LoginScreen())
                ),
                child: Text(l10n.loginNow),
              ),
            ],
          ),
        ),
      );
    }

    final unreadCount = _notifications.where((n) => n['is_read'] != true).length;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        backgroundColor: const Color(0xFF2196F3),
        title: Text(
            '${l10n.notifications}${unreadCount > 0 ? ' ($unreadCount)' : ''}',
            style: const TextStyle(color: Colors.white)
        ),
        elevation: 0,
        actions: [
          if (_notifications.isNotEmpty)
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert, color: Colors.white),
              onSelected: (value) {
                if (value == 'mark_all_read') {
                  _markAllAsRead();
                } else if (value == 'clear_all') {
                  _clearAll();
                }
              },
              itemBuilder: (BuildContext context) => [
                PopupMenuItem(value: 'mark_all_read', child: Text(l10n.markAllAsRead)),
                PopupMenuItem(value: 'clear_all', child: Text(l10n.clearAll)),
              ],
            ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _notifications.isEmpty
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.notifications_none, size: 80, color: Colors.grey[400]),
            const SizedBox(height: 16),
            Text(l10n.noNotifications, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Text(l10n.notificationsWillAppearHere, style: TextStyle(color: Colors.grey[600])),
          ],
        ),
      )
          : RefreshIndicator(
        onRefresh: _loadNotifications,
        child: ListView.builder(
          itemCount: _notifications.length,
          itemBuilder: (context, index) {
            final notification = _notifications[index];
            final isRead = notification['is_read'] == true;
            final type = notification['type']?.toString() ?? '';
            final createdAt = notification['created_at']?.toString() ?? '';

            return Dismissible(
              key: Key('${notification['id']}'),
              background: Container(
                color: Colors.red,
                alignment: Alignment.centerRight,
                padding: const EdgeInsets.only(right: 20),
                child: const Icon(Icons.delete, color: Colors.white),
              ),
              direction: DismissDirection.endToStart,
              onDismissed: (direction) => _deleteNotification(index),
              child: Container(
                color: isRead ? Colors.white : Colors.blue[50],
                margin: const EdgeInsets.only(bottom: 1),
                child: ListTile(
                  leading: _getNotificationIcon(type),
                  title: Text(
                    '${notification['title'] ?? ''}',
                    style: TextStyle(
                      fontWeight: isRead ? FontWeight.normal : FontWeight.bold,
                    ),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${notification['message'] ?? ''}'),
                      const SizedBox(height: 4),
                      Text(
                        NotificationService.formatNotificationTime(createdAt),
                        style: const TextStyle(fontSize: 12, color: Colors.grey),
                      ),
                    ],
                  ),
                  trailing: !isRead
                      ? Container(
                    width: 8,
                    height: 8,
                    decoration: const BoxDecoration(
                      color: Color(0xFF2196F3),
                      shape: BoxShape.circle,
                    ),
                  )
                      : null,
                  onTap: () => _handleNotificationTap(notification),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

/* ---------------- Profile Page 个人资料页（美化版本 - 修复锯齿）---------------- */

class ProfilePage extends StatefulWidget {
  final bool isGuest;
  const ProfilePage({Key? key, this.isGuest = false}) : super(key: key);

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> with SingleTickerProviderStateMixin {
  bool _loading = true;
  Map<String, dynamic>? _profile;
  final _svc = ProfileService();
  VerificationBadgeType _verificationType = VerificationBadgeType.none;
  bool _uploadingAvatar = false;

  // 动画控制器
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();

    // 初始化动画
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );

    if (!widget.isGuest) {
      _load();
    } else {
      _animationController.forward();
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final data = await _svc.getUserProfileWithVerification();
      if (!mounted) return;
      setState(() {
        _profile = data ?? {};
        _loading = false;
        _verificationType = VerificationBadge.getVerificationTypeFromUser(_profile);
      });
      _animationController.forward();
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      _animationController.forward();
    }
  }

  Future<void> _editNamePhone() async {
    final nameCtrl = TextEditingController();
    final phoneCtrl = TextEditingController();

    try {
      final p = await ProfileService.instance.getUserProfile();
      if (p != null) {
        nameCtrl.text = (p['display_name'] ?? p['full_name'] ?? '').toString();
        phoneCtrl.text = (p['phone'] ?? '').toString();
      }
    } catch (_) {}

    if (!mounted) {
      nameCtrl.dispose();
      phoneCtrl.dispose();
      return;
    }

    final result = await showDialog<bool>(
      context: context,
      useRootNavigator: true,
      barrierDismissible: true,
      builder: (dialogCtx) {
        return Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          elevation: 8,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.white,
                  Colors.grey.shade50,
                ],
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Theme.of(context).primaryColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        Icons.edit,
                        color: Theme.of(context).primaryColor,
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 12),
                    const Text(
                      'Edit Profile',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                TextField(
                  controller: nameCtrl,
                  decoration: InputDecoration(
                    labelText: 'Full name',
                    prefixIcon: const Icon(Icons.person_outline),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(
                        color: Theme.of(context).primaryColor,
                        width: 2,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: phoneCtrl,
                  keyboardType: TextInputType.phone,
                  decoration: InputDecoration(
                    labelText: 'Phone',
                    prefixIcon: const Icon(Icons.phone_outlined),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(
                        color: Theme.of(context).primaryColor,
                        width: 2,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 28),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: () {
                        if (Navigator.of(dialogCtx).canPop()) {
                          Navigator.of(dialogCtx).pop(false);
                        }
                      },
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 24,
                          vertical: 12,
                        ),
                      ),
                      child: const Text('Cancel'),
                    ),
                    const SizedBox(width: 12),
                    ElevatedButton(
                      onPressed: () async {
                        if (Navigator.of(dialogCtx).canPop()) {
                          Navigator.of(dialogCtx).pop(true);
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 32,
                          vertical: 12,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        elevation: 0,
                      ),
                      child: const Text('Save'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );

    if (result == true && mounted) {
      try {
        await ProfileService.instance.updateUserProfile(
          fullName: nameCtrl.text.trim().isEmpty ? null : nameCtrl.text.trim(),
          phone: phoneCtrl.text.trim().isEmpty ? null : phoneCtrl.text.trim(),
        );

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Row(
                children: [
                  Icon(Icons.check_circle, color: Colors.white),
                  SizedBox(width: 8),
                  Text('Profile updated successfully'),
                ],
              ),
              backgroundColor: Colors.green,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          );
          await _load();
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(
                children: [
                  const Icon(Icons.error_outline, color: Colors.white),
                  const SizedBox(width: 8),
                  Expanded(child: Text('Update failed: $e')),
                ],
              ),
              backgroundColor: Colors.red,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          );
        }
      }
    }

    nameCtrl.dispose();
    phoneCtrl.dispose();
  }

  Future<void> _uploadAvatarSimple() async {
    if (!mounted) return;
    setState(() => _uploadingAvatar = true);

    try {
      final picker = ImagePicker();
      final XFile? image = await picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 512,
        maxHeight: 512,
        imageQuality: 80,
      );
      if (image == null) {
        return;
      }

      final user = Supabase.instance.client.auth.currentUser;
      if (user == null) {
        throw Exception('User not authenticated');
      }

      final bytes = await File(image.path).readAsBytes();
      final ext = image.path.split('.').last;
      final path = '${user.id}/avatar_${DateTime.now().millisecondsSinceEpoch}.$ext';

      await Supabase.instance.client.storage
          .from('avatars')
          .uploadBinary(path, bytes, fileOptions: const FileOptions(upsert: true));

      final publicUrl = Supabase.instance.client.storage.from('avatars').getPublicUrl(path);
      await ProfileService.instance.updateUserProfile(avatarUrl: publicUrl);

      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Row(
              children: [
                Icon(Icons.check_circle, color: Colors.white),
                SizedBox(width: 8),
                Text('Avatar updated successfully'),
              ],
            ),
            backgroundColor: Colors.green,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                const Icon(Icons.error_outline, color: Colors.white),
                const SizedBox(width: 8),
                Expanded(child: Text('Upload failed: $e')),
              ],
            ),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _uploadingAvatar = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final languageProvider = Provider.of<LanguageProvider>(context);

    // 游客版本
    if (widget.isGuest) {
      return Scaffold(
        backgroundColor: const Color(0xFFF8F9FA),
        body: CustomScrollView(
          slivers: [
            SliverAppBar(
              expandedHeight: 240,
              backgroundColor: Colors.transparent,
              pinned: true,
              elevation: 0,
              flexibleSpace: _buildEnhancedHeader(
                isGuest: true,
                languageProvider: languageProvider,
                name: l10n.guestUser,
                email: l10n.browseWithoutAccount,
                avatarUrl: null,
              ),
            ),
            SliverToBoxAdapter(
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      _ProfileOptionEnhanced(
                        icon: Icons.help_outline_rounded,
                        title: l10n.helpSupport,
                        color: Colors.blue,
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => HelpSupportPage()),
                        ),
                      ),
                      const SizedBox(height: 12),
                      _ProfileOptionEnhanced(
                        icon: Icons.info_outline_rounded,
                        title: l10n.about,
                        color: Colors.indigo,
                        isLast: true,
                        onTap: () => showAboutDialog(
                          context: context,
                          applicationName: 'Swaply',
                          applicationVersion: '1.0.0',
                          applicationLegalese: '© 2024 Swaply. All rights reserved.',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    }

    // 加载中
    if (_loading) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(
                  Theme.of(context).primaryColor,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'Loading profile...',
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
      );
    }

    final fullName = (_profile?['full_name'] ?? 'User') as String;
    final email = (_profile?['email'] ?? '') as String;
    final phone = (_profile?['phone'] ?? '') as String;
    final avatarUrl = (_profile?['avatar_url'] ?? '') as String?;
    final memberSince = _profile?['created_at'] as String?;

    String? memberSinceText;
    if (memberSince != null && memberSince.isNotEmpty) {
      final cut = memberSince.length >= 10 ? memberSince.substring(0, 10) : memberSince;
      memberSinceText = 'Member since $cut';
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      body: Stack(
        children: [
          CustomScrollView(
            slivers: [
              SliverAppBar(
                expandedHeight: 280,
                backgroundColor: Colors.transparent,
                pinned: true,
                elevation: 0,
                flexibleSpace: _buildEnhancedHeader(
                  isGuest: false,
                  languageProvider: languageProvider,
                  name: fullName,
                  email: phone.isNotEmpty ? phone : email,
                  avatarUrl: avatarUrl?.isNotEmpty == true ? avatarUrl : null,
                  memberSince: memberSinceText,
                  verificationType: _verificationType,
                ),
              ),
              SliverToBoxAdapter(
                child: FadeTransition(
                  opacity: _fadeAnimation,
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Profile Actions Section
                        Text(
                          'Profile',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: Colors.grey[600],
                            letterSpacing: 0.5,
                          ),
                        ),
                        const SizedBox(height: 12),

                        _ProfileOptionEnhanced(
                          icon: Icons.edit_rounded,
                          title: l10n.editProfile,
                          color: Colors.blue,
                          onTap: () => _editNamePhone(),
                        ),
                        const SizedBox(height: 12),

                        _ProfileOptionEnhanced(
                          icon: Icons.verified_user_rounded,
                          title: l10n.verification,
                          subtitle: VerificationBadge.getVerificationText(_verificationType),
                          color: _verificationType != VerificationBadgeType.none
                              ? Colors.green
                              : Colors.orange,
                          showBadge: _verificationType != VerificationBadgeType.none,
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => const VerificationPage()),
                          ).then((_) => _load()),
                        ),

                        const SizedBox(height: 24),

                        // Activities Section
                        Text(
                          'Activities',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: Colors.grey[600],
                            letterSpacing: 0.5,
                          ),
                        ),
                        const SizedBox(height: 12),

                        _ProfileOptionEnhanced(
                          icon: Icons.inventory_2_rounded,
                          title: l10n.myListings,
                          color: Colors.indigo,
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => const MyListingsPage()),
                          ),
                        ),
                        const SizedBox(height: 12),

                        _ProfileOptionEnhanced(
                          icon: Icons.favorite_rounded,
                          title: l10n.wishlist,
                          color: Colors.pink,
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => const WishlistPage()),
                          ),
                        ),
                        const SizedBox(height: 12),

                        _ProfileOptionEnhanced(
                          icon: Icons.local_activity_rounded,
                          title: 'My Coupons',
                          color: Colors.purple,
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => const CouponManagementPage()),
                          ),
                        ),

                        const SizedBox(height: 24),

                        // Support Section
                        Text(
                          'Support',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: Colors.grey[600],
                            letterSpacing: 0.5,
                          ),
                        ),
                        const SizedBox(height: 12),

                        _ProfileOptionEnhanced(
                          icon: Icons.help_outline_rounded,
                          title: l10n.helpSupport,
                          color: Colors.teal,
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => HelpSupportPage()),
                          ),
                        ),
                        const SizedBox(height: 12),

                        _ProfileOptionEnhanced(
                          icon: Icons.info_outline_rounded,
                          title: l10n.about,
                          color: Colors.blueGrey,
                          onTap: () => showAboutDialog(
                            context: context,
                            applicationName: 'Swaply',
                            applicationVersion: '1.0.0',
                            applicationLegalese: '© 2024 Swaply. All rights reserved.',
                          ),
                        ),

                        const SizedBox(height: 24),

                        _ProfileOptionEnhanced(
                          icon: Icons.logout_rounded,
                          title: l10n.logout,
                          color: Colors.red,
                          isLast: true,
                          onTap: () async {
                            final confirmed = await showDialog<bool>(
                              context: context,
                              builder: (ctx) => AlertDialog(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                title: const Text('Logout'),
                                content: const Text('Are you sure you want to logout?'),
                                actions: [
                                  TextButton(
                                    onPressed: () => Navigator.of(ctx).pop(false),
                                    child: const Text('Cancel'),
                                  ),
                                  ElevatedButton(
                                    onPressed: () => Navigator.of(ctx).pop(true),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.red,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                    ),
                                    child: const Text('Logout'),
                                  ),
                                ],
                              ),
                            );

                            if (confirmed == true) {
                              await Supabase.instance.client.auth.signOut();
                              if (!mounted) return;
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(builder: (_) => const WelcomeScreen()),
                              );
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),

          // 上传中遮罩
          if (_uploadingAvatar)
            Container(
              color: Colors.black54,
              child: Center(
                child: Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const CircularProgressIndicator(),
                      const SizedBox(height: 16),
                      Text(
                        'Uploading avatar...',
                        style: TextStyle(
                          color: Colors.grey[700],
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  // 美化的头部设计 - 无锯齿
  Widget _buildEnhancedHeader({
    required bool isGuest,
    required LanguageProvider languageProvider,
    required String name,
    required String email,
    String? avatarUrl,
    String? memberSince,
    VerificationBadgeType verificationType = VerificationBadgeType.none,
  }) {
    return FlexibleSpaceBar(
      background: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF2563EB), // Modern Blue
              Color(0xFF3B82F6),
              Color(0xFF60A5FA),
            ],
            stops: const [0.0, 0.5, 1.0],
          ),
        ),
        child: Stack(
          children: [
            // 平滑的装饰元素
            Positioned(
              top: -100,
              right: -100,
              child: Container(
                width: 250,
                height: 250,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      Colors.white.withOpacity(0.1),
                      Colors.white.withOpacity(0.0),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: -80,
              left: -80,
              child: Container(
                width: 200,
                height: 200,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      Colors.white.withOpacity(0.08),
                      Colors.white.withOpacity(0.0),
                    ],
                  ),
                ),
              ),
            ),

            // 平滑的底部过渡
            Positioned(
              bottom: -1,
              left: 0,
              right: 0,
              child: Container(
                height: 30,
                decoration: BoxDecoration(
                  color: const Color(0xFFF8F9FA),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(30),
                    topRight: Radius.circular(30),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0, -5),
                    ),
                  ],
                ),
              ),
            ),

            // 主要内容
            SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(24, 8, 24, 60),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Spacer(),

                    // 头像
                    Hero(
                      tag: 'profile_avatar',
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: [
                              Colors.white.withOpacity(0.8),
                              Colors.white.withOpacity(0.2),
                            ],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.2),
                              blurRadius: 20,
                              offset: const Offset(0, 10),
                            ),
                          ],
                        ),
                        child: VerifiedAvatar(
                          avatarUrl: avatarUrl,
                          radius: 48,
                          verificationType: verificationType,
                          onTap: !isGuest ? _uploadAvatarSimple : null,
                          defaultIcon: isGuest ? Icons.person_outline : Icons.person,
                        ),
                      ),
                    ),

                    const SizedBox(height: 20),

                    // 用户名
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Flexible(
                          child: Text(
                            name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 26,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.5,
                              shadows: [
                                Shadow(
                                  offset: Offset(0, 2),
                                  blurRadius: 4,
                                  color: Color(0x40000000),
                                ),
                              ],
                            ),
                          ),
                        ),
                        if (verificationType != VerificationBadgeType.none) ...[
                          const SizedBox(width: 10),
                          VerificationBadge(
                            type: verificationType,
                            size: 24,
                            showBorder: false,
                          ),
                        ],
                      ],
                    ),

                    const SizedBox(height: 8),

                    // 联系信息
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(25),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.3),
                          width: 1,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            email.contains('@') ? Icons.email : Icons.phone,
                            size: 16,
                            color: Colors.white.withOpacity(0.9),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            email,
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.95),
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),

                    if (!isGuest && memberSince != null) ...[
                      const SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          _buildInfoChip(
                            icon: Icons.calendar_today_outlined,
                            label: memberSince.replaceAll('Member since ', ''),
                            color: Colors.white.withOpacity(0.9),
                          ),
                          const SizedBox(width: 12),
                          if (verificationType != VerificationBadgeType.none)
                            _buildInfoChip(
                              icon: Icons.verified,
                              label: 'Verified',
                              color: Colors.greenAccent,
                            ),
                        ],
                      ),
                    ],

                    const Spacer(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoChip({
    required IconData icon,
    required String label,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Colors.white.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

// 增强的选项卡组件
class _ProfileOptionEnhanced extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final bool isLast;
  final Color color;
  final bool showBadge;
  final VoidCallback? onTap;

  const _ProfileOptionEnhanced({
    required this.icon,
    required this.title,
    required this.color,
    this.subtitle,
    this.isLast = false,
    this.showBadge = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 10,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: color, size: 24),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    if (subtitle != null) ...[
                      const SizedBox(height: 2),
                      Text(
                        subtitle!,
                        style: TextStyle(
                          fontSize: 13,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              if (showBadge)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.green.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(
                    Icons.check,
                    size: 16,
                    color: Colors.green,
                  ),
                ),
              const SizedBox(width: 8),
              Icon(
                Icons.arrow_forward_ios,
                size: 16,
                color: Colors.grey[400],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// 这个类已经不需要了，可以删除
// WavePainter 类已移除

// 示例页面保持不变
class EditProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    return Scaffold(
      appBar: AppBar(title: Text(l10n.editProfile)),
      body: Center(child: Text(l10n.editProfile)),
    );
  }
}

class MyPurchasesPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    return Scaffold(
      appBar: AppBar(title: Text(l10n.myPurchases)),
      body: Center(child: Text(l10n.myPurchases)),
    );
  }
}

class HelpSupportPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    return Scaffold(
      appBar: AppBar(title: Text(l10n.helpSupport)),
      body: Center(child: Text(l10n.helpSupport)),
    );
  }
}

class SettingsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    return Scaffold(
      appBar: AppBar(title: Text(l10n.settings)),
      body: Center(child: Text(l10n.settings)),
    );
  }
}