// lib/pages/sell_form_page.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:swaply/pages/product_detail_page.dart' as pd;
import 'package:swaply/config.dart';
import 'package:swaply/models/listing_store.dart'; // 本地发布用

import '../listing_api.dart'; // 使用后端 API（images 列 & listings_images bucket）

class SellFormPage extends StatefulWidget {
  const SellFormPage({super.key});

  @override
  State<SellFormPage> createState() => _SellFormPageState();
}

class _SellFormPageState extends State<SellFormPage> {
  /* ------------ controllers & state ------------ */
  final _formKey = GlobalKey<FormState>();
  final _titleCtrl = TextEditingController();
  final _priceCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();

  // 提交状态 & 进度提示
  bool _submitting = false;
  String _progressMsg = '';

  // 针对动态字段（不同分类有不同额外字段）
  final Map<String, TextEditingController> _dynamicControllers = {};

  final _picker = ImagePicker();
  final List<XFile> _images = [];

  String _category = '';
  String _city = 'Harare';

  // 下拉框等保存的值
  final Map<String, String> _dynamicValues = {};

  /* --------- 常量数据 --------- */
  static const _maxPhotos = 10;

  final _cities = const [
    'Harare',
    'Bulawayo',
    'Chitungwiza',
    'Mutare',
    'Gweru',
    'Kwekwe',
    'Kadoma',
    'Masvingo',
    'Chinhoyi',
    'Chegutu',
    'Bindura',
    'Marondera',
    'Redcliff'
  ];

  // 与首页一致的 15 个分类
  final _categories = const [
    'Vehicles',
    'Property',
    'Beauty and Personal Care',
    'Jobs',
    'Babies and Kids',
    'Services',
    'Leisure Activities',
    'Repair and Construction',
    'Home Furniture and Appliances',
    'Pets',
    'Electronics',
    'Phones and Tablets',
    'Seeking Work and CVs',
    'Fashion',
    'Food Agriculture and Drinks'
  ];

  /* ---------- 获取（或新建）动态字段控制器 ---------- */
  TextEditingController _getController(String key) {
    return _dynamicControllers.putIfAbsent(key, () => TextEditingController());
  }

  /* ---------- 分类专属字段 ---------- */
  List<Widget> _getCategorySpecificFields() {
    switch (_category) {
      case 'Vehicles':
        return [
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Vehicle Type *', border: OutlineInputBorder()),
            value: _dynamicValues['vehicleType'],
            items: [
              'Car', 'Motorcycle', 'Truck', 'Bus', 'Van', 'Tractor', 'Boat', 'Other'
            ].map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['vehicleType'] = v ?? ''),
            validator: (v) => v == null ? 'Select vehicle type' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('make'),
            decoration: const InputDecoration(
              labelText: 'Make/Brand *',
              hintText: 'e.g. Toyota, Honda',
              border: OutlineInputBorder(),
            ),
            validator: (v) => v!.isEmpty ? 'Required' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('model'),
            decoration: const InputDecoration(
              labelText: 'Model *',
              hintText: 'e.g. Corolla, Civic',
              border: OutlineInputBorder(),
            ),
            validator: (v) => v!.isEmpty ? 'Required' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('year'),
            decoration: const InputDecoration(
              labelText: 'Year',
              hintText: 'e.g. 2020',
              border: OutlineInputBorder(),
            ),
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('mileage'),
            decoration: const InputDecoration(
              labelText: 'Mileage (km)',
              hintText: 'e.g. 50000',
              border: OutlineInputBorder(),
            ),
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Fuel Type', border: OutlineInputBorder()),
            value: _dynamicValues['fuelType'],
            items: ['Petrol', 'Diesel', 'Electric', 'Hybrid', 'LPG', 'Other']
                .map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['fuelType'] = v ?? ''),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Transmission', border: OutlineInputBorder()),
            value: _dynamicValues['transmission'],
            items: ['Manual', 'Automatic', 'Semi-Automatic']
                .map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['transmission'] = v ?? ''),
          ),
        ];

      case 'Property':
        return [
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Property Type *', border: OutlineInputBorder()),
            value: _dynamicValues['propertyType'],
            items: [
              'House', 'Apartment', 'Land', 'Commercial', 'Office Space', 'Warehouse', 'Farm'
            ].map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['propertyType'] = v ?? ''),
            validator: (v) => v == null ? 'Select property type' : null,
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Listing Type *', border: OutlineInputBorder()),
            value: _dynamicValues['listingType'],
            items: ['For Sale', 'For Rent', 'Lease']
                .map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['listingType'] = v ?? ''),
            validator: (v) => v == null ? 'Select listing type' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('bedrooms'),
            decoration: const InputDecoration(
              labelText: 'Number of Bedrooms',
              border: OutlineInputBorder(),
            ),
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('bathrooms'),
            decoration: const InputDecoration(
              labelText: 'Number of Bathrooms',
              border: OutlineInputBorder(),
            ),
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('area'),
            decoration: const InputDecoration(
              labelText: 'Area (sq meters)',
              border: OutlineInputBorder(),
            ),
            keyboardType: TextInputType.number,
          ),
        ];

      case 'Beauty and Personal Care':
        return [
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Product Type *', border: OutlineInputBorder()),
            value: _dynamicValues['beautyType'],
            items: [
              'Skincare','Makeup','Hair Care','Perfume','Tools & Accessories','Other'
            ].map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['beautyType'] = v ?? ''),
            validator: (v) => v == null ? 'Select product type' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('brand'),
            decoration: const InputDecoration(
              labelText: 'Brand',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Condition', border: OutlineInputBorder()),
            value: _dynamicValues['condition'],
            items: ['New', 'Like New', 'Used', 'Sample Size']
                .map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['condition'] = v ?? ''),
          ),
        ];

      case 'Jobs':
        return [
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Job Type *', border: OutlineInputBorder()),
            value: _dynamicValues['jobType'],
            items: [
              'Full-time','Part-time','Contract','Internship','Freelance','Remote'
            ].map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['jobType'] = v ?? ''),
            validator: (v) => v == null ? 'Select job type' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('salary'),
            decoration: const InputDecoration(
              labelText: 'Salary Range',
              hintText: 'e.g. \$500 - \$1000 / month',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('experience'),
            decoration: const InputDecoration(
              labelText: 'Experience Required',
              hintText: 'e.g. 2-3 years',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('qualifications'),
            decoration: const InputDecoration(
              labelText: 'Qualifications',
              hintText: 'e.g. Bachelor degree in...',
              border: OutlineInputBorder(),
            ),
          ),
        ];

      case 'Babies and Kids':
        return [
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Item Type *', border: OutlineInputBorder()),
            value: _dynamicValues['itemType'],
            items: [
              'Clothing','Toys','Furniture','Strollers & Car Seats','Baby Care','Books','Other'
            ].map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['itemType'] = v ?? ''),
            validator: (v) => v == null ? 'Select item type' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('ageRange'),
            decoration: const InputDecoration(
              labelText: 'Age Range',
              hintText: 'e.g. 0-6 months, 2-4 years',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Gender', border: OutlineInputBorder()),
            value: _dynamicValues['gender'],
            items: ['Unisex','Boys','Girls']
                .map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['gender'] = v ?? ''),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Condition', border: OutlineInputBorder()),
            value: _dynamicValues['condition'],
            items: ['New','Like New','Good','Fair']
                .map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['condition'] = v ?? ''),
          ),
        ];

      case 'Services':
        return [
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Service Type *', border: OutlineInputBorder()),
            value: _dynamicValues['serviceType'],
            items: [
              'Cleaning','Tutoring','Event Planning','Photography','Catering','Transport','IT Services','Legal','Accounting','Other'
            ].map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['serviceType'] = v ?? ''),
            validator: (v) => v == null ? 'Select service type' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('availability'),
            decoration: const InputDecoration(
              labelText: 'Availability',
              hintText: 'e.g. Weekdays, Weekends, Flexible',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('serviceArea'),
            decoration: const InputDecoration(
              labelText: 'Service Area',
              hintText: 'Areas you cover',
              border: OutlineInputBorder(),
            ),
          ),
        ];

      case 'Leisure Activities':
        return [
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Activity Type *', border: OutlineInputBorder()),
            value: _dynamicValues['activityType'],
            items: [
              'Sports Equipment','Musical Instruments','Books & Media','Games','Outdoor Gear','Art & Craft','Other'
            ].map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['activityType'] = v ?? ''),
            validator: (v) => v == null ? 'Select activity type' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('brand'),
            decoration: const InputDecoration(
              labelText: 'Brand/Manufacturer',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Condition', border: OutlineInputBorder()),
            value: _dynamicValues['condition'],
            items: ['New','Like New','Good','Fair','Poor']
                .map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['condition'] = v ?? ''),
          ),
        ];

      case 'Repair and Construction':
        return [
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Category *', border: OutlineInputBorder()),
            value: _dynamicValues['repairCategory'],
            items: [
              'Tools','Building Materials','Hardware','Electrical','Plumbing','Paint & Finishes','Services','Other'
            ].map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['repairCategory'] = v ?? ''),
            validator: (v) => v == null ? 'Select category' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('brand'),
            decoration: const InputDecoration(
              labelText: 'Brand',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('quantity'),
            decoration: const InputDecoration(
              labelText: 'Quantity Available',
              border: OutlineInputBorder(),
            ),
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Condition', border: OutlineInputBorder()),
            value: _dynamicValues['condition'],
            items: ['New','Used - Like New','Used - Good','Used - Fair']
                .map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['condition'] = v ?? ''),
          ),
        ];

      case 'Home Furniture and Appliances':
        return [
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Item Type *', border: OutlineInputBorder()),
            value: _dynamicValues['furnitureType'],
            items: [
              'Living Room','Bedroom','Kitchen','Dining','Office','Outdoor','Appliances','Decor','Other'
            ].map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['furnitureType'] = v ?? ''),
            validator: (v) => v == null ? 'Select item type' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('brand'),
            decoration: const InputDecoration(
              labelText: 'Brand/Manufacturer',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('dimensions'),
            decoration: const InputDecoration(
              labelText: 'Dimensions',
              hintText: 'L x W x H',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Condition', border: OutlineInputBorder()),
            value: _dynamicValues['condition'],
            items: ['New','Like New','Good','Fair','Needs Repair']
                .map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['condition'] = v ?? ''),
          ),
        ];

      case 'Pets':
        return [
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Category *', border: OutlineInputBorder()),
            value: _dynamicValues['petCategory'],
            items: [
              'Dogs','Cats','Birds','Fish','Reptiles','Small Animals','Pet Supplies','Pet Services','Other'
            ].map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['petCategory'] = v ?? ''),
            validator: (v) => v == null ? 'Select category' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('breed'),
            decoration: const InputDecoration(
              labelText: 'Breed/Type',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('age'),
            decoration: const InputDecoration(
              labelText: 'Age',
              hintText: 'e.g. 2 months, 1 year',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Gender', border: OutlineInputBorder()),
            value: _dynamicValues['petGender'],
            items: ['Male','Female','Unknown']
                .map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['petGender'] = v ?? ''),
          ),
        ];

      case 'Electronics':
        return [
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Electronics Type *', border: OutlineInputBorder()),
            value: _dynamicValues['electronicsType'],
            items: [
              'TV & Video','Audio','Cameras','Computers','Gaming','Home Appliances','Other'
            ].map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['electronicsType'] = v ?? ''),
            validator: (v) => v == null ? 'Select type' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('brand'),
            decoration: const InputDecoration(
              labelText: 'Brand',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('model'),
            decoration: const InputDecoration(
              labelText: 'Model',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Condition', border: OutlineInputBorder()),
            value: _dynamicValues['condition'],
            items: ['New','Like New','Good','Fair','For Parts']
                .map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['condition'] = v ?? ''),
          ),
        ];

      case 'Phones and Tablets':
        return [
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Device Type *', border: OutlineInputBorder()),
            value: _dynamicValues['deviceType'],
            items: [
              'Smartphone','Tablet','Smart Watch','Accessories','Other'
            ].map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['deviceType'] = v ?? ''),
            validator: (v) => v == null ? 'Select device type' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('brand'),
            decoration: const InputDecoration(
              labelText: 'Brand *',
              hintText: 'e.g. Apple, Samsung',
              border: OutlineInputBorder(),
            ),
            validator: (v) => v!.isEmpty ? 'Required' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('model'),
            decoration: const InputDecoration(
              labelText: 'Model *',
              hintText: 'e.g. iPhone 14, Galaxy S23',
              border: OutlineInputBorder(),
            ),
            validator: (v) => v!.isEmpty ? 'Required' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('storage'),
            decoration: const InputDecoration(
              labelText: 'Storage Capacity',
              hintText: 'e.g. 128GB, 256GB',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Condition', border: OutlineInputBorder()),
            value: _dynamicValues['condition'],
            items: ['New','Like New','Good','Fair','For Parts']
                .map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['condition'] = v ?? ''),
          ),
        ];

      case 'Seeking Work and CVs':
        return [
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Job Category *', border: OutlineInputBorder()),
            value: _dynamicValues['jobCategory'],
            items: [
              'Administration','Finance','IT','Sales','Marketing','Engineering','Healthcare','Education','Other'
            ].map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['jobCategory'] = v ?? ''),
            validator: (v) => v == null ? 'Select job category' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('experience'),
            decoration: const InputDecoration(
              labelText: 'Years of Experience',
              border: OutlineInputBorder(),
            ),
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('qualifications'),
            decoration: const InputDecoration(
              labelText: 'Qualifications',
              hintText: 'Education and certifications',
              border: OutlineInputBorder(),
            ),
            maxLines: 2,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('expectedSalary'),
            decoration: const InputDecoration(
              labelText: 'Expected Salary',
              hintText: 'e.g. \$500 - \$800',
              border: OutlineInputBorder(),
            ),
          ),
        ];

      case 'Fashion':
        return [
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Category *', border: OutlineInputBorder()),
            value: _dynamicValues['fashionCategory'],
            items: [
              'Men\'s Clothing','Women\'s Clothing','Shoes','Bags','Accessories','Jewelry','Watches','Other'
            ].map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['fashionCategory'] = v ?? ''),
            validator: (v) => v == null ? 'Select category' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('brand'),
            decoration: const InputDecoration(
              labelText: 'Brand',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('size'),
            decoration: const InputDecoration(
              labelText: 'Size',
              hintText: 'e.g. S, M, L, XL or shoe size',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Condition', border: OutlineInputBorder()),
            value: _dynamicValues['condition'],
            items: [
              'New with Tags','New without Tags','Like New','Good','Fair'
            ].map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['condition'] = v ?? ''),
          ),
        ];

      case 'Food Agriculture and Drinks':
        return [
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Category *', border: OutlineInputBorder()),
            value: _dynamicValues['foodCategory'],
            items: [
              'Fresh Produce','Grains & Cereals','Livestock','Poultry','Dairy Products','Processed Foods','Beverages','Seeds & Plants','Other'
            ].map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['foodCategory'] = v ?? ''),
            validator: (v) => v == null ? 'Select category' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('quantity'),
            decoration: const InputDecoration(
              labelText: 'Quantity',
              hintText: 'e.g. 50kg, 10 liters, 20 pieces',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _getController('harvestDate'),
            decoration: const InputDecoration(
              labelText: 'Harvest/Production Date',
              hintText: 'When was it produced',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                labelText: 'Organic', border: OutlineInputBorder()),
            value: _dynamicValues['organic'],
            items: ['Yes','No','Partially']
                .map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) => setState(() => _dynamicValues['organic'] = v ?? ''),
          ),
        ];

      default:
        return [];
    }
  }

  /* ---------- 本地发布（不走云端） ---------- */
  void _publishLocalOnly() {
    if (!_formKey.currentState!.validate()) return;
    if (_images.isEmpty) {
      _toast('Please upload at least one photo.');
      return;
    }
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    final listing = {
      'id': id,
      'category': _category,
      'images': _images.map((e) => e.path).toList(),
      'title': _titleCtrl.text.trim(),
      'price': '\$${_priceCtrl.text.trim()}',
      'location': _city,
      'postedDate': DateTime.now().toIso8601String(),
      'description': _descCtrl.text.trim(),
      'sellerName': _nameCtrl.text.trim(),
      'sellerPhone': _phoneCtrl.text.trim(),
    };
    ListingStore.i.add(listing);
    _toast('Posted locally (mock data).');
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => pd.ProductDetailPage(productId: id, productData: listing),
      ),
    );
  }

  /* ---------- 远程提交（上传图片 + 写库 + 跳转详情） ---------- */
  Future<void> _submitListing() async {
    if (_submitting) return;
    if (!_formKey.currentState!.validate()) return;
    if (_images.isEmpty) {
      _toast('Please upload at least one photo.');
      return;
    }

    if (!kUploadToRemote) {
      _publishLocalOnly();
      return;
    }

    setState(() {
      _submitting = true;
      _progressMsg = 'Preparing...';
    });

    try {
      // 确保拿到 userId（匿名登录兜底）
      final auth = Supabase.instance.client.auth;
      if (auth.currentUser == null) {
        await auth.signInAnonymously();
      }
      final userId = auth.currentUser!.id;

      // 1) 上传图片（File 化）
      final files = _images.map((x) => File(x.path)).toList();
      int lastShown = 0;
      final urls = await ListingApi.uploadListingImages(
        files: files,
        userId: userId,
        onProgress: (done, total) {
          if (!mounted) return;
          if (done != lastShown) {
            lastShown = done;
            setState(() => _progressMsg = 'Uploading photos $done / $total');
          }
        },
      );

      // 2) 组装附加字段，拼到描述尾部（避免改表结构）
      final extrasLines = <String>[];
      for (final entry in _dynamicControllers.entries) {
        final v = entry.value.text.trim();
        if (v.isNotEmpty) extrasLines.add('${entry.key}: $v');
      }
      _dynamicValues.forEach((k, v) {
        final vv = v.trim();
        if (vv.isNotEmpty) extrasLines.add('$k: $vv');
      });
      final extrasText = extrasLines.isEmpty ? '' : '\n\n---\nExtras:\n${extrasLines.join('\n')}';
      final desc = '${_descCtrl.text.trim()}$extrasText';

      // 3) 插入 listings（按 listing_api.dart 的字段）
      setState(() => _progressMsg = 'Saving item...');
      final priceText = _priceCtrl.text.trim().replaceAll(',', '');
      num? price = priceText.isEmpty ? null : num.tryParse(priceText);

      final row = await ListingApi.insertListing(
        title: _titleCtrl.text.trim(),
        price: price,
        category: _category,
        city: _city,
        description: desc,
        imageUrls: urls,
        userId: userId,
        sellerName: _nameCtrl.text.trim().isEmpty ? null : _nameCtrl.text.trim(),
        contactPhone: _phoneCtrl.text.trim().isEmpty ? null : _phoneCtrl.text.trim(),
      );

      if (!mounted) return;

      _toast('Posted successfully!');

      // 4) 跳到详情页（适配你的详情字段名）
      final productId = row['id'].toString();
      final productData = {
        'id': productId,
        'category': row['category'] ?? '',
        'images': List<String>.from(row['images'] ?? []),
        'title': row['title'] ?? '',
        'price': row['price'] == null ? '' : '\$${(row['price'] as num).toStringAsFixed(2)}',
        'location': row['city'] ?? '',
        'postedDate': row['created_at'] ?? DateTime.now().toIso8601String(),
        'description': row['description'] ?? '',
        'sellerName': row['seller_name'] ?? _nameCtrl.text.trim(),
        'sellerPhone': row['contact_phone'] ?? _phoneCtrl.text.trim(),
      };

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => pd.ProductDetailPage(
            productId: productId,
            productData: productData,
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      _toast('Post failed: $e');
    } finally {
      if (mounted) {
        setState(() {
          _submitting = false;
          _progressMsg = '';
        });
      }
    }
  }

  /* ---------- 选图（相机或相册） ---------- */
  Future<void> _pickImage() async {
    if (_images.length >= _maxPhotos) {
      _toast('You can upload up to $_maxPhotos photos.');
      return;
    }
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return SafeArea(
          child: Wrap(
            children: <Widget>[
              ListTile(
                leading: const Icon(Icons.photo_camera),
                title: const Text('Take Photo'),
                onTap: () async {
                  Navigator.of(context).pop();
                  final file = await _picker.pickImage(
                    source: ImageSource.camera,
                    imageQuality: 80,
                  );
                  if (file != null && mounted) {
                    if (_images.length >= _maxPhotos) {
                      _toast('You can upload up to $_maxPhotos photos.');
                      return;
                    }
                    setState(() => _images.add(file));
                  }
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo_library),
                title: const Text('Choose from Gallery'),
                onTap: () async {
                  Navigator.of(context).pop();
                  final file = await _picker.pickImage(
                    source: ImageSource.gallery,
                    imageQuality: 80,
                  );
                  if (file != null && mounted) {
                    if (_images.length >= _maxPhotos) {
                      _toast('You can upload up to $_maxPhotos photos.');
                      return;
                    }
                    setState(() => _images.add(file));
                  }
                },
              ),
              ListTile(
                leading: const Icon(Icons.cancel),
                title: const Text('Cancel'),
                onTap: () => Navigator.of(context).pop(),
              ),
            ],
          ),
        );
      },
    );
  }

  /* ---------- 释放资源 ---------- */
  @override
  void dispose() {
    _titleCtrl.dispose();
    _priceCtrl.dispose();
    _descCtrl.dispose();
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    for (final c in _dynamicControllers.values) {
      c.dispose();
    }
    super.dispose();
  }

  void _toast(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  /* ------------------ UI ------------------ */
  @override
  Widget build(BuildContext context) {
    final categoryFields = _getCategorySpecificFields(); // ✅ 避免重复调用
    return Scaffold(
      appBar: AppBar(title: const Text('New Advert')),
      body: Stack(
        children: [
          AbsorbPointer(
            absorbing: _submitting,
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // 图片上传区域
                    const Text('Photos',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    const SizedBox(height: 8),
                    const Text(
                      'Add up to 10 photos. First photo will be the main image.',
                      style: TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                    const SizedBox(height: 12),

                    Container(
                      constraints: const BoxConstraints(minHeight: 100),
                      child: Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          ..._images.asMap().entries.map((entry) {
                            final index = entry.key;
                            final file = entry.value;
                            return Stack(
                              children: [
                                Container(
                                  width: 100,
                                  height: 100,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(8),
                                    border: index == 0
                                        ? Border.all(
                                      color: Theme.of(context).primaryColor,
                                      width: 2,
                                    )
                                        : null,
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(8),
                                    child: Stack(
                                      fit: StackFit.expand,
                                      children: [
                                        Image.file(
                                          File(file.path),
                                          fit: BoxFit.cover,
                                        ),
                                        if (index == 0)
                                          Positioned(
                                            bottom: 0,
                                            left: 0,
                                            right: 0,
                                            child: Container(
                                              color: Theme.of(context)
                                                  .primaryColor
                                                  .withOpacity(0.8),
                                              padding: const EdgeInsets.symmetric(vertical: 2),
                                              child: const Text(
                                                'Main Photo',
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 10,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),
                                ),
                                Positioned(
                                  right: -4,
                                  top: -4,
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      shape: BoxShape.circle,
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.black.withOpacity(0.2),
                                          blurRadius: 4,
                                        ),
                                      ],
                                    ),
                                    child: IconButton(
                                      icon: const Icon(Icons.close, size: 18, color: Colors.red),
                                      padding: const EdgeInsets.all(4),
                                      constraints: const BoxConstraints(),
                                      onPressed: () => setState(() => _images.removeAt(index)),
                                    ),
                                  ),
                                ),
                              ],
                            );
                          }),
                          if (_images.length < _maxPhotos)
                            GestureDetector(
                              onTap: _pickImage,
                              child: Container(
                                width: 100,
                                height: 100,
                                decoration: BoxDecoration(
                                  color: Colors.grey[100],
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: Colors.grey[300]!, width: 2),
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(Icons.add_a_photo, color: Colors.grey[600], size: 28),
                                    const SizedBox(height: 4),
                                    Text('Add Photo', style: TextStyle(fontSize: 11, color: Colors.grey[600])),
                                  ],
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),
                    const Divider(),
                    const SizedBox(height: 16),

                    // 分类下拉
                    DropdownButtonFormField<String>(
                      decoration: const InputDecoration(
                          labelText: 'Category *', border: OutlineInputBorder()),
                      value: _category.isEmpty ? null : _category,
                      items: _categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                      onChanged: (v) {
                        setState(() {
                          _category = v ?? '';
                          _dynamicValues.clear();
                          for (final c in _dynamicControllers.values) {
                            c.clear();
                          }
                        });
                      },
                      validator: (_) => _category.isEmpty ? 'Please select category' : null,
                    ),
                    const SizedBox(height: 16),

                    // 动态字段
                    ...categoryFields,
                    if (categoryFields.isNotEmpty) const SizedBox(height: 16),

                    // 标题
                    TextFormField(
                      controller: _titleCtrl,
                      decoration: const InputDecoration(labelText: 'Title *', border: OutlineInputBorder()),
                      validator: (v) => v!.isEmpty ? 'Required' : null,
                    ),
                    const SizedBox(height: 16),

                    // 价格
                    TextFormField(
                      controller: _priceCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Price (USD) *',
                        prefixText: '\$ ',
                        border: OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.number,
                      validator: (v) => v!.isEmpty ? 'Required' : null,
                    ),
                    const SizedBox(height: 16),

                    // 城市
                    DropdownButtonFormField<String>(
                      decoration: const InputDecoration(labelText: 'Region *', border: OutlineInputBorder()),
                      value: _city,
                      items: _cities.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                      onChanged: (v) => setState(() => _city = v!),
                    ),
                    const SizedBox(height: 16),

                    // 描述
                    TextFormField(
                      controller: _descCtrl,
                      decoration: const InputDecoration(labelText: 'Description', border: OutlineInputBorder()),
                      maxLines: 3,
                    ),
                    const SizedBox(height: 24),

                    // 卖家信息
                    const Text('Seller Information', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    const SizedBox(height: 12),

                    TextFormField(
                      controller: _nameCtrl,
                      decoration: const InputDecoration(labelText: 'Your Name *', border: OutlineInputBorder()),
                      validator: (v) => v!.isEmpty ? 'Required' : null,
                    ),
                    const SizedBox(height: 16),

                    TextFormField(
                      controller: _phoneCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Phone Number *',
                        hintText: '+263 77 123 4567',
                        border: OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.phone,
                      validator: (v) => v!.isEmpty ? 'Required' : null,
                    ),
                    const SizedBox(height: 24),

                    // 发布按钮（开关决定本地/远程）
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton(
                        onPressed: _submitting ? null : (kUploadToRemote ? _submitListing : _publishLocalOnly),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Theme.of(context).primaryColor,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        ),
                        child: _submitting
                            ? const SizedBox(
                          height: 22,
                          width: 22,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                        )
                            : const Text(
                          'Post Advertisement',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                    const SizedBox(height: 32),
                  ],
                ),
              ),
            ),
          ),

          // 提交遮罩与进度
          if (_submitting)
            Container(
              color: Colors.black.withOpacity(0.08),
              alignment: Alignment.center,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const CircularProgressIndicator(),
                  const SizedBox(height: 12),
                  Text(
                    _progressMsg,
                    style: const TextStyle(fontSize: 13),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}