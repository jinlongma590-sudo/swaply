// lib/pages/category_products_page.dart - Cloud-only listings + Pinned Ads
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:swaply/config.dart'; // 可留着，不影响
import 'package:swaply/pages/product_detail_page.dart';
import 'package:swaply/listing_api.dart';
import 'package:swaply/services/coupon_service.dart';
import 'package:swaply/widgets/pinned_ad_card.dart';

class CategoryProductsPage extends StatefulWidget {
  final String categoryId;   // 如: 'jobs', 'vehicles', 'phones'...
  final String categoryName; // AppBar 显示

  const CategoryProductsPage({
    super.key,
    required this.categoryId,
    required this.categoryName,
  });

  @override
  State<CategoryProductsPage> createState() => _CategoryProductsPageState();
}

class _CategoryProductsPageState extends State<CategoryProductsPage> {
  String _selectedSort = 'newest';            // newest | price_low | price_high
  String _selectedLocation = 'All Zimbabwe';

  final List<String> _locations = const [
    'All Zimbabwe','Harare','Bulawayo','Chitungwiza','Mutare','Gweru','Kwekwe',
    'Kadoma','Masvingo','Chinhoyi','Chegutu','Bindura','Marondera','Redcliff',
  ];

  final List<Map<String, dynamic>> _items = [];
  List<Map<String, dynamic>> _pinnedAds = [];
  bool _loading = false;
  bool _loadingMore = false;
  bool _loadingPinned = false;
  bool _hasMore = true;
  String? _error;

  int? _totalCount;

  static const int _pageSize = 24;
  int _offset = 0;
  final ScrollController _scroll = ScrollController();

  @override
  void initState() {
    super.initState();
    _loadInitial();
    _loadPinnedAds();
    _scroll.addListener(() {
      if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 200) {
        _loadMore();
      }
    });
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  String _categoryIdToDb(String id) {
    const map = {
      'vehicles': 'Vehicles',
      'property': 'Property',
      'beauty_personal_care': 'Beauty and Personal Care',
      'jobs': 'Jobs',
      'babies_kids': 'Babies and Kids',
      'services': 'Services',
      'leisure_activities': 'Leisure Activities',
      'repair_construction': 'Repair and Construction',
      'home_furniture_appliances': 'Home Furniture and Appliances',
      'pets': 'Pets',
      'electronics': 'Electronics',
      'phones': 'Phones and Tablets',
      'seeking_work_cvs': 'Seeking Work and CVs',
      'fashion': 'Fashion',
      'food_agriculture_drinks': 'Food Agriculture and Drinks',
    };
    return map[id] ?? widget.categoryName;
  }

  /* ============== 云端置顶广告 ============== */
  Future<void> _loadPinnedAds() async {
    setState(() => _loadingPinned = true);
    try {
      final categoryDb = _categoryIdToDb(widget.categoryId);
      final city = _selectedLocation == 'All Zimbabwe' ? null : _selectedLocation;

      final pinnedAds = await CouponService.getPinnedAds(
        category: categoryDb,
        city: city,
        limit: 6,
      );

      setState(() => _pinnedAds = pinnedAds);
    } catch (e) {
      debugPrint('Error loading pinned ads: $e');
    } finally {
      if (mounted) setState(() => _loadingPinned = false);
    }
  }

  /* ============== 云端列表 ============== */

  Future<void> _loadInitial() async {
    setState(() {
      _loading = true;
      _error = null;
      _items.clear();
      _offset = 0;
      _hasMore = true;
      _totalCount = null;
    });

    try {
      final futures = <Future>[];
      futures.add(_fetchPage(offset: 0).then((list) {
        _items.addAll(list);
        _sortInMemory();
        _hasMore = list.length >= _pageSize;
        _offset = list.length;
      }));
      futures.add(_refreshTotalCount());
      await Future.wait(futures);
    } catch (e) {
      _error = e.toString();
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _loadMore() async {
    if (_loading || _loadingMore || !_hasMore) return;
    setState(() => _loadingMore = true);
    try {
      final list = await _fetchPage(offset: _offset);
      setState(() {
        _items.addAll(list);
        _sortInMemory();
        _hasMore = list.length >= _pageSize;
        _offset += list.length;
      });
    } finally {
      if (mounted) setState(() => _loadingMore = false);
    }
  }

  Future<void> _refreshTotalCount() async {
    final categoryDb = _categoryIdToDb(widget.categoryId);
    final city = _selectedLocation == 'All Zimbabwe' ? null : _selectedLocation;
    final total = await ListingApi.countListings(category: categoryDb, city: city);
    if (mounted) setState(() => _totalCount = total);
  }

  Future<List<Map<String, dynamic>>> _fetchPage({required int offset}) async {
    final categoryDb = _categoryIdToDb(widget.categoryId);
    final city = _selectedLocation == 'All Zimbabwe' ? null : _selectedLocation;

    // 排序映射（与你原逻辑一致）
    String orderBy = 'created_at';
    bool ascending = false;
    switch (_selectedSort) {
      case 'price_low':
        orderBy = 'price';
        ascending = true;
        break;
      case 'price_high':
        orderBy = 'price';
        ascending = false;
        break;
      default:
        orderBy = 'created_at';
        ascending = false;
    }

    final rows = await ListingApi.fetchListings(
      category: categoryDb,
      city: city,
      limit: _pageSize,
      offset: offset,
      orderBy: orderBy,
      ascending: ascending,
      status: 'active',
    );

    return rows.map<Map<String, dynamic>>((r) {
      final num? priceNum = r['price'] is num ? (r['price'] as num) : null;
      final priceText = priceNum != null ? '\$${priceNum.toStringAsFixed(0)}' : (r['price']?.toString() ?? '');
      final imgs = (r['images'] as List?) ?? (r['image_urls'] as List?) ?? const <String>[];

      return {
        'id': r['id'],
        'title': r['title'] ?? '',
        'price': priceText,
        'price_num': priceNum,
        'location': r['city'] ?? '',
        'images': List<String>.from(imgs.map((e) => e.toString())),
        'postedDate': r['created_at'] ?? r['posted_at'],
        'full': r,
      };
    }).toList();
  }

  /* ---------- 前端排序（保持原逻辑） ---------- */
  void _sortInMemory() {
    if (_items.isEmpty) return;
    if (_selectedSort == 'price_low') {
      _items.sort((a, b) {
        final an = (a['price_num'] as num?) ?? 1e15;
        final bn = (b['price_num'] as num?) ?? 1e15;
        return an.compareTo(bn);
      });
    } else if (_selectedSort == 'price_high') {
      _items.sort((a, b) {
        final an = (a['price_num'] as num?) ?? -1e15;
        final bn = (b['price_num'] as num?) ?? -1e15;
        return bn.compareTo(an);
      });
    } else {
      _items.sort((a, b) {
        final sa = (a['postedDate'] ?? '').toString();
        final sb = (b['postedDate'] ?? '').toString();
        DateTime? da, db;
        try { da = DateTime.tryParse(sa); } catch (_) {}
        try { db = DateTime.tryParse(sb); } catch (_) {}
        if (da == null || db == null) return 0;
        return db.compareTo(da);
      });
    }
  }

  /* =========================  UI（保持原跳转） ========================= */

  void _openSortSheet() { /* 原实现保持 */
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 12),
            Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2))),
            const Padding(padding: EdgeInsets.all(20), child: Text('Sort by', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
            _sortTile('Newest first', 'newest'),
            _sortTile('Price: Low to High', 'price_low'),
            _sortTile('Price: High to Low', 'price_high'),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  ListTile _sortTile(String title, String value) {
    final selected = _selectedSort == value;
    return ListTile(
      title: Text(title),
      trailing: selected ? const Icon(Icons.check, color: Color(0xFF2196F3)) : null,
      onTap: () {
        setState(() => _selectedSort = value);
        Navigator.pop(context);
        _sortInMemory();
      },
    );
  }

  void _openLocationSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: ListView(
          shrinkWrap: true,
          children: [
            const SizedBox(height: 12),
            Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2)))),
            const Padding(padding: EdgeInsets.all(20), child: Text('Select Location', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
            ..._locations.map((loc) {
              final selected = _selectedLocation == loc;
              return ListTile(
                title: Text(loc),
                trailing: selected ? const Icon(Icons.check, color: Color(0xFF2196F3)) : null,
                onTap: () {
                  setState(() => _selectedLocation = loc);
                  Navigator.pop(context);
                  _loadInitial();
                  _loadPinnedAds();
                },
              );
            }),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final title = widget.categoryName;

    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: const Color(0xFF2196F3),
        title: Text(title, style: const TextStyle(color: Colors.white)),
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: Colors.white), onPressed: () => Navigator.pop(context)),
        actions: [IconButton(icon: const Icon(Icons.search, color: Colors.white), onPressed: () {})],
      ),
      body: Column(
        children: [
          // 筛选栏
          Container(
            color: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: InkWell(
                    onTap: _openLocationSheet,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(border: Border.all(color: Colors.grey[300]!), borderRadius: BorderRadius.circular(8)),
                      child: Row(
                        children: [
                          const Icon(Icons.location_on, size: 18, color: Colors.grey),
                          const SizedBox(width: 6),
                          Expanded(child: Text(_selectedLocation, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14))),
                          const Icon(Icons.arrow_drop_down, color: Colors.grey),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                InkWell(
                  onTap: _openSortSheet,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(border: Border.all(color: Colors.grey[300]!), borderRadius: BorderRadius.circular(8)),
                    child: const Row(children: [Icon(Icons.sort, size: 18, color: Colors.grey), SizedBox(width: 6), Text('Sort', style: TextStyle(fontSize: 14))]),
                  ),
                ),
              ],
            ),
          ),

          // 数量栏
          Container(
            alignment: Alignment.centerLeft,
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            color: Colors.grey[50],
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (_totalCount == null)
                  const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                else ...[
                  Text('$_totalCount', style: const TextStyle(color: Colors.grey, fontSize: 14)),
                  const SizedBox(width: 6),
                  Text(_totalCount == 1 ? 'ad found' : 'ads found', style: const TextStyle(color: Colors.grey, fontSize: 14)),
                  if (_pinnedAds.isNotEmpty) ...[
                    const SizedBox(width: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.orange[100],
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.orange[300]!, width: 1),
                      ),
                      child: Text('${_pinnedAds.length} pinned', style: TextStyle(color: Colors.orange[700], fontSize: 11, fontWeight: FontWeight.w500)),
                    ),
                  ],
                ],
              ],
            ),
          ),

          Expanded(
            child: RefreshIndicator(
              onRefresh: () async {
                await _loadInitial();
                await _loadPinnedAds();
              },
              child: _buildBody(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (_loading && _items.isEmpty && _pinnedAds.isEmpty) return _skeleton();
    if (_error != null) {
      return Center(child: Text('Load failed: $_error', style: const TextStyle(color: Colors.red)));
    }
    if (_items.isEmpty && _pinnedAds.isEmpty && !_loading) {
      return const Center(child: Text('No ads yet'));
    }

    return CustomScrollView(
      controller: _scroll,
      slivers: [
        // 置顶广告区域
        if (_pinnedAds.isNotEmpty || _loadingPinned)
          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 置顶广告标题
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Row(
                    children: [
                      const Text('Featured Ads', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.orange[100],
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.orange[300]!, width: 1),
                        ),
                        child: const Text('PINNED', style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold, color: Colors.orange, letterSpacing: 0.5)),
                      ),
                      const Spacer(),
                      Icon(Icons.push_pin, color: Colors.orange[600], size: 18),
                    ],
                  ),
                ),

                // 置顶广告网格
                if (_loadingPinned) _buildPinnedAdsLoading() else _buildPinnedAdsGrid(),

                // 分隔线
                if (_pinnedAds.isNotEmpty)
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                    height: 1,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [Colors.transparent, Colors.orange[300]!, Colors.transparent]),
                    ),
                  ),
              ],
            ),
          ),

        // 普通广告标题
        if (_items.isNotEmpty)
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
              child: Text('All Ads', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: Colors.grey[700])),
            ),
          ),

        // 普通广告网格
        SliverPadding(
          padding: const EdgeInsets.all(16),
          sliver: SliverGrid(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, childAspectRatio: 0.75, crossAxisSpacing: 16, mainAxisSpacing: 16,
            ),
            delegate: SliverChildBuilderDelegate((context, i) {
              if (i >= _items.length) return _loadingTile();
              final p = _items[i];
              return GestureDetector(
                onTap: () => _openDetail(p), // ★ 保持原跳转
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [BoxShadow(color: Colors.black.withAlpha(20), blurRadius: 6, offset: const Offset(0, 2))],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(child: ClipRRect(borderRadius: const BorderRadius.vertical(top: Radius.circular(14)), child: _thumb(p))),
                      Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(p['price']?.toString() ?? '', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.green)),
                            const SizedBox(height: 4),
                            Text(p['title']?.toString() ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14)),
                            const SizedBox(height: 3),
                            Row(children: [
                              const Icon(Icons.location_on, size: 12, color: Colors.grey),
                              const SizedBox(width: 2),
                              Expanded(child: Text(p['location']?.toString() ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: Colors.grey))),
                            ]),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }, childCount: _items.length + (_loadingMore ? 1 : 0)),
          ),
        ),
      ],
    );
  }

  // 构建置顶广告网格
  Widget _buildPinnedAdsGrid() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GridView.builder(
        physics: const NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, childAspectRatio: 0.75, crossAxisSpacing: 12, mainAxisSpacing: 12,
        ),
        itemCount: _pinnedAds.length,
        itemBuilder: (context, index) {
          final pinnedAd = _pinnedAds[index];
          final listing = pinnedAd['listings'] as Map<String, dynamic>;

          return PinnedAdCard(
            listingData: listing,
            pinnedData: pinnedAd,
            onTap: () => _openDetail({
              'id': listing['id'],
              'title': listing['title'],
              'price': listing['price'],
              'location': listing['city'],
              'images': listing['images'],
              'full': listing,
            }),
          );
        },
      ),
    );
  }

  // 置顶广告加载状态
  Widget _buildPinnedAdsLoading() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GridView.builder(
        physics: const NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, childAspectRatio: 0.75, crossAxisSpacing: 12, mainAxisSpacing: 12,
        ),
        itemCount: 4,
        itemBuilder: (context, index) {
          return Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.orange[300]!, width: 2),
              boxShadow: [BoxShadow(color: Colors.orange.withAlpha(30), blurRadius: 8, offset: const Offset(0, 2))],
            ),
            child: Column(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(color: Colors.grey[300], borderRadius: const BorderRadius.vertical(top: Radius.circular(12))),
                    child: const Center(child: CircularProgressIndicator(strokeWidth: 2)),
                  ),
                ),
                Container(
                  height: 80, padding: const EdgeInsets.all(12),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Container(height: 14, width: 80, color: Colors.grey[300]),
                    const SizedBox(height: 6),
                    Container(height: 12, width: 120, color: Colors.grey[200]),
                  ]),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _thumb(Map<String, dynamic> p) {
    final imgs = p['images'];
    String? src;
    if (imgs is List && imgs.isNotEmpty) {
      src = imgs.first.toString();
    } else if (p['image'] != null) {
      src = p['image'].toString();
    }
    if (src == null || src.isEmpty) return _imgPlaceholderCover();
    if (src.startsWith('http')) {
      return SizedBox.expand(child: Image.network(src, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _imgPlaceholderCover()));
    } else if (src.startsWith('/') || src.startsWith('file:')) {
      return SizedBox.expand(child: Image.file(File(src.replaceFirst('file://', '')), fit: BoxFit.cover, errorBuilder: (_, __, ___) => _imgPlaceholderCover()));
    } else {
      return SizedBox.expand(child: Image.asset(src, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _imgPlaceholderCover()));
    }
  }

  Widget _imgPlaceholderCover() => SizedBox.expand(
    child: Container(color: Colors.grey[300], child: const Center(child: Icon(Icons.image, size: 50, color: Colors.grey))),
  );

  void _openDetail(Map<String, dynamic> item) {
    final full = (item['full'] as Map?) ?? {};
    final images = (item['images'] as List?) ?? [];
    final pdData = {
      'id': item['id'],
      'title': item['title'],
      'price': item['price'],
      'location': item['location'],
      'images': images,
      'postedDate': item['postedDate'] ?? full['created_at'],
      'description': full['description'] ?? '',
      'sellerName': full['name'] ?? '',
      'sellerPhone': full['phone'] ?? '',
      'category': full['category'] ?? '',
    };
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ProductDetailPage(
          productId: item['id']?.toString(),
          productData: pdData,
        ),
      ),
    );
  }

  Widget _loadingTile() => Container(
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
    child: const Center(child: CircularProgressIndicator()),
  );

  Widget _skeleton() => GridView.builder(
    padding: const EdgeInsets.all(16),
    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
      crossAxisCount: 2, childAspectRatio: 0.75, crossAxisSpacing: 16, mainAxisSpacing: 16,
    ),
    itemCount: 6,
    itemBuilder: (_, __) => Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
      child: Column(children: [
        Expanded(child: Container(decoration: BoxDecoration(color: Colors.grey[300], borderRadius: const BorderRadius.vertical(top: Radius.circular(14))))),
        Container(height: 64, padding: const EdgeInsets.all(12), alignment: Alignment.centerLeft,
            child: Container(height: 14, width: 90, color: Colors.grey[300])),
      ]),
    ),
  );
}
