// lib/pages/coupon_management_page.dart - UUID版本（完成版）
import 'package:flutter/material.dart';
import 'package:swaply/models/coupon.dart';
import 'package:swaply/services/coupon_service.dart';

class CouponManagementPage extends StatefulWidget {
  const CouponManagementPage({super.key});

  @override
  State<CouponManagementPage> createState() => _CouponManagementPageState();
}

class _CouponManagementPageState extends State<CouponManagementPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  List<CouponModel> _allCoupons = [];
  List<CouponModel> _activeCoupons = [];
  List<CouponModel> _usedCoupons = [];
  List<Map<String, dynamic>> _myPinnedAds = [];

  bool _loading = false;
  String? _error;
  Map<String, int> _stats = {};

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _loadData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() => _loading = true);
    try {
      final futures = await Future.wait([
        CouponService.getUserCoupons(),
        CouponService.getUserPinnedAds(),
        CouponService.getCouponStats(),
      ]);

      final coupons = futures[0] as List<CouponModel>;
      final pinnedAds = futures[1] as List<Map<String, dynamic>>;
      final stats = futures[2] as Map<String, int>;

      setState(() {
        _allCoupons = coupons;
        _activeCoupons = coupons.where((c) => c.isUsable).toList();
        _usedCoupons =
            coupons.where((c) => c.status == CouponStatus.used).toList();
        _myPinnedAds = pinnedAds;
        _stats = stats;
        _error = null;
      });
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: const Color(0xFF319AFF),
        title: const Text('My Coupons', style: TextStyle(color: Colors.white)),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        bottom: TabBar(
          controller: _tabController,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          indicatorColor: Colors.white,
          tabs: [
            Tab(
              text: 'Active',
              icon: Badge(
                label: Text('${_activeCoupons.length}'),
                child: const Icon(Icons.local_activity),
              ),
            ),
            Tab(
              text: 'Used',
              icon: Badge(
                label: Text('${_usedCoupons.length}'),
                child: const Icon(Icons.check_circle),
              ),
            ),
            Tab(
              text: 'Pinned Ads',
              icon: Badge(
                label: Text('${_myPinnedAds.length}'),
                child: const Icon(Icons.push_pin),
              ),
            ),
            const Tab(
              text: 'Stats',
              icon: Icon(Icons.bar_chart),
            ),
          ],
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
          ? _buildError()
          : TabBarView(
        controller: _tabController,
        children: [
          _buildActiveCouponsTab(),
          _buildUsedCouponsTab(),
          _buildPinnedAdsTab(),
          _buildStatsTab(),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showUseCouponDialog,
        icon: const Icon(Icons.redeem),
        label: const Text('Use Coupon'),
        backgroundColor: Colors.orange,
      ),
    );
  }

  Widget _buildError() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.error, size: 64, color: Colors.red),
          const SizedBox(height: 16),
          Text('Error: $_error'),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: _loadData,
            child: const Text('Retry'),
          ),
        ],
      ),
    );
  }

  Widget _buildActiveCouponsTab() {
    if (_activeCoupons.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.local_activity, size: 64, color: Colors.grey),
            SizedBox(height: 16),
            Text('No active coupons'),
            SizedBox(height: 8),
            Text(
              'Active coupons will appear here when you receive them.',
              style: TextStyle(color: Colors.grey),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadData,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _activeCoupons.length,
        itemBuilder: (context, index) {
          return CouponCard(
            coupon: _activeCoupons[index],
            onUse: () => _useCoupon(_activeCoupons[index]),
          );
        },
      ),
    );
  }

  Widget _buildUsedCouponsTab() {
    if (_usedCoupons.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.check_circle, size: 64, color: Colors.grey),
            SizedBox(height: 16),
            Text('No used coupons'),
            SizedBox(height: 8),
            Text(
              'Coupons you\'ve used will appear here.',
              style: TextStyle(color: Colors.grey),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadData,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _usedCoupons.length,
        itemBuilder: (context, index) {
          return CouponCard(
            coupon: _usedCoupons[index],
            onUse: null, // 已使用的不能再使用
          );
        },
      ),
    );
  }

  Widget _buildPinnedAdsTab() {
    if (_myPinnedAds.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.push_pin, size: 64, color: Colors.grey),
            SizedBox(height: 16),
            Text('No pinned ads'),
            SizedBox(height: 8),
            Text(
              'Your pinned ads will appear here.',
              style: TextStyle(color: Colors.grey),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadData,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _myPinnedAds.length,
        itemBuilder: (context, index) {
          return PinnedAdCard2(
            pinnedAd: _myPinnedAds[index],
            onUnpin: () => _unpinAd(_myPinnedAds[index]),
          );
        },
      ),
    );
  }

  Widget _buildStatsTab() {
    return RefreshIndicator(
      onRefresh: _loadData,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Coupon Statistics',
                      style:
                      TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 16),
                    _buildStatRow(
                        'Total Coupons', _stats['total_coupons'] ?? 0),
                    _buildStatRow(
                        'Active Coupons', _stats['active_coupons'] ?? 0),
                    _buildStatRow(
                        'Used Coupons', _stats['used_coupons'] ?? 0),
                    _buildStatRow(
                        'Expired Coupons', _stats['expired_coupons'] ?? 0),
                    _buildStatRow(
                        'Pinned Coupons', _stats['pinned_coupons'] ?? 0),
                    _buildStatRow(
                        'Usable Coupons', _stats['usable_coupons'] ?? 0),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Pinned Ads Statistics',
                      style:
                      TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 16),
                    _buildStatRow('Currently Pinned', _myPinnedAds.length),
                    _buildStatRow(
                      'Active Pinned',
                      _myPinnedAds
                          .where((ad) => ad['status'] == 'active')
                          .length,
                    ),
                    _buildStatRow(
                      'Expired Pinned',
                      _myPinnedAds
                          .where((ad) => ad['status'] == 'expired')
                          .length,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatRow(String label, int value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text(
            value.toString(),
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Future<void> _useCoupon(CouponModel coupon) async {
    if (coupon.type != CouponType.pinned) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Only pinned ad coupons can be used here'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    // 选择 Listing（UUID 字符串）
    final listingId = await _showListingSelectionDialog();

    if (listingId != null) {
      final success = await CouponService.useCouponForPinning(
        couponId: coupon.id,
        listingId: listingId,
      );

      if (success && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Your ad has been pinned successfully!'),
            backgroundColor: Colors.green,
          ),
        );
        _loadData();
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to pin ad. Please try again.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<String?> _showListingSelectionDialog() async {
    // Demo：返回一个固定 UUID。你可以替换为实际列表选择。
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Select Listing'),
        content: const Text(
          'In a real implementation, this would show your active listings to choose from.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx)
                .pop('550e8400-e29b-41d4-a716-446655440000'),
            child: const Text('Use Demo Listing'),
          ),
        ],
      ),
    );
  }

  Future<void> _unpinAd(Map<String, dynamic> pinnedAd) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Unpin Ad'),
        content: const Text('Are you sure you want to unpin this ad?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Unpin'),
          ),
        ],
      ),
    );

    if (result == true) {
      final listingId = pinnedAd['listing_id']?.toString();
      if (listingId != null) {
        final success = await CouponService.unpinListing(listingId);

        if (success && mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Ad unpinned successfully'),
              backgroundColor: Colors.green,
            ),
          );
          _loadData();
        } else if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Failed to unpin ad'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    }
  }

  void _showUseCouponDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Use Coupon'),
        content: const Text(
          'Select an active coupon from the "Active" tab and tap "Use" to pin one of your ads.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }
}

class CouponCard extends StatelessWidget {
  final CouponModel coupon;
  final VoidCallback? onUse;

  const CouponCard({
    super.key,
    required this.coupon,
    this.onUse,
  });

  @override
  Widget build(BuildContext context) {
    final isUsable = coupon.isUsable;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isUsable ? Colors.orange[300]! : Colors.grey[300]!,
            width: isUsable ? 2 : 1,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: isUsable ? Colors.orange[100] : Colors.grey[100],
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      coupon.type.displayNameEn,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color:
                        isUsable ? Colors.orange[700] : Colors.grey[600],
                      ),
                    ),
                  ),
                  const Spacer(),
                  Container(
                    padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: _getStatusColor(coupon.statusDescription),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      coupon.statusDescription,
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                coupon.title,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                coupon.description,
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey[600],
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Icon(Icons.schedule, size: 16, color: Colors.grey[600]),
                  const SizedBox(width: 4),
                  Text(
                    'Duration: ${coupon.durationDays} days',
                    style:
                    TextStyle(fontSize: 12, color: Colors.grey[600]),
                  ),
                  const SizedBox(width: 16),
                  Icon(Icons.event, size: 16, color: Colors.grey[600]),
                  const SizedBox(width: 4),
                  Text(
                    'Expires: ${coupon.formattedExpiryDate}',
                    style:
                    TextStyle(fontSize: 12, color: Colors.grey[600]),
                  ),
                ],
              ),
              if (isUsable && onUse != null) ...[
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: onUse,
                    icon: const Icon(Icons.redeem),
                    label: const Text('Use This Coupon'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'active':
        return Colors.green;
      case 'used':
        return Colors.blue;
      case 'expired':
        return Colors.red;
      case 'used up':
        return Colors.grey;
      default:
        return Colors.grey;
    }
  }
}

class PinnedAdCard2 extends StatelessWidget {
  final Map<String, dynamic> pinnedAd;
  final VoidCallback? onUnpin;

  const PinnedAdCard2({
    super.key,
    required this.pinnedAd,
    this.onUnpin,
  });

  @override
  Widget build(BuildContext context) {
    final listing = pinnedAd['listings'] as Map<String, dynamic>? ?? {};
    final title = listing['title']?.toString() ?? 'No title';
    final price = listing['price']?.toString() ?? '';
    final city = listing['city']?.toString() ?? '';
    final status = pinnedAd['status']?.toString() ?? '';
    final pinnedUntil =
    DateTime.tryParse(pinnedAd['pinned_until']?.toString() ?? '');

    final isActive =
        status == 'active' && pinnedUntil != null && DateTime.now().isBefore(pinnedUntil);

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isActive ? Colors.orange[300]! : Colors.grey[300]!,
            width: isActive ? 2 : 1,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: isActive ? Colors.orange[100] : Colors.grey[100],
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.push_pin,
                          size: 12,
                          color: isActive ? Colors.orange[700] : Colors.grey[600],
                        ),
                        const SizedBox(width: 4),
                        Text(
                          'PINNED',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: isActive
                                ? Colors.orange[700]
                                : Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Spacer(),
                  Container(
                    padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: isActive ? Colors.green : Colors.red,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      isActive ? 'Active' : 'Expired',
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  if (price.isNotEmpty) ...[
                    Text(
                      price,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                      ),
                    ),
                    const SizedBox(width: 16),
                  ],
                  Icon(Icons.location_on, size: 16, color: Colors.grey[600]),
                  const SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      city,
                      style:
                      TextStyle(fontSize: 14, color: Colors.grey[600]),
                    ),
                  ),
                ],
              ),
              if (pinnedUntil != null) ...[
                const SizedBox(height: 8),
                Row(
                  children: [
                    Icon(Icons.schedule, size: 16, color: Colors.grey[600]),
                    const SizedBox(width: 4),
                    Text(
                      'Pinned until: ${_formatDateTime(pinnedUntil)}',
                      style: TextStyle(
                          fontSize: 12, color: Colors.grey[600]),
                    ),
                  ],
                ),
              ],
              if (onUnpin != null) ...[
                const SizedBox(height: 12),
                Row(
                  children: [
                    const Spacer(),
                    OutlinedButton.icon(
                      onPressed: onUnpin,
                      icon: const Icon(Icons.push_pin_outlined),
                      label: const Text('Unpin'),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  String _formatDateTime(DateTime dt) {
    return '${dt.year}-${_two(dt.month)}-${_two(dt.day)} ${_two(dt.hour)}:${_two(dt.minute)}';
    // 秒级就不展示了
  }

  String _two(int n) => n.toString().padLeft(2, '0');
}
