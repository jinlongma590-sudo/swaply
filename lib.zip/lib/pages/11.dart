// lib/pages/product_detail_page.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:swaply/models/listing_store.dart';
import 'package:swaply/services/dual_favorites_service.dart';
import 'package:swaply/services/favorites_service.dart';
import 'package:swaply/services/wishlist_service.dart';
import 'package:swaply/services/notification_service.dart';
import 'package:swaply/services/offer_service.dart';
import 'package:photo_view/photo_view.dart';
import 'package:photo_view/photo_view_gallery.dart';
import 'package:flutter/foundation.dart';

class ProductDetailPage extends StatefulWidget {
  final String? productId;
  final Map<String, dynamic>? productData;

  const ProductDetailPage({
    Key? key,
    this.productId,
    this.productData,
  }) : super(key: key);

  @override
  State<ProductDetailPage> createState() => _ProductDetailPageState();
}

class _ProductDetailPageState extends State<ProductDetailPage> {
  late PageController _pageController;
  int _currentImageIndex = 0;
  bool _isDescriptionExpanded = false;
  bool _isInFavorites = false;
  bool _isFavoritesLoading = false;
  bool _isOfferLoading = false;

  Map<String, dynamic> product = {};
  List<String> productImages = [];

  @override
  void initState() {
    super.initState();

    _pageController = PageController();
    _prepareProductData();

    // 先按已知 id/数据补齐一次
    _hydrateListingFromCloudIfNeeded();

    // 有些场景（如 pushNamed 传参）会在 initState 之后才拿到 args，
    // 再延时做一次补全，避免「进入详情为空」。
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _hydrateListingFromCloudIfNeeded();
    });

    _checkFavoritesStatus();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // 从路由 arguments 补齐（支持通知页、其他页面多种键名）
    try {
      final args = ModalRoute.of(context)?.settings.arguments;
      if (args != null) {
        String? idFromArgs;
        Map<String, dynamic>? dataFromArgs;

        if (args is Map) {
          final map = Map<String, dynamic>.from(args.cast<dynamic, dynamic>());
          idFromArgs = (map['id'] ??
              map['listing_id'] ??
              map['listingId'] ??
              (map['listing']?['id']) ??
              (map['data']?['id']))
              ?.toString();
          dataFromArgs = map['data'] is Map
              ? Map<String, dynamic>.from((map['data'] as Map))
              : map;
        } else if (args is String) {
          idFromArgs = args;
        }

        bool needSetState = false;

        if (idFromArgs != null && (product['id'] == null)) {
          product['id'] = idFromArgs;
          needSetState = true;
        }
        if (dataFromArgs != null) {
          // merge，但不覆盖已有非空字段
          dataFromArgs.forEach((k, v) {
            if (product[k] == null && v != null) {
              product[k] = v;
              needSetState = true;
            }
          });
          if (productImages.isEmpty && dataFromArgs['images'] is List) {
            productImages =
                (dataFromArgs['images'] as List).map((e) => e.toString()).toList();
            needSetState = true;
          }
        }

        if (needSetState && mounted) setState(() {});

        // 已拿到 id/数据后，再做一次云端补齐
        _hydrateListingFromCloudIfNeeded();
      }
    } catch (_) {}
  }

  bool _isNetwork(String src) => src.startsWith('http');
  bool _isFile(String src) => src.startsWith('/') || src.startsWith('file:');

  void _prepareProductData() {
    if (widget.productData != null) {
      product = widget.productData!;
    } else if (widget.productId != null) {
      product = ListingStore.i.find(widget.productId!) ?? {};
    }
    if (product.isEmpty) _loadMockById(widget.productId);

    final imgs = product['images'] ?? product['image_urls'] ?? product['image'];
    if (imgs is List) {
      productImages = imgs.map((e) => e.toString()).toList();
    } else if (imgs is String) {
      productImages = [imgs];
    }
    if (productImages.isEmpty) {
      productImages = ['assets/images/placeholder.jpg'];
    }
  }

  /// 仅在缺失字段时，从云端 `listings` 补齐；不会覆盖已有值
  Future<void> _hydrateListingFromCloudIfNeeded() async {
    try {
      final dynamicId = widget.productId ?? (product['id']?.toString());
      if (dynamicId == null) return;
      final row = await Supabase.instance.client
          .from('listings')
          .select(
          'id, user_id, phone, title, images, city, price, description, created_at')
          .eq('id', dynamicId)
          .maybeSingle();

      if (row != null && mounted) {
        setState(() {
          product['user_id'] ??= row['user_id'];
          product['seller_id'] ??= row['user_id']; // 兼容读取 seller_id 的代码
          product['sellerPhone'] ??= row['phone'];
          product['phone'] ??= row['phone'];
          product['title'] ??= row['title'];
          product['images'] ??= row['images'];
          product['city'] ??= row['city'];
          product['price'] ??= row['price'];
          product['description'] ??= row['description'];
          product['created_at'] ??= row['created_at'];

          if (productImages.isEmpty && row['images'] is List) {
            productImages =
                (row['images'] as List).map((e) => e.toString()).toList();
          }
        });
      }
    } catch (e) {
      if (kDebugMode) print('hydrate listing failed: $e');
    }
  }

  Future<void> _checkFavoritesStatus() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null || widget.productId == null) return;

    try {
      final isInFavorites = await DualFavoritesService.isInFavorites(
        userId: user.id,
        listingId: widget.productId!,
      );

      if (mounted) setState(() => _isInFavorites = isInFavorites);

      if (kDebugMode) {
        print('=== 收藏状态检查 ===');
        print('商品ID: ${widget.productId}');
        print('用户ID: ${user.id}');
        print('是否收藏: $isInFavorites');
      }
    } catch (e) {
      if (kDebugMode) print('检查收藏状态出错: $e');
      if (mounted) setState(() => _isInFavorites = false);
    }
  }

  Future<void> _toggleFavorites() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) {
      _toast('Please login to add to favorites');
      return;
    }
    if (widget.productId == null) {
      _toast('Product ID not available');
      return;
    }

    setState(() => _isFavoritesLoading = true);

    try {
      if (kDebugMode) {
        print('=== 开始收藏操作 ===');
        print('用户ID: ${user.id}');
        print('商品ID: ${widget.productId}');
        print('当前收藏状态: $_isInFavorites');
      }

      final newStatus = await DualFavoritesService.toggleFavorite(
        userId: user.id,
        listingId: widget.productId!,
      );

      if (kDebugMode) print('切换操作结果: $newStatus');

      if (mounted) {
        setState(() => _isInFavorites = newStatus);

        if (newStatus) {
          _toast('Added to favorites and wishlist');
          await _sendWishlistNotification();
        } else {
          _toast('Removed from favorites and wishlist');
        }
      }
    } catch (e, stackTrace) {
      if (kDebugMode) {
        print('=== 收藏同步错误 ===');
        print('错误: $e');
        print('堆栈跟踪: $stackTrace');
      }

      String errorMessage = 'Failed to update favorites';
      if (e.toString().contains('relation') &&
          e.toString().contains('does not exist')) {
        errorMessage = 'Favorites feature unavailable, please contact support';
      } else if (e.toString().contains('permission')) {
        errorMessage = 'Permission denied, please check login status';
      } else if (e.toString().contains('network')) {
        errorMessage = 'Network error, please check connection';
      } else if (e.toString().contains('duplicate key')) {
        errorMessage = 'Item already in favorites';
        if (mounted) setState(() => _isInFavorites = true);
      }

      _toast(errorMessage);
    } finally {
      if (mounted) setState(() => _isFavoritesLoading = false);
    }
  }

  Future<void> _sendWishlistNotification() async {
    try {
      final user = Supabase.instance.client.auth.currentUser;
      if (user == null) return;

      final sellerId = product['user_id'] ?? product['seller_id'];
      if (sellerId == null || sellerId == user.id) return;

      String? userName;
      try {
        final profile = await Supabase.instance.client
            .from('profiles')
            .select('full_name')
            .eq('id', user.id)
            .maybeSingle();
        userName = profile?['full_name'];
      } catch (e) {
        if (kDebugMode) print('获取用户资料出错: $e');
      }

      await NotificationService.createWishlistNotification(
        sellerId: sellerId,
        likerId: user.id,
        listingId: (widget.productId ?? product['id']).toString(),
        listingTitle: product['title'] ?? 'Unknown Item',
        likerName: userName,
      );

      if (kDebugMode) print('心愿单通知已发送给卖家: $sellerId');
    } catch (e) {
      if (kDebugMode) print('发送心愿单通知出错: $e');
    }
  }

  void _loadMockById(String? id) {
    switch (id) {
      case '1':
        product = {
          "id": "1",
          "title": "iPhone 13 Pro Max 256GB",
          "price": "\$850",
          "location": "Harare CBD",
          "category": "phones",
          "condition": "Used - Like New",
          "brand": "Apple",
          "model": "iPhone 13 Pro Max",
          "storage": "256GB",
          "color": "Silver",
          "description":
          "Selling my iPhone 13 Pro Max in excellent condition. Used for only 6 months with original box and all accessories. No scratches or dents. Battery health at 96%. Reason for selling: Upgrading to newer model. Price slightly negotiable for serious buyers only. Cash on delivery available within Harare.",
          "sellerName": "John Mukamba",
          "sellerPhone": "+263771234567",
          "postedDate": "3 hours ago",
          "user_id": "mock-seller-1",
          "images": [
            "assets/images/trending_items/item1/1.jpg",
            "assets/images/trending_items/item1/1.jpg",
            "assets/images/trending_items/item1/1.jpg",
          ]
        };
        break;
      case '2':
        product = {
          "id": "2",
          "title": "Toyota Corolla 2019",
          "price": "\$15,500",
          "location": "Bulawayo",
          "category": "vehicles",
          "condition": "Used - Good",
          "brand": "Toyota",
          "model": "Corolla",
          "year": "2019",
          "mileage": "68000 km",
          "fuel": "Petrol",
          "transmission": "Automatic",
          "description":
          "Well maintained 2019 Toyota Corolla. Single owner, regularly serviced, clean interior and exterior. Drives smoothly. Viewing in Bulawayo. Slightly negotiable for serious buyers.",
          "sellerName": "Tawanda N.",
          "sellerPhone": "+263778001234",
          "postedDate": "1 day ago",
          "user_id": "mock-seller-2",
          "images": [
            "assets/images/trending_items/item2/1.jpg",
            "assets/images/trending_items/item2/1.jpg",
            "assets/images/trending_items/item2/1.jpg",
          ]
        };
        break;
      case '3':
        product = {
          "id": "3",
          "title": "Leather Sofa Set",
          "price": "\$450",
          "location": "Chitungwiza",
          "category": "furniture",
          "condition": "Used - Like New",
          "furnitureType": "Living Room",
          "material": "Genuine Leather",
          "color": "Brown",
          "description":
          "3+2+1 leather sofa set, barely used, no tears or sagging. Very comfortable and sturdy. Pickup in Chitungwiza. Can help arrange delivery at extra cost.",
          "sellerName": "Ruth M.",
          "sellerPhone": "+263772223456",
          "postedDate": "2 days ago",
          "user_id": "mock-seller-3",
          "images": [
            "assets/images/trending_items/item3/1.jpg",
            "assets/images/trending_items/item3/1.jpg",
            "assets/images/trending_items/item3/1.jpg",
          ]
        };
        break;
      default:
        product = {
          "title": "Product",
          "price": "\$0",
          "location": "Zimbabwe",
          "description": "No description available",
          "sellerName": "Seller",
          "sellerPhone": "+263770000000",
          "postedDate": "Recently",
          "user_id": "mock-seller-default",
          "images": ["assets/images/placeholder.jpg"]
        };
    }
  }

  void _showMakeOfferDialog() {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) {
      _toast('Please login to make offers');
      return;
    }
    if (widget.productId == null && product['id'] == null) {
      _toast('Product not available');
      return;
    }

    final sellerId = product['user_id'] ?? product['seller_id'];
    if (sellerId == user.id) {
      _toast('You cannot make an offer on your own item');
      return;
    }

    final TextEditingController offerController = TextEditingController();
    final TextEditingController messageController = TextEditingController();
    final priceStr = product['price']?.toString() ?? '\$0';
    final cleanPrice = priceStr.replaceAll('\$', '').replaceAll(',', '');
    final price = double.tryParse(cleanPrice) ?? 0;

    final quickOffers = [
      price * 0.8,
      price * 0.85,
      price * 0.9,
      price * 0.95,
    ].where((offer) => offer > 0).toList();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (BuildContext context) {
        return Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(24),
              topRight: Radius.circular(24),
            ),
          ),
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom + 20,
            top: 20,
            left: 20,
            right: 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Make an Offer',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Current Price: ${product['price']}',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.grey[100],
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.close, size: 20),
                    ),
                  ),
                ],
              ),

              if (quickOffers.isNotEmpty) ...[
                const SizedBox(height: 20),
                const Text(
                  'Quick Select',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey,
                  ),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: quickOffers.map((offer) {
                    final percentage =
                    price > 0 ? ((offer / price) * 100).round() : 0;
                    return InkWell(
                      onTap: () {
                        offerController.text = offer.toStringAsFixed(0);
                      },
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 10,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.grey[50],
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: Colors.grey[300]!,
                          ),
                        ),
                        child: Column(
                          children: [
                            Text(
                              '\$${offer.toStringAsFixed(0)}',
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              '$percentage%',
                              style: TextStyle(
                                fontSize: 11,
                                color: Colors.grey[600],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ],

              const SizedBox(height: 24),
              const Text(
                'Your Offer',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colors.grey,
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: offerController,
                keyboardType: TextInputType.number,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
                decoration: InputDecoration(
                  prefixText: '\$ ',
                  prefixStyle: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                  hintText: 'Enter amount',
                  hintStyle: TextStyle(
                    color: Colors.grey[400],
                    fontWeight: FontWeight.normal,
                  ),
                  filled: true,
                  fillColor: Colors.grey[50],
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: Colors.grey[300]!),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: Colors.grey[300]!),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(
                      color: Color(0xFF2196F3),
                      width: 2,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'Message (Optional)',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colors.grey,
                ),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: messageController,
                maxLines: 3,
                decoration: InputDecoration(
                  hintText: 'Add a message to the seller...',
                  hintStyle: TextStyle(color: Colors.grey[400]),
                  filled: true,
                  fillColor: Colors.grey[50],
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: Colors.grey[300]!),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: Colors.grey[300]!),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(
                      color: Color(0xFF2196F3),
                      width: 2,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Container(
                width: double.infinity,
                height: 52,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF2196F3), Color(0xFF1E88E5)],
                  ),
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF2196F3).withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: _isOfferLoading
                        ? null
                        : () async {
                      final offerText = offerController.text.trim();
                      if (offerText.isNotEmpty) {
                        final amount = double.tryParse(offerText);
                        if (amount != null && amount > 0) {
                          Navigator.pop(context);
                          await _sendOffer(
                            amount,
                            messageController.text.trim().isEmpty
                                ? null
                                : messageController.text.trim(),
                          );
                        } else {
                          _toast('Please enter a valid offer amount');
                        }
                      } else {
                        _toast('Please enter offer amount');
                      }
                    },
                    borderRadius: BorderRadius.circular(12),
                    child: Center(
                      child: _isOfferLoading
                          ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor:
                          AlwaysStoppedAnimation<Color>(Colors.white),
                        ),
                      )
                          : const Text(
                        'Send Offer',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Center(
                child: Text(
                  'The seller will be notified of your offer',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _sendOffer(double amount, String? message) async {
    setState(() => _isOfferLoading = true);

    try {
      if (kDebugMode) {
        print('=== 开始发送报价 ===');
        print('报价金额: $amount');
        print('商品ID: ${widget.productId ?? product['id']}');
        print('留言: $message');
      }

      final user = Supabase.instance.client.auth.currentUser;
      if (user == null) {
        _toast('Please login to send offers');
        return;
      }

      final sellerId = product['user_id'] ?? product['seller_id'];
      if (sellerId == null) {
        _toast('Seller information not available');
        return;
      }
      if (sellerId == user.id) {
        _toast('You cannot make an offer on your own item');
        return;
      }

      String? userName;
      String? userPhone;
      try {
        final profile = await Supabase.instance.client
            .from('profiles')
            .select('full_name, phone')
            .eq('id', user.id)
            .maybeSingle();
        userName = profile?['full_name'];
        userPhone = profile?['phone'];
      } catch (e) {
        if (kDebugMode) print('获取用户资料出错: $e');
      }

      final originalPriceStr = product['price']?.toString() ?? '\$0';
      final originalPrice = double.tryParse(
          originalPriceStr.replaceAll('\$', '').replaceAll(',', ''));

      final offer = await OfferService.createOffer(
        listingId: (widget.productId ?? product['id']).toString(),
        sellerId: sellerId,
        offerAmount: amount,
        originalPrice: originalPrice,
        message: message,
        buyerPhone: userPhone,
        buyerName: userName ?? 'Anonymous',
      );

      if (offer != null) {
        _toast('Offer \$${amount.toStringAsFixed(0)} sent successfully!');
        if (kDebugMode) {
          print('报价已创建: ${offer['id']}');
          print('将通过数据库触发器自动发送通知');
        }
      } else {
        _toast('Failed to send offer, please try again');
      }
    } catch (e) {
      if (kDebugMode) print('发送报价出错: $e');

      String errorMessage = 'Failed to send offer';
      if (e.toString().contains('already have a pending offer')) {
        errorMessage = 'You already have a pending offer for this item';
      } else if (e.toString().contains('Cannot make offer on your own item')) {
        errorMessage = 'You cannot make an offer on your own item';
      } else if (e.toString().contains('network')) {
        errorMessage = 'Network error, please check connection';
      } else if (e.toString().contains('permission')) {
        errorMessage = 'Permission denied, please check login status';
      } else if (e.toString().contains('User not authenticated')) {
        errorMessage = 'Please login to send offers';
      }

      _toast(errorMessage);
    } finally {
      if (mounted) setState(() => _isOfferLoading = false);
    }
  }

  void _makePhoneCall() async {
    // 先取 sellerPhone，若为空再用 phone 兜底
    final rawPhone =
    product['sellerPhone']?.toString().trim().isNotEmpty == true
        ? product['sellerPhone'].toString()
        : (product['phone']?.toString() ?? '');

    if (rawPhone.isEmpty) {
      _toast('Phone number not available');
      return;
    }

    try {
      final cleanPhone = rawPhone.replaceAll(RegExp(r'[^\d+]'), '');
      final uri = Uri(scheme: 'tel', path: cleanPhone);

      if (kDebugMode) {
        print('尝试拨打电话: $cleanPhone');
        print('URI: $uri');
      }

      final canLaunch = await canLaunchUrl(uri);
      if (canLaunch) {
        await launchUrl(uri);
      } else {
        _toast(
            'Unable to make phone call. Please check if your device supports phone calls.');
      }
    } catch (e) {
      if (kDebugMode) print('拨打电话失败: $e');
      _toast('Failed to make phone call: ${e.toString()}');
    }
  }

  void _openWhatsApp() async {
    final raw =
    product['sellerPhone']?.toString().trim().isNotEmpty == true
        ? product['sellerPhone'].toString()
        : (product['phone']?.toString() ?? '');

    if (raw.isEmpty) {
      _toast('Phone number not available');
      return;
    }

    try {
      final phone = raw.replaceAll(RegExp(r'[^\d]'), '');
      final msg = Uri.encodeComponent(
          "Hi, I'm interested in your ${product['title'] ?? 'item'} listed on Swaply for ${product['price'] ?? 'the listed price'}. Is it still available?");

      final url = Uri.parse('https://wa.me/$phone?text=$msg');

      if (kDebugMode) {
        print('尝试打开 WhatsApp: $phone');
        print('URL: $url');
      }

      final canLaunch = await canLaunchUrl(url);
      if (canLaunch) {
        await launchUrl(url, mode: LaunchMode.externalApplication);
      } else {
        _toast('WhatsApp not installed or not available');
      }
    } catch (e) {
      if (kDebugMode) print('打开 WhatsApp 失败: $e');
      _toast('Failed to open WhatsApp: ${e.toString()}');
    }
  }

  void _shareProduct() {
    final text = '''
${product['title'] ?? 'Product'}
Price: ${product['price'] ?? 'Price not available'}
Location: ${product['location'] ?? 'Location not available'}

Shared from Swaply
''';
    Clipboard.setData(ClipboardData(text: text));
    _toast('Product details copied to clipboard');
  }

  void _toast(String msg) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(msg),
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 350,
            pinned: true,
            backgroundColor: Colors.white,
            elevation: 0,
            leading: _circleBtn(Icons.arrow_back, () => Navigator.pop(context)),
            actions: [
              _circleBtn(Icons.share, _shareProduct),
              _buildFavoritesButton(),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                children: [
                  PageView.builder(
                    controller: _pageController,
                    itemCount: productImages.length,
                    onPageChanged: (i) =>
                        setState(() => _currentImageIndex = i),
                    itemBuilder: (_, i) {
                      final tag = 'product_image_$i';
                      final src = productImages[i];
                      final isNet = _isNetwork(src);
                      final isFile = _isFile(src);

                      final imageWidget = isNet
                          ? Image.network(
                        src,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Container(
                            color: Colors.grey[300],
                            child: const Center(
                              child: Icon(Icons.broken_image, size: 50),
                            ),
                          );
                        },
                      )
                          : isFile
                          ? Image.file(
                        File(src),
                        fit: BoxFit.cover,
                        errorBuilder:
                            (context, error, stackTrace) {
                          return Container(
                            color: Colors.grey[300],
                            child: const Center(
                              child:
                              Icon(Icons.broken_image, size: 50),
                            ),
                          );
                        },
                      )
                          : Image.asset(
                        src,
                        fit: BoxFit.cover,
                        errorBuilder:
                            (context, error, stackTrace) {
                          return Container(
                            color: Colors.grey[300],
                            child: const Center(
                              child:
                              Icon(Icons.broken_image, size: 50),
                            ),
                          );
                        },
                      );

                      return GestureDetector(
                        onTap: () => _openGallery(i),
                        child: Hero(
                          tag: tag,
                          child: imageWidget,
                        ),
                      );
                    },
                  ),
                  Positioned(
                    bottom: 20,
                    left: 0,
                    right: 0,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(
                        productImages.length,
                            (i) => Container(
                          width: 8,
                          height: 8,
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _currentImageIndex == i
                                ? Colors.white
                                : Colors.white54,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildFavoritesButton() {
    return Container(
      margin: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white.withAlpha(230),
        shape: BoxShape.circle,
      ),
      child: _isFavoritesLoading
          ? const Padding(
        padding: EdgeInsets.all(12),
        child: SizedBox(
          width: 20,
          height: 20,
          child: CircularProgressIndicator(
            strokeWidth: 2,
            valueColor:
            AlwaysStoppedAnimation<Color>(Color(0xFF2196F3)),
          ),
        ),
      )
          : IconButton(
        icon: Icon(
          _isInFavorites ? Icons.bookmark : Icons.bookmark_border,
          color:
          _isInFavorites ? const Color(0xFF2196F3) : Colors.black87,
        ),
        onPressed: _toggleFavorites,
      ),
    );
  }

  void _openGallery(int initialIndex) {
    Navigator.of(context).push(
      PageRouteBuilder(
        opaque: true,
        barrierDismissible: true,
        pageBuilder: (_, __, ___) => _FullscreenGallery(
          images: productImages,
          initialIndex: initialIndex,
        ),
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
      ),
    );
  }

  Widget _buildBody() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _card(
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                product['title']?.toString() ?? 'No title',
                style:
                const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              Text(
                product['price']?.toString() ?? 'Price not available',
                style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF13C45B)),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Icon(Icons.location_on, size: 16, color: Colors.grey),
                  const SizedBox(width: 4),
                  Text(
                      product['location']?.toString() ??
                          'Location not available',
                      style:
                      const TextStyle(color: Colors.grey, fontSize: 14)),
                  const SizedBox(width: 16),
                  const Icon(Icons.access_time, size: 16, color: Colors.grey),
                  const SizedBox(width: 4),
                  Text(product['postedDate']?.toString() ?? 'Recently',
                      style:
                      const TextStyle(color: Colors.grey, fontSize: 14)),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    flex: 2,
                    child: Container(
                      height: 48,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: const Color(0xFF2196F3),
                          width: 2,
                        ),
                      ),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap:
                          _isOfferLoading ? null : _showMakeOfferDialog,
                          borderRadius: BorderRadius.circular(12),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              if (_isOfferLoading) ...[
                                const SizedBox(
                                  width: 16,
                                  height: 16,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    valueColor:
                                    AlwaysStoppedAnimation<Color>(
                                        Color(0xFF2196F3)),
                                  ),
                                ),
                                const SizedBox(width: 6),
                              ] else ...[
                                const Icon(Icons.local_offer,
                                    color: Color(0xFF2196F3), size: 20),
                                const SizedBox(width: 6),
                              ],
                              Text(
                                _isOfferLoading ? 'Sending...' : 'Make Offer',
                                style: const TextStyle(
                                  color: Color(0xFF2196F3),
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    flex: 2,
                    child: Container(
                      height: 48,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF2196F3), Color(0xFF1E88E5)],
                        ),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF2196F3).withOpacity(0.3),
                            blurRadius: 8,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: _makePhoneCall,
                          borderRadius: BorderRadius.circular(12),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: const [
                              Icon(Icons.phone, color: Colors.white, size: 18),
                              SizedBox(width: 6),
                              Text(
                                'Call',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    flex: 2,
                    child: Container(
                      height: 48,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF25D366), Color(0xFF128C7E)],
                        ),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF25D366).withOpacity(0.3),
                            blurRadius: 8,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: _openWhatsApp,
                          borderRadius: BorderRadius.circular(12),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: const [
                              Icon(Icons.chat, color: Colors.white, size: 18),
                              SizedBox(width: 6),
                              Text(
                                'WhatsApp',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        _card(_buildDetails()),
        const SizedBox(height: 10),
        _card(_buildDescription()),
        const SizedBox(height: 10),
        _card(_buildSeller()),
        _safetyTip(),
        const SizedBox(height: 80),
      ],
    );
  }

  Widget _buildDetails() {
    final items = <Widget>[];

    if (product['condition'] != null) {
      items.add(_detailRow('Condition', product['condition'].toString()));
    }

    void addIf(String key, String label) {
      if (product[key] != null && product[key].toString().isNotEmpty) {
        items.add(_detailRow(label, product[key].toString()));
      }
    }

    addIf('brand', 'Brand');
    addIf('model', 'Model');
    addIf('year', 'Year');
    addIf('mileage', 'Mileage');
    addIf('fuel', 'Fuel Type');
    addIf('transmission', 'Transmission');
    addIf('storage', 'Storage');
    addIf('color', 'Color');
    addIf('propertyType', 'Property Type');
    addIf('bedrooms', 'Bedrooms');
    addIf('bathrooms', 'Bathrooms');
    addIf('area', 'Area');
    addIf('jobType', 'Job Type');
    addIf('salary', 'Salary');
    addIf('experience', 'Experience');
    addIf('fashionType', 'Type');
    addIf('size', 'Size');
    addIf('furnitureType', 'Type');
    addIf('petType', 'Pet Type');
    addIf('breed', 'Breed');
    addIf('age', 'Age');
    addIf('kidsCategory', 'Category');
    addIf('ageRange', 'Age Range');
    addIf('material', 'Material');
    addIf('type', 'Type');

    if (items.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Details',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        ...items,
      ],
    );
  }

  Widget _buildDescription() {
    final desc =
        product['description']?.toString() ?? 'No description available';
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Description',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      Text(
        desc,
        maxLines: _isDescriptionExpanded ? null : 4,
        overflow:
        _isDescriptionExpanded ? TextOverflow.visible : TextOverflow.ellipsis,
        style: const TextStyle(fontSize: 14, height: 1.5),
      ),
      if (desc.length > 150)
        GestureDetector(
          onTap: () =>
              setState(() => _isDescriptionExpanded = !_isDescriptionExpanded),
          child: Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(_isDescriptionExpanded ? 'Show less' : 'Read more',
                style: const TextStyle(
                    color: Color(0xFF2196F3),
                    fontSize: 14,
                    fontWeight: FontWeight.w500)),
          ),
        )
    ]);
  }

  Widget _buildSeller() {
    final raw = product['sellerName'];
    final name =
    (raw is String && raw.trim().isNotEmpty) ? raw.trim() : 'Seller';
    final initial = name.substring(0, 1).toUpperCase();

    return Row(children: [
      CircleAvatar(
        radius: 30,
        backgroundColor: const Color(0xFF2196F3),
        child:
        Text(initial, style: const TextStyle(color: Colors.white, fontSize: 24)),
      ),
      const SizedBox(width: 16),
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(name,
              style:
              const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          const Text('Member since 2023',
              style: TextStyle(color: Colors.grey, fontSize: 14)),
        ],
      ),
    ]);
  }

  Widget _safetyTip() => Container(
    margin: const EdgeInsets.all(20),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Colors.blue[50],
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: const Color(0xFF2196F3).withAlpha(50)),
    ),
    child: Row(children: const [
      Icon(Icons.security, color: Color(0xFF2196F3)),
      SizedBox(width: 12),
      Expanded(
          child: Text(
              'Meet in safe public places and inspect items before payment',
              style: TextStyle(fontSize: 12))),
    ]),
  );

  Widget _detailRow(String label, String value) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
            flex: 2,
            child: Text(label,
                style: const TextStyle(color: Colors.grey, fontSize: 14))),
        Expanded(
            flex: 3,
            child: Text(value,
                style: const TextStyle(
                    fontSize: 14, fontWeight: FontWeight.w500))),
      ],
    ),
  );

  Widget _card(Widget child) => Container(
    color: Colors.white,
    padding: const EdgeInsets.all(20),
    width: double.infinity,
    child: child,
  );

  Widget _circleBtn(IconData icon, VoidCallback tap) => Container(
    margin: const EdgeInsets.all(8),
    decoration: BoxDecoration(
        color: Colors.white.withAlpha(230), shape: BoxShape.circle),
    child: IconButton(icon: Icon(icon, color: Colors.black87), onPressed: tap),
  );
}

class _FullscreenGallery extends StatefulWidget {
  final List<String> images;
  final int initialIndex;

  const _FullscreenGallery({
    Key? key,
    required this.images,
    required this.initialIndex,
  }) : super(key: key);

  @override
  State<_FullscreenGallery> createState() => _FullscreenGalleryState();
}

class _FullscreenGalleryState extends State<_FullscreenGallery> {
  late final PageController _controller;
  late int _current;

  bool _isNetwork(String src) => src.startsWith('http');
  bool _isFile(String src) => src.startsWith('/') || src.startsWith('file:');

  @override
  void initState() {
    super.initState();
    _current = widget.initialIndex;
    _controller = PageController(initialPage: widget.initialIndex);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          PhotoViewGallery.builder(
            pageController: _controller,
            itemCount: widget.images.length,
            backgroundDecoration: const BoxDecoration(color: Colors.black),
            onPageChanged: (i) => setState(() => _current = i),
            builder: (context, index) {
              final src = widget.images[index];

              final ImageProvider provider = _isNetwork(src)
                  ? NetworkImage(src)
                  : _isFile(src)
                  ? FileImage(File(src))
                  : AssetImage(src) as ImageProvider;

              return PhotoViewGalleryPageOptions(
                imageProvider: provider,
                heroAttributes:
                PhotoViewHeroAttributes(tag: 'product_image_$index'),
                minScale: PhotoViewComputedScale.contained,
                maxScale: PhotoViewComputedScale.covered * 3.0,
              );
            },
            loadingBuilder: (_, __) =>
            const Center(child: CircularProgressIndicator()),
          ),
          SafeArea(
            child: Align(
              alignment: Alignment.topRight,
              child: IconButton(
                icon: const Icon(Icons.close, color: Colors.white),
                onPressed: () => Navigator.pop(context),
              ),
            ),
          ),
          SafeArea(
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                margin: const EdgeInsets.only(bottom: 16),
                padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '${_current + 1} / ${widget.images.length}',
                  style: const TextStyle(color: Colors.white, fontSize: 12),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
