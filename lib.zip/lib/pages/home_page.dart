// lib/pages/home_page.dart
// Cloud-only Trending feed: pinned first + latest fill (no separate Featured section)

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:swaply/pages/category_products_page.dart';
import 'package:swaply/pages/product_detail_page.dart';
import 'package:swaply/pages/search_results_page.dart';
import 'package:swaply/pages/sell_form_page.dart';
import 'package:swaply/services/coupon_service.dart';
import 'package:swaply/listing_api.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final ScrollController _scrollController = ScrollController();
  final GlobalKey _trendingKey = GlobalKey();
  final TextEditingController _searchCtrl = TextEditingController();

  String _selectedLocation = 'All Zimbabwe';

  // Trending (mixed: pinned first + latest fill; all cloud)
  List<Map<String, dynamic>> _trendingRemote = [];
  bool _loadingTrending = false;

  static const List<String> _locations = [
    'All Zimbabwe',
    'Harare',
    'Bulawayo',
    'Chitungwiza',
    'Mutare',
    'Gweru',
    'Kwekwe',
    'Kadoma',
    'Masvingo',
    'Chinhoyi',
    'Chegutu',
    'Bindura',
    'Marondera',
    'Redcliff',
  ];

  static const List<Map<String, String>> _categories = [
    {"id": "trending", "icon": "trending", "label": "Trending"},
    {"id": "vehicles", "icon": "vehicles", "label": "Vehicles"},
    {"id": "property", "icon": "property", "label": "Property"},
    {"id": "beauty_personal_care", "icon": "beauty_personal_care", "label": "Beauty & Personal Care"},
    {"id": "jobs", "icon": "jobs", "label": "Jobs"},
    {"id": "babies_kids", "icon": "babies_kids", "label": "Babies & Kids"},
    {"id": "services", "icon": "services", "label": "Services"},
    {"id": "leisure_activities", "icon": "leisure_activities", "label": "Leisure Activities"},
    {"id": "repair_construction", "icon": "repair_construction", "label": "Repair & Construction"},
    {"id": "home_furniture_appliances", "icon": "home_furniture_appliances", "label": "Home, Furniture & Appliances"},
    {"id": "pets", "icon": "pets", "label": "Pets"},
    {"id": "electronics", "icon": "electronics", "label": "Electronics"},
    {"id": "phones_tablets", "icon": "phones_tablets", "label": "Phones & Tablets"},
    {"id": "seeking_work_cvs", "icon": "seeking_work_cvs", "label": "Seeking Work & CVs"},
    {"id": "fashion", "icon": "fashion", "label": "Fashion"},
    {"id": "food_agriculture_drinks", "icon": "food_agriculture_drinks", "label": "Food, Agriculture & Drinks"},
  ];

  @override
  void initState() {
    super.initState();
    _loadTrending(); // 混合流：置顶优先 + 最新补齐
  }

  /* ===================== 数据加载 ===================== */

  /// 混合 Trending：先置顶，再最新，去重，裁剪到 total 条
  Future<List<Map<String, dynamic>>> _fetchTrendingMixed({
    String? city,
    int pinnedLimit = 6,
    int latestLimit = 36,
    int total = 12,
  }) async {
    // 1) 置顶 -> listings
    final pinnedAds = await CouponService.getPinnedAds(
      category: null,
      city: city,
      limit: pinnedLimit,
    );
    final list = <Map<String, dynamic>>[];
    for (final e in pinnedAds) {
      final l = (e['listings'] as Map<String, dynamic>? ?? {});
      if (l.isEmpty) continue;
      final imgs = (l['images'] as List?) ?? (l['image_urls'] as List?) ?? const [];
      list.add({
        'id': l['id'],
        'title': l['title'],
        'price': l['price'],
        'images': imgs,
        'city': l['city'],
        'created_at': l['created_at'],
        'pinned': true,
      });
    }

    // 2) 最新
    final latest = await ListingApi.fetchListings(
      city: city,
      limit: latestLimit,
      offset: 0,
      orderBy: 'created_at',
      ascending: false,
      status: 'active',
    );

    // 3) 去重补齐
    final seen = <String>{...list.map((x) => x['id'].toString())};
    for (final r in latest) {
      final id = r['id']?.toString();
      if (id == null || seen.contains(id)) continue;
      seen.add(id);
      final imgs = (r['images'] as List?) ?? (r['image_urls'] as List?) ?? const [];
      list.add({
        'id': r['id'],
        'title': r['title'],
        'price': r['price'],
        'images': imgs,
        'city': r['city'],
        'created_at': r['created_at'],
        'pinned': false,
      });
      if (list.length >= total) break;
    }
    return list.take(total).toList();
  }

  Future<void> _loadTrending() async {
    setState(() => _loadingTrending = true);
    try {
      final city = _selectedLocation == 'All Zimbabwe' ? null : _selectedLocation;
      final rows = await _fetchTrendingMixed(
        city: city,
        pinnedLimit: 6,
        latestLimit: 36,
        total: 12,
      );
      if (mounted) setState(() => _trendingRemote = rows);
    } catch (e) {
      debugPrint('Error loading trending: $e');
    } finally {
      if (mounted) setState(() => _loadingTrending = false);
    }
  }

  /* ===================== 导航（保持原样） ===================== */

  void _navigateToCategory(String categoryId, String categoryName) {
    if (categoryId == "trending") {
      _scrollToTrending();
    } else {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => CategoryProductsPage(
            categoryId: categoryId,
            categoryName: categoryName,
          ),
        ),
      );
    }
  }

  void _navigateToProductDetail(String productId) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ProductDetailPage(productId: productId)),
    );
  }

  void _scrollToTrending() {
    final ctx = _trendingKey.currentContext;
    if (ctx != null) {
      Scrollable.ensureVisible(
        ctx,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    }
  }

  void _performSearch() {
    final keyword = _searchCtrl.text.trim();
    if (keyword.isEmpty) return;
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => SearchResultsPage(keyword: keyword, location: _selectedLocation),
      ),
    );
  }

  Future<void> _onTapPost() async {
    final auth = Supabase.instance.client.auth;
    if (auth.currentUser == null) {
      final goLogin = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Login required'),
          content: const Text('Please login to use post listings.'),
          actions: [
            TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('Login')),
          ],
        ),
      );
      if (goLogin == true && mounted) {
        await Navigator.of(context).pushNamed('/login');
      }
      if (Supabase.instance.client.auth.currentUser == null) return;
    }
    if (!mounted) return;
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SellFormPage()));
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  /* ===================== UI ===================== */

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: Stack(
        children: [
          ListView(
            controller: _scrollController,
            padding: EdgeInsets.zero,
            children: [
              // 头部
              Stack(
                children: [
                  Container(height: 220, color: const Color(0xFF319AFF)),
                  Column(
                    children: [
                      // Logo
                      Container(
                        padding: const EdgeInsets.only(top: 35, bottom: 20),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: 50,
                              height: 50,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              padding: const EdgeInsets.all(6),
                              child: const Center(
                                child: Text(
                                  'S',
                                  style: TextStyle(
                                    fontSize: 26,
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xFF319AFF),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            const Text(
                              'Swaply',
                              style: TextStyle(
                                fontSize: 32,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ),

                      // 白卡：位置 + 搜索 + 分类
                      Container(
                        margin: const EdgeInsets.symmetric(horizontal: 16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [BoxShadow(color: Colors.black.withAlpha(15), blurRadius: 10, offset: const Offset(0, 3))],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Padding(
                              padding: EdgeInsets.only(left: 20, top: 8, bottom: 2),
                              child: Text(
                                'What are you looking for?',
                                style: TextStyle(fontSize: 22, color: Color(0xFF319AFF), fontWeight: FontWeight.w600),
                              ),
                            ),

                            // 位置 + 搜索
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 20),
                              child: Row(
                                children: [
                                  Flexible(
                                    flex: 2,
                                    child: Container(
                                      height: 44,
                                      padding: const EdgeInsets.symmetric(horizontal: 8),
                                      decoration: BoxDecoration(
                                        border: Border.all(color: const Color(0xFF319AFF), width: 1.3),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: DropdownButtonHideUnderline(
                                        child: DropdownButton<String>(
                                          value: _selectedLocation,
                                          icon: const Icon(Icons.arrow_drop_down),
                                          isExpanded: true,
                                          onChanged: (v) {
                                            setState(() => _selectedLocation = v!);
                                            _loadTrending();
                                          },
                                          items: _locations.map((loc) => DropdownMenuItem(
                                            value: loc,
                                            child: Text(loc, style: const TextStyle(fontSize: 13), overflow: TextOverflow.ellipsis),
                                          )).toList(),
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Flexible(
                                    flex: 5,
                                    child: Container(
                                      height: 44,
                                      padding: const EdgeInsets.symmetric(horizontal: 12),
                                      decoration: BoxDecoration(
                                        border: Border.all(color: const Color(0xFF319AFF), width: 1.3),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Row(
                                        children: [
                                          Expanded(
                                            child: TextField(
                                              controller: _searchCtrl,
                                              textInputAction: TextInputAction.search,
                                              decoration: const InputDecoration(isCollapsed: true, hintText: 'Search...', border: InputBorder.none),
                                              onSubmitted: (_) => _performSearch(),
                                            ),
                                          ),
                                          GestureDetector(onTap: _performSearch, child: const Icon(Icons.search, size: 22)),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            // 分类网格（保持原跳转）
                            Padding(
                              padding: const EdgeInsets.only(left: 4, right: 4, top: 4, bottom: 12),
                              child: GridView.count(
                                physics: const NeverScrollableScrollPhysics(),
                                shrinkWrap: true,
                                crossAxisCount: 4,
                                childAspectRatio: 1.4,
                                children: _categories.map((cat) {
                                  final index = _categories.indexOf(cat);
                                  return GestureDetector(
                                    onTap: () => _navigateToCategory(cat['id']!, cat['label']!),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Container(
                                          width: 56,
                                          height: 56,
                                          decoration: BoxDecoration(color: Colors.grey[100], borderRadius: BorderRadius.circular(12)),
                                          child: Center(
                                            child: SizedBox(
                                              width: 40,
                                              height: 40,
                                              child: Image.asset(
                                                'assets/icons/${cat['icon']}.png',
                                                fit: BoxFit.contain,
                                                errorBuilder: (_, __, ___) {
                                                  return Image.asset(
                                                    'assets/icons/${cat['icon']}.jpg',
                                                    fit: BoxFit.contain,
                                                    errorBuilder: (_, __, ___) => Icon(
                                                      index == 0 ? Icons.local_fire_department : Icons.category,
                                                      size: 32,
                                                      color: index == 0 ? Colors.orange : Colors.grey,
                                                    ),
                                                  );
                                                },
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(height: 2),
                                        Flexible(
                                          child: Text(
                                            cat['label']!,
                                            textAlign: TextAlign.center,
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                }).toList(),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),

              // Trending 标题
              Padding(
                key: _trendingKey,
                padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
                child: Row(
                  children: [
                    const Text('Trending', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    const SizedBox(width: 6),
                    Icon(Icons.local_fire_department, color: Colors.orange[600], size: 28),
                  ],
                ),
              ),

              // Trending（混合流，图片按 cover 铺满；置顶打标）
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: _loadingTrending ? _buildTrendingLoading() : _buildTrendingGrid(),
              ),

              const SizedBox(height: 80),
            ],
          ),

          // Post FAB
          Positioned(
            right: 16,
            bottom: 16,
            child: FloatingActionButton.extended(
              heroTag: 'post-fab',
              onPressed: _onTapPost,
              icon: const Icon(Icons.add),
              label: const Text('Post'),
            ),
          ),
        ],
      ),
    );
  }

  /* ============ Trending 渲染 ============ */

  Widget _buildTrendingLoading() {
    return GridView.builder(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, childAspectRatio: 0.75, crossAxisSpacing: 16, mainAxisSpacing: 16,
      ),
      itemCount: 6,
      itemBuilder: (_, __) => Container(
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
        child: Column(children: [
          Expanded(child: Container(decoration: BoxDecoration(color: Colors.grey[300], borderRadius: const BorderRadius.vertical(top: Radius.circular(14))))),
          Container(height: 64, padding: const EdgeInsets.all(12), alignment: Alignment.centerLeft, child: Container(height: 14, width: 90, color: Colors.grey[300])),
        ]),
      ),
    );
  }

  Widget _buildTrendingGrid() {
    if (_trendingRemote.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(24),
        child: Center(child: Text('No trending items')),
      );
    }

    return GridView.builder(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, mainAxisSpacing: 16, crossAxisSpacing: 16, childAspectRatio: 0.75,
      ),
      itemCount: _trendingRemote.length,
      itemBuilder: (context, i) {
        final r = _trendingRemote[i];
        final isPinned = (r['pinned'] == true);
        final images = (r['images'] as List?) ?? const [];
        final img = images.isNotEmpty ? images.first.toString() : null;
        final priceVal = r['price'];
        String priceText = '';
        if (priceVal is num) {
          priceText = '\$${priceVal.toStringAsFixed(0)}';
        } else if (priceVal != null) {
          priceText = priceVal.toString();
        }

        return GestureDetector(
          onTap: () => _navigateToProductDetail(r['id'].toString()),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              boxShadow: [BoxShadow(color: Colors.black.withAlpha(20), blurRadius: 6, offset: const Offset(0, 2))],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ☆☆☆ 图片按 cover 铺满 ☆☆☆
                Expanded(
                  child: Stack(
                    children: [
                      ClipRRect(
                        borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
                        child: _coverThumb(img),
                      ),
                      if (isPinned)
                        Positioned(
                          top: 8, right: 8,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(color: Colors.orange[600], borderRadius: BorderRadius.circular(8)),
                            child: const Text('PINNED', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                          ),
                        ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (priceText.isNotEmpty)
                        Text(priceText, style: const TextStyle(color: Color(0xFF13C45B), fontWeight: FontWeight.bold, fontSize: 18)),
                      const SizedBox(height: 4),
                      Text(r['title']?.toString() ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14)),
                      const SizedBox(height: 3),
                      Text(r['city']?.toString() ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // 统一封面图渲染：按 cover 铺满
  Widget _coverThumb(String? src) {
    if (src == null || src.isEmpty) return _imgPlaceholderCover();
    final imgWidget = src.startsWith('http')
        ? Image.network(src, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _imgPlaceholderCover())
        : Image.asset(src, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _imgPlaceholderCover());
    return SizedBox.expand(child: imgWidget);
  }

  Widget _imgPlaceholderCover() => SizedBox.expand(
    child: Container(color: Colors.grey[300], child: const Center(child: Icon(Icons.image, size: 50))),
  );
}
