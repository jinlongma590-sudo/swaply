// lib/pages/my_listings_page.dart - 最终修复版本
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:swaply/services/listing_service.dart';
import 'package:swaply/services/offer_service.dart';
import 'package:swaply/services/notification_service.dart';
import 'package:swaply/models/offer.dart';
import 'package:swaply/pages/product_detail_page.dart';
import 'package:swaply/pages/sell_form_page.dart';
import 'package:flutter/foundation.dart';
import 'package:url_launcher/url_launcher.dart';

class MyListingsPage extends StatefulWidget {
  const MyListingsPage({Key? key}) : super(key: key);

  @override
  State<MyListingsPage> createState() => _MyListingsPageState();
}

class _MyListingsPageState extends State<MyListingsPage> with TickerProviderStateMixin {
  late TabController _tabController;

  List<Map<String, dynamic>> _listings = [];
  List<OfferModel> _receivedOffers = [];
  bool _isLoadingListings = true;
  bool _isLoadingOffers = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  /// 加载数据
  Future<void> _loadData() async {
    await Future.wait([
      _loadListings(),
      _loadReceivedOffers(),
    ]);
  }

  /// 加载我的商品列表
  Future<void> _loadListings() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) {
      setState(() {
        _isLoadingListings = false;
        _errorMessage = 'Please login to view your listings';
      });
      return;
    }

    try {
      setState(() {
        _isLoadingListings = true;
        _errorMessage = null;
      });

      final listings = await ListingService.fetchMyListings(
        userId: user.id,
        limit: 100,
        status: 'active',
      );

      if (mounted) {
        setState(() {
          _listings = listings;
          _isLoadingListings = false;
        });

        if (kDebugMode) {
          print('Loaded ${listings.length} listings');
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error loading listings: $e');
      }

      if (mounted) {
        setState(() {
          _isLoadingListings = false;
          _errorMessage = 'Failed to load listings. Please try again.';
        });
      }
    }
  }

  /// 加载收到的报价
  Future<void> _loadReceivedOffers() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) {
      setState(() => _isLoadingOffers = false);
      return;
    }

    try {
      setState(() => _isLoadingOffers = true);

      final offers = await OfferService.getReceivedOffers(
        userId: user.id,
        limit: 100,
      );

      // Fallback: if nothing returned (joins blocked by RLS), try a simpler query
      List<Map<String, dynamic>> offersMutable = List<Map<String, dynamic>>.from(offers);
      if (offersMutable.isEmpty) {
        try {
          final supa = Supabase.instance.client;
          final raw = await supa
              .from('offers')
              .select('*, listings!inner(id,title,images,price,city)')
              .eq('seller_id', user.id)
              .order('created_at', ascending: false);

          if (raw is List && raw.isNotEmpty) {
            offersMutable = raw.cast<Map<String, dynamic>>();
          }
        } catch (_) {}
      }

      if (mounted) {
        setState(() {
          _receivedOffers = offersMutable.map((offer) => OfferModel.fromMap(offer)).toList();
          _isLoadingOffers = false;
        });

        if (kDebugMode) {
          print('Loaded ${offersMutable.length} received offers');
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error loading offers: $e');
      }

      if (mounted) {
        setState(() => _isLoadingOffers = false);
      }
    }
  }

  /// 刷新数据
  Future<void> _refreshData() async {
    await _loadData();
  }

  /// 删除商品
  Future<void> _deleteListing(Map<String, dynamic> listing, int index) async {
    try {
      final listingId = int.tryParse(listing['id']?.toString() ?? '');
      if (listingId == null) throw Exception('Invalid listing ID');

      // 获取图片路径用于删除存储对象
      final images = ListingService.readImages(listing);
      final imagePaths = images
          .map(ListingService.publicUrlToObjectPath)
          .whereType<String>()
          .toList();

      await ListingService.deleteListingAndStorage(
        id: listingId,
        imageObjectPaths: imagePaths,
      );

      if (mounted) {
        setState(() {
          _listings.removeAt(index);
        });

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Listing deleted successfully'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error deleting listing: $e');
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to delete listing: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  /// 处理报价操作
  Future<void> _handleOfferAction(OfferModel offer, OfferStatus newStatus, String? message) async {
    try {
      final success = await OfferService.updateOfferStatus(
        offerId: offer.id,
        status: newStatus,
        responseMessage: message,
      );

      if (success) {
        // 重新加载报价列表
        await _loadReceivedOffers();

        // 发送通知给买家
        if (newStatus == OfferStatus.accepted || newStatus == OfferStatus.declined) {
          try {
            if (newStatus == OfferStatus.accepted) {
              await NotificationService.createSystemNotification(
                recipientId: offer.buyerId,
                title: 'Offer Accepted! 🎉',
                message: 'Your offer of ${offer.formattedOfferAmount} for ${offer.listingTitle ?? 'the item'} has been accepted!',
                metadata: {
                  'offer_amount': offer.offerAmount,
                  'listing_title': offer.listingTitle,
                  'action': newStatus.value,
                  'response_message': message,
                  'listing_id': offer.listingId,
                  'offer_id': offer.id,
                },
              );
            } else {
              await NotificationService.createSystemNotification(
                recipientId: offer.buyerId,
                title: 'Offer Declined',
                message: 'Your offer of ${offer.formattedOfferAmount} for ${offer.listingTitle ?? 'the item'} has been declined${message != null && message.isNotEmpty ? ': $message' : '.'}',
                metadata: {
                  'offer_amount': offer.offerAmount,
                  'listing_title': offer.listingTitle,
                  'action': newStatus.value,
                  'response_message': message,
                  'listing_id': offer.listingId,
                  'offer_id': offer.id,
                },
              );
            }
          } catch (e) {
            if (kDebugMode) {
              print('Error sending notification: $e');
            }
          }
        }

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Offer ${newStatus.displayText.toLowerCase()} successfully'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (kDebugMode) {
        print('Error handling offer action: $e');
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to ${newStatus.displayText.toLowerCase()} offer'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  /// 构建商品列表
  Widget _buildListingsTab() {
    if (_isLoadingListings) {
      return const Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF2196F3)),
        ),
      );
    }

    if (_errorMessage != null) {
      return _buildErrorState();
    }

    if (_listings.isEmpty) {
      return _buildEmptyListingsState();
    }

    return RefreshIndicator(
      onRefresh: _refreshData,
      color: const Color(0xFF2196F3),
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _listings.length,
        itemBuilder: (context, index) {
          return _buildListingCard(_listings[index], index);
        },
      ),
    );
  }

  /// 构建报价列表
  Widget _buildOffersTab() {
    if (_isLoadingOffers) {
      return const Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF2196F3)),
        ),
      );
    }

    if (_receivedOffers.isEmpty) {
      return _buildEmptyOffersState();
    }

    return RefreshIndicator(
      onRefresh: _refreshData,
      color: const Color(0xFF2196F3),
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _receivedOffers.length,
        itemBuilder: (context, index) {
          return _buildOfferCard(_receivedOffers[index]);
        },
      ),
    );
  }

  /// 构建商品卡片
  Widget _buildListingCard(Map<String, dynamic> listing, int index) {
    final title = listing['title']?.toString() ?? 'No Title';
    final price = listing['price']?.toString() ?? 'No Price';
    final images = ListingService.readImages(listing);
    final firstImage = images.isNotEmpty ? images.first : 'assets/images/placeholder.jpg';
    final city = listing['city']?.toString() ?? '';
    final createdAt = listing['created_at']?.toString() ?? '';

    // 格式化创建时间
    String timeAgo = 'Recently';
    if (createdAt.isNotEmpty) {
      try {
        final date = DateTime.parse(createdAt);
        final now = DateTime.now();
        final difference = now.difference(date);

        if (difference.inMinutes < 60) {
          timeAgo = '${difference.inMinutes}m ago';
        } else if (difference.inHours < 24) {
          timeAgo = '${difference.inHours}h ago';
        } else if (difference.inDays < 7) {
          timeAgo = '${difference.inDays}d ago';
        } else {
          timeAgo = '${date.day}/${date.month}/${date.year}';
        }
      } catch (e) {
        timeAgo = 'Recently';
      }
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ProductDetailPage(
                productId: listing['id']?.toString(),
                productData: listing,
              ),
            ),
          );
        },
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 商品图片
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Container(
                  width: 80,
                  height: 80,
                  color: Colors.grey[200],
                  child: firstImage.startsWith('http')
                      ? Image.network(
                    firstImage,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return const Icon(Icons.image, color: Colors.grey);
                    },
                  )
                      : Image.asset(
                    firstImage,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return const Icon(Icons.image, color: Colors.grey);
                    },
                  ),
                ),
              ),
              const SizedBox(width: 12),

              // 商品信息
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      price,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF2196F3),
                      ),
                    ),
                    const SizedBox(height: 4),
                    if (city.isNotEmpty)
                      Row(
                        children: [
                          Icon(
                            Icons.location_on,
                            size: 14,
                            color: Colors.grey[600],
                          ),
                          const SizedBox(width: 4),
                          Text(
                            city,
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(
                          Icons.visibility,
                          size: 14,
                          color: Colors.grey[600],
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '234 views', // 这里可以从数据库获取真实的浏览量
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey[600],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          'Posted $timeAgo',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey[500],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              // 操作菜单
              PopupMenuButton<String>(
                onSelected: (value) async {
                  switch (value) {
                    case 'edit':
                    // 导航到编辑页面
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const SellFormPage(),
                        ),
                      );
                      break;
                    case 'delete':
                      _showDeleteDialog(listing, index);
                      break;
                  }
                },
                itemBuilder: (BuildContext context) => [
                  const PopupMenuItem(
                    value: 'edit',
                    child: Row(
                      children: [
                        Icon(Icons.edit, size: 18),
                        SizedBox(width: 8),
                        Text('Edit'),
                      ],
                    ),
                  ),
                  const PopupMenuItem(
                    value: 'delete',
                    child: Row(
                      children: [
                        Icon(Icons.delete, size: 18, color: Colors.red),
                        SizedBox(width: 8),
                        Text('Delete', style: TextStyle(color: Colors.red)),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// 构建报价卡片
  Widget _buildOfferCard(OfferModel offer) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 买家信息和报价状态
            Row(
              children: [
                CircleAvatar(
                  radius: 20,
                  backgroundColor: const Color(0xFF2196F3),
                  backgroundImage: offer.buyerAvatar != null
                      ? NetworkImage(offer.buyerAvatar!)
                      : null,
                  child: offer.buyerAvatar == null
                      ? Text(
                    offer.buyerDisplayName.substring(0, 1).toUpperCase(),
                    style: const TextStyle(color: Colors.white, fontSize: 16),
                  )
                      : null,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        offer.buyerDisplayName,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        'Made an offer ${offer.timeAgo}',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Color(offer.status.color).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    offer.status.displayText,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Color(offer.status.color),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // 商品信息
            if (offer.listingTitle != null) ...[
              Row(
                children: [
                  Icon(
                    Icons.shopping_bag,
                    size: 16,
                    color: Colors.grey[600],
                  ),
                  const SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      offer.listingTitle!,
                      style: const TextStyle(fontSize: 14),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
            ],

            // 报价信息
            Row(
              children: [
                Text(
                  'Offer: ${offer.formattedOfferAmount}',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF2196F3),
                  ),
                ),
                if (offer.formattedOriginalPrice != null) ...[
                  const SizedBox(width: 8),
                  Text(
                    'Original: ${offer.formattedOriginalPrice}',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                      decoration: TextDecoration.lineThrough,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    '(${offer.offerPercentage.toStringAsFixed(0)}%)',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ],
            ),

            // 报价消息
            if (offer.message != null && offer.message!.isNotEmpty) ...[
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.grey[50],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  offer.message!,
                  style: const TextStyle(fontSize: 14),
                ),
              ),
            ],

            // 过期时间
            if (offer.status == OfferStatus.pending) ...[
              const SizedBox(height: 8),
              Text(
                offer.formattedTimeUntilExpiry ?? 'Expired',
                style: TextStyle(
                  fontSize: 12,
                  color: offer.isExpired ? Colors.red : Colors.orange,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],

            // 操作按钮
            if (offer.status == OfferStatus.pending && !offer.isExpired) ...[
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => _showDeclineDialog(offer),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.red,
                        side: const BorderSide(color: Colors.red),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: const Text('Decline'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => _showAcceptDialog(offer),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF4CAF50),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: const Text('Accept'),
                    ),
                  ),
                ],
              ),
            ],

            // 联系买家按钮
            if (offer.contactPhone != null) ...[
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () => _contactBuyer(offer.contactPhone!),
                  icon: const Icon(Icons.phone, size: 18),
                  label: const Text('Contact Buyer'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFF2196F3),
                    side: const BorderSide(color: Color(0xFF2196F3)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  /// 构建空状态 - 无商品
  Widget _buildEmptyListingsState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.add_business,
              size: 80,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            const Text(
              'No Listings Yet',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Start selling by posting your first item. Take photos and create listings easily.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const SellFormPage(),
                  ),
                );
              },
              icon: const Icon(Icons.add),
              label: const Text('Post New Item'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2196F3),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// 构建空状态 - 无报价
  Widget _buildEmptyOffersState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.local_offer,
              size: 80,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            const Text(
              'No Offers Yet',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'When buyers make offers on your items, they will appear here.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// 构建错误状态
  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline,
              size: 80,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            const Text(
              'Something went wrong',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _errorMessage ?? 'Failed to load your data.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _loadData,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2196F3),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: const Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }

  /// 显示删除确认对话框
  void _showDeleteDialog(Map<String, dynamic> listing, int index) {
    final title = listing['title']?.toString() ?? 'this item';

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Delete Listing'),
          content: Text('Are you sure you want to delete "$title"? This action cannot be undone.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _deleteListing(listing, index);
              },
              child: const Text(
                'Delete',
                style: TextStyle(color: Colors.red),
              ),
            ),
          ],
        );
      },
    );
  }

  /// 显示接受报价对话框
  void _showAcceptDialog(OfferModel offer) {
    final messageController = TextEditingController();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Accept Offer'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Accept offer of ${offer.formattedOfferAmount} from ${offer.buyerDisplayName}?'),
              const SizedBox(height: 16),
              TextField(
                controller: messageController,
                decoration: const InputDecoration(
                  labelText: 'Message to buyer (optional)',
                  hintText: 'Thank you for your offer...',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                _handleOfferAction(
                  offer,
                  OfferStatus.accepted,
                  messageController.text.trim().isEmpty ? null : messageController.text.trim(),
                );
              },
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4CAF50)),
              child: const Text('Accept'),
            ),
          ],
        );
      },
    );
  }

  /// 显示拒绝报价对话框
  void _showDeclineDialog(OfferModel offer) {
    final messageController = TextEditingController();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Decline Offer'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Decline offer of ${offer.formattedOfferAmount} from ${offer.buyerDisplayName}?'),
              const SizedBox(height: 16),
              TextField(
                controller: messageController,
                decoration: const InputDecoration(
                  labelText: 'Reason (optional)',
                  hintText: 'Thank you for your interest, but...',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                _handleOfferAction(
                  offer,
                  OfferStatus.declined,
                  messageController.text.trim().isEmpty ? null : messageController.text.trim(),
                );
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              child: const Text('Decline'),
            ),
          ],
        );
      },
    );
  }

  /// 联系买家
  void _contactBuyer(String phone) async {
    final uri = Uri(scheme: 'tel', path: phone);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not launch phone call')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final pendingOffersCount = _receivedOffers.where((offer) => offer.status == OfferStatus.pending).length;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        title: const Text(
          'My Listings',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
        backgroundColor: const Color(0xFF2196F3),
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.white,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          tabs: [
            Tab(text: 'Items (${_listings.length})'),
            Tab(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Offers'),
                  if (pendingOffersCount > 0) ...[
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        '$pendingOffersCount',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ] else ...[
                    Text(' (${_receivedOffers.length})'),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildListingsTab(),
          _buildOffersTab(),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const SellFormPage(),
            ),
          ).then((_) => _loadListings()); // 添加商品后刷新列表
        },
        backgroundColor: const Color(0xFF2196F3),
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }
}