// lib/startup_screen.dart
import 'package:flutter/material.dart';

class StartupScreen extends StatefulWidget {
  const StartupScreen({super.key, this.onFinished, this.duration = const Duration(seconds: 3)});

  final VoidCallback? onFinished;
  final Duration duration;

  @override
  State<StartupScreen> createState() => _StartupScreenState();
}

class _StartupScreenState extends State<StartupScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat();

    if (widget.onFinished != null) {
      Future.delayed(widget.duration, () {
        if (mounted) widget.onFinished!();
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  // 单个小圆点
  Widget _dot(double begin, double end) {
    return ScaleTransition(
      scale: Tween<double>(begin: 0.75, end: 1.0)
          .chain(CurveTween(curve: Interval(begin, end, curve: Curves.easeInOut)))
          .animate(_controller),
      child: Container(
        width: 10,
        height: 10,
        margin: const EdgeInsets.symmetric(horizontal: 6),
        decoration: const BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // 正确读取安全区与尺寸（不再使用 size.padding）
    final insets = MediaQuery.of(context).padding;
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: const Color(0xFF2196F3),
      body: Padding(
        padding: EdgeInsets.only(top: insets.top, bottom: insets.bottom),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // 这里随便放个 Logo 位
              Container(
                width: size.width * 0.28,
                height: size.width * 0.28,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.15),
                  shape: BoxShape.circle,
                ),
                alignment: Alignment.center,
                child: const Text(
                  'Swaply',
                  style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(height: 20),
              // 你的三颗小圆点
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _dot(0.00, 0.50),
                  _dot(0.15, 0.65),
                  _dot(0.30, 0.80),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
