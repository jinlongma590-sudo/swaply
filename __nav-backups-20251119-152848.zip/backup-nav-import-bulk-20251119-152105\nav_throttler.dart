// lib/router/nav_throttler.dart
import 'dart:async';

class NavThrottler {
  // 按“标签”限流（比如 'login-callback', 'reset-password', 'show-dialog:x'）
  static final Map<String, bool> _locks = {};

  /// 在一个小时间窗内，同标签只允许执行一次。
  /// [hold] 建议 500~800ms，安卓深链双触发常见在 50~300ms 之间。
  static Future<bool> run(String tag, FutureOr<void> Function() fn,
      {Duration hold = const Duration(milliseconds: 700)}) async {
    if (_locks[tag] == true) return false;
    _locks[tag] = true;
    try {
      // ⚠️ 不要在 fn 里 await push 的返回值（那会等到页面被 pop 才解锁）
      await fn();
      return true;
    } finally {
      // 下一帧 + 缓冲后自动解锁，防止同帧连击
      Future<void>.delayed(hold, () => _locks.remove(tag));
    }
  }
}
