﻿// lib/services/oauth_service.dart
//
// 缂佺喍绔撮惃?OAuth 閻ц缍嶇亸浣筋棅閿涘湙oogle / Facebook / Apple閿?
// - 鏉╂柨娲栫猾璇茬€风紒鐔剁 Future<void>閿涘牆鍚嬬€硅妫悧鍫ｇ箲閸?bool閵嗕焦鏌婇悧鍫ｇ箲閸?AuthResponse閿?
// - redirectTo閿涙瓙eb 娴?null閿涙稓些閸斻劎顏导?swaply://login-callback閿涘牐顫?auth_config.dart閿?
//
// 娑撳秴濂栭崫?Android閿涙铂OS 娓氭繆绂?Info.plist 闁插瞼娈?URL Schemes 瀹告彃姘ㄧ紒顏傗偓?

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:swaply/services/oauth_entry.dart';
import 'package:supabase_flutter/supabase_flutter.dart' as sf;
import 'package:swaply/services/oauth_entry.dart';
// kAuthRedirectUri = 'cc.swaply.app://login-callback'

class OAuthService {
  OAuthService._();

  static sf.SupabaseClient get _sb => sf.Supabase.instance.client;

  /// Google 閻ц缍?
  static Future<void> signInWithGoogle() async {
    await OAuthEntry.signIn(
      sf.OAuthProvider.google,
      queryParams: const {'prompt': 'select_account'},
    );
  }

  /// Facebook 閻ц缍?
  static Future<void> signInWithFacebook() async {
    await OAuthEntry.signIn(
      sf.OAuthProvider.facebook,
      );
  }

  /// Apple 閻ц缍嶉敍鍫滅矌 iOS 閺勫墽銇氶幐澶愭尦閿?
  static Future<void> signInWithApple() async {
    await OAuthEntry.signIn(
      sf.OAuthProvider.apple,
      );
  }
}




