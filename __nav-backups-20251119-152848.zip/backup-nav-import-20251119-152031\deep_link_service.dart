﻿// lib/services/deep_link_service.dart
import 'dart:async';
import 'package:app_links/app_links.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:swaply/router/nav_throttler.dart';


/// 统一深链服务：不自建 GlobalKey，只复用传入的 rootNavKey。
/// 使用：DeepLinkService.I.init(rootNavKey);
class DeepLinkService {
  DeepLinkService._();
  static final DeepLinkService I = DeepLinkService._();

  bool _inited = false;
  GlobalKey<NavigatorState>? _navKey; // 仅保存引用
  AppLinks? _appLinks;
  StreamSubscription<Uri>? _sub;

  // 去抖：Android 偶发同一 URL 连发；1s 内重复忽略
  String? _lastUrl;
  DateTime? _lastAt;

  // “只跳一次”保护（避免多次进重置页）
  bool _navigatedToReset = false;

  NavigatorState? get _nav => _navKey?.currentState;

  Future<void> init(GlobalKey<NavigatorState> navKey) async {
    if (_inited) return;
    _inited = true;
    _navKey = navKey;

    // init 多在 runApp 前调用，此时 currentState 未挂载属正常
    assert(
    _navKey!.currentState == null,
    'DeepLinkService: init called before runApp is fine.',
    );

    try {
      _appLinks = AppLinks();

      // ✅ 冷启动初始链接（6.x 用 getInitialLink）
      final initial = await _appLinks!.getInitialLink();
      if (kDebugMode) print('[DeepLink] initial=$initial');
      if (initial != null) _handle(initial);

      // 运行期链接流
      _sub = _appLinks!.uriLinkStream.listen(
            (uri) {
          if (kDebugMode) print('[DeepLink] stream=$uri');
          _handle(uri);
        },
        onError: (e, st) {
          if (kDebugMode) print('[DeepLink] stream error: $e\n$st');
        },
      );
    } catch (e, st) {
      if (kDebugMode) print('[DeepLink] init error: $e\n$st');
    }
  }

  /// 安全 pushNamed：若根导航未挂载，延后一帧再导航
  Future<T?> _pushNamed<T extends Object?>(String route) async {
    final nav = _nav;
    if (nav == null) {
      if (kDebugMode) print('[DeepLink] root navigator not attached yet.');
      final c = Completer<T?>();
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        try {
          final res = await _nav?.pushNamed<T>(route);
          if (!c.isCompleted) c.complete(res);
        } catch (e, st) {
          if (kDebugMode) print('[DeepLink] delayed pushNamed error: $e\n$st');
          if (!c.isCompleted) c.complete(null);
        }
      });
      return c.future;
    }
    try {
      return await nav.pushNamed<T>(route);
    } catch (e, st) {
      if (kDebugMode) print('[DeepLink] pushNamed error: $e\n$st');
      return null;
    }
  }

  void _handle(Uri uri) {
    // 1) 1 秒去重（Android 常见重复触发）
    final now = DateTime.now();
    final s = uri.toString();
    if (_lastUrl == s && _lastAt != null && now.difference(_lastAt!) < const Duration(seconds: 1)) {
      if (kDebugMode) print('[DeepLink] duplicate within 1s, drop: $s');
      return;
    }
    _lastUrl = s;
    _lastAt = now;

    // 2) 兼容 host/path 两种形式
    final scheme = (uri.scheme).toLowerCase();
    final host = (uri.host).toLowerCase();
    final path = (uri.path).toLowerCase();
    final seg = uri.path.toLowerCase().replaceAll('/', '');

    // 3) Supabase OAuth 登录回调由库自身处理，这里跳过
    final looksLikeSupaLoginCallback =
        (scheme == 'cc.swaply.app') &&
            (host.contains('login-callback') || seg == 'login-callback' || path.contains('login-callback'));
    if (looksLikeSupaLoginCallback) {
      if (kDebugMode) print('[DeepLink] skip login-callback (handled by Supabase/Auth).');
      return;
    }

    // 4) 解析 query + fragment（Supabase 可能把 type 放在 fragment）
    final qp = <String, String>{};
    try {
      qp.addAll(uri.queryParameters);
      if (uri.fragment.isNotEmpty) {
        try {
          qp.addAll(Uri.splitQueryString(uri.fragment));
        } catch (_) {
          final frag = uri.fragment.replaceAll('#', '').replaceAll('?', '&');
          try {
            qp.addAll(Uri.splitQueryString(frag));
          } catch (_) {}
        }
      }
    } catch (_) {}
    final type = (qp['type'] ?? qp['event'] ?? '').trim().toLowerCase();

    // 5) 重置密码：type=recovery 或路径/片段包含 reset-password
    final isResetPath =
        path.endsWith('/reset-password') || host.contains('reset-password') || seg == 'reset-password';
    final isRecovery = type == 'recovery';
    if ((isRecovery || isResetPath) && !_navigatedToReset) {
      _navigatedToReset = true; // 只跳一次
      _pushNamed('/reset-password');
      if (kDebugMode) print('[DeepLink] -> /reset-password');
      return;
    }

    if (kDebugMode) print('[DeepLink] unhandled link: $uri');
  }

  Future<void> dispose() async {
    await _sub?.cancel();
    _sub = null;
    _appLinks = null;
    _navKey = null;
    _inited = false;
  }
}
