﻿// lib/services/oauth_entry.dart
import 'dart:async';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart' show LaunchMode;

class OAuthEntry {
  OAuthEntry._();

  // 公开只读：供 UI 判断按钮是否可点
  static bool _inFlight = false;
  static bool get inFlight => _inFlight;

  static Timer? _resetTimer;

  static const String _mobileRedirect = 'cc.swaply.app://login-callback';
  static const String _webRedirect = 'https://swaply.cc/auth/callback';

  static void _armReset([Duration d = const Duration(seconds: 12)]) {
    _resetTimer?.cancel();
    _resetTimer = Timer(d, () {
      _inFlight = false; // 超时兜底复位，防止卡死
    });
  }

  static Future<void> signIn(
      OAuthProvider provider, {
        String? scopes,
        Map<String, String>? queryParams,
      }) async {
    if (_inFlight) return; // 防重复点
    _inFlight = true;
    _armReset(); // 启动兜底计时器

    await Supabase.instance.client.auth.signInWithOAuth(
      provider,
      redirectTo: kIsWeb ? _webRedirect : _mobileRedirect,
      authScreenLaunchMode: LaunchMode.externalApplication,
      scopes: scopes,
      queryParams: queryParams,
    );

    // 注意：不要在这里立刻把 _inFlight 置回 false
    // 等 onAuthStateChange 收到 signedIn（或超时）再复位，避免二次弹窗/双跳
  }

  /// 可选：在全局 onAuthStateChange 里调用，登录成功后立即清锁
  static void clearGuardIfSignedIn(AuthState state) {
    final ok = state.event == AuthChangeEvent.signedIn ||
        state.session?.user != null;
    if (ok) {
      _inFlight = false;
      _resetTimer?.cancel();
      _resetTimer = null;
    }
  }
}
